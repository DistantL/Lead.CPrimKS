﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lead.CPrim.Interfaces.HoneywellPrinter
{
    public delegate void MsgReved(string context);
    public interface IHoneywellPrinter
    {
        event MsgReved OnMsgReved;
        int PrintCommand(string cmd);
        int GetDrvState(ref string errMsg);
        int PrintBlank();
        int QueryCommand(string cmd, out string result);
    }
}
