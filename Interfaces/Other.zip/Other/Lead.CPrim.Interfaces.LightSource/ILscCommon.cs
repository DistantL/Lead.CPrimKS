﻿namespace Lead.CPrim.Interfaces.LightSource
{
    public enum ConnType
    {
        Serial,
        Ethernet
    }

    public enum DevType
    {
        CST,
        SerialCommon,
        EthCommon,
        Other
    }

    public enum LscType
    {
        Digital,
        Analog,
        Strobe
    }

    public interface ILscCommon
    {
        /// <summary>
        ///     连接类型
        /// </summary>
        ConnType ConnType { set; get; }

        /// <summary>
        ///     设备厂商分类
        /// </summary>
        DevType DevType { set; get; }

        /// <summary>
        ///     控制器类型
        /// </summary>
        LscType LscType { set; get; }

        /// <summary>
        ///     获取光源延时
        /// </summary>
        /// <param name="chIndex">通道号</param>
        /// <param name="delayValue">延时时间</param>
        /// <returns>指令执行结果</returns>
        int GetLightDelayValue(int chIndex, out int delayValue);

        /// <summary>
        ///     获取光源亮度
        /// </summary>
        /// <param name="chIndex">通道号</param>
        /// <param name="lightValue">亮度值</param>
        /// <returns>指令执行结果</returns>
        int GetLightness(int chIndex, out int lightValue);

        /// <summary>
        ///     获取频闪光源频闪值
        /// </summary>
        /// <param name="chIndex">通道号</param>
        /// <param name="strobeValue">频闪值</param>
        /// <returns>指令执行结果</returns>
        int GetStrobeValue(int chIndex, int strobeValue);

        /// <summary>
        ///     获取光源常亮常灭工作模式
        /// </summary>
        /// <param name="lightState">模式：0-常灭，常亮</param>
        /// <returns>指令执行结果</returns>
        int GetTrigLevel(out int lightState);

        /// <summary>
        ///     获取光源触发模式
        /// </summary>
        /// <param name="lightTrigMode">触发模式：0-外触发，1-内触发</param>
        /// <returns>指令执行结果</returns>
        int GetTrigMode(out int lightTrigMode);

        /// <summary>
        ///     设置光源延时
        /// </summary>
        /// <param name="chIndex">通道号</param>
        /// <param name="delayValue">延时时间</param>
        /// <returns>指令执行结果</returns>
        int SetLightDelayValue(int chIndex, int delayValue);

        /// <summary>
        ///     设置光源亮度
        /// </summary>
        /// <param name="chIndex">通道号</param>
        /// <param name="lightValue">亮度值</param>
        /// <returns>指令执行结果</returns>
        int SetLightness(int chIndex, int lightValue);

        /// <summary>
        ///     设置频闪光源频闪值
        /// </summary>
        /// <param name="chIndex">通道号</param>
        /// <param name="strobeValue">频闪值</param>
        /// <returns>指令执行结果</returns>
        int SetStrobeValue(int chIndex, int strobeValue);

        /// <summary>
        ///     设置光源常亮常灭工作模式
        /// </summary>
        /// <param name="lightState">模式：0-常灭，常亮</param>
        /// <returns>指令执行结果</returns>
        int SetTrigLevel(int lightState);

        /// <summary>
        ///     设置光源触发模式
        /// </summary>
        /// <param name="lightTrigMode">触发模式：0-外触发，1-内触发</param>
        /// <returns>指令执行结果</returns>
        int SetTrigMode(int lightTrigMode);
    }
}