﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lead.CPrim.Interfaces.Bartender
{
    public interface IBartender
    {
        string CurrentPrintDataFile { set; get; }
        string TemplatePrintDataFile { set; get; }
        string InitPrinter(string printerName, string sLabelID);
        string PrintByOnes(List<Dictionary<string, string>> dicLabels);
        string PrintByOnes(List<Dictionary<string, string>> dicLabels, int fromNum, int count);
        string PrintByOnes(Dictionary<string, string> dicLabels, int count = 1);
        int GetLabels(string filePath, out List<Dictionary<string, string>> labels, int count = -1, char splitChar = '`', bool modify = false);
        List<Dictionary<string, string>> EnqueueLabels(string filePath, char splitChar = '`');
        void EnqueueLabels(List<Dictionary<string, string>> labels);
        Dictionary<string, string> DequeuePrintByOnes();
        int DequeuePrintLabels(int count, out int noPrintedNum, string dataFile = "", char splitChar = '`');
    }
}
