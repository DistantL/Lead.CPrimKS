﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;

namespace Lead.CPrim.Interfaces.SensorCVC
{
    /// <summary>
    /// 用于3D传感器的通用接口
    /// </summary>
    public interface IPrimSensorCVC
    {
        int LoadSettings(string productName);
        int SaveSettings(string productName);
        bool LoadLut(bool enable, string fileName);
        bool StartAcquisition();
        bool StopAcquisition();
        bool StartTrigger();
        bool StopTrigger();
        bool ReverseReading(bool value);
        bool FlipLine(bool value);
        bool SetLinesCount(int count);
        bool SetExposureTime(float value);
        void ClearBufferImage();
        Bitmap GetImage();
    }
}
