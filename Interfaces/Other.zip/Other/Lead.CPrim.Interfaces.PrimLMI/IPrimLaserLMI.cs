﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lead.CPrim.Interfaces.PrimLMI
{
    [Serializable]
    public struct ProfilePoints
    {
        public double x;
        public double y;
        public double z;
    }
    public interface IPrimLaserLMI
    {
        bool UpEnable { get; set; }
        bool DownEnable { get; set; }
        List<ProfilePoints[]> GetBatch();
        List<ProfilePoints[]> GetUpBatch();
        List<ProfilePoints[]> GetDownBatch();
        void ClearBatch();
        void switchJob(string path, string sensorName);
        void setScanPara(double legth, double pitch);
        bool isFinishDataPass(int count);
        void LoadLMITask(string JobPathAndName);

    }
}
