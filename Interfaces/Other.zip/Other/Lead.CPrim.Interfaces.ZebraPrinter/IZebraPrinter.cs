﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lead.CPrim.Interfaces.ZebraPrinter
{
    public delegate void MsgReved(string context);
    public interface IZebraPrinter
    {
        event MsgReved OnMsgReved;
        int PrintCommand(string cmd);
        int ReStartPrinter();
        int PausePrinter();
        int PrintBlank();
        int GetDrvState();
    }
}
