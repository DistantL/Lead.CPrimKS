﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CommonStruct2D.VisionStruct;
using VisionGraphic;
using VisionGraphic2D;

namespace Lead.CPrim.Interfaces
{

    /*
	功能：刷新运行过程信息
	参数：
		  strArgs -- 刷新信息
	返回：刷新完成标志
*/
    public delegate bool DelegateStringEventHandle(string strArgs);

    /*
        功能：刷新图形控件事件
        参数：
              strTask -- 任务名
        返回：刷新完成标志
    */
    public delegate bool DelegateGuidRunOutsideShowEventHandle(string strTask);


    /*
        功能：拍照完成事件，接收到后表示指定任务已拍照完成
        参数：
              taskName -- 任务名
        返回：无
    */
    public delegate void DelegateCaptureFinish(string taskName);


    /*
        功能：任务执行完成事件
        参数：
              taskName -- 任务名
              bSucess -- 任务执行结果
        返回：无
    */
    public delegate void DelegateTaskFinish(string taskName, bool bSucess);


    /*
        功能：获取对位结果事件
        参数：
              alignResult  -- 对位结果列表
        返回：无
    */
    public delegate void DelegateAlignResultOut(List<AlignResult> alignResult);


    /*
        功能：回调运动控制事件,自动标定使用
        参数：
              taskName -- 任务名
              primName -- 标定基元名
              step -- 相对运动步长VisionPointAngle (x,y,r)
              pos -- 当前运动模组位置坐标VisionPointAngle (x,y,r)
        返回：无
    */
    public delegate bool DelegateMotionCtrl(string taskName, string primName, VisionPointAngle step, out VisionPointAngle pos);


    public interface IGoldVision
    {

        /*
      功能：回调运动控制事件,自动标定使用
      参数：
            taskName -- 任务名
            primName -- 标定基元名
            step -- 相对运动步长VisionPointAngle (x,y,r)
            pos -- 当前运动模组位置坐标VisionPointAngle (x,y,r)
      返回：无
  */
        event DelegateStringEventHandle updateMsgEvent;

        /*
       功能：回调运动控制事件,自动标定使用
       参数：
             taskName -- 任务名
             primName -- 标定基元名
             step -- 相对运动步长VisionPointAngle (x,y,r)
             pos -- 当前运动模组位置坐标VisionPointAngle (x,y,r)
       返回：无
   */
        event DelegateMotionCtrl motionCtrl;


        /*
    功能：刷新图形控件事件
    参数：
          strTask -- 任务名
    返回：刷新完成标志
*/
        event DelegateGuidRunOutsideShowEventHandle UpdateUIEvent;


        /*
            功能：拍照完成事件，接收到后表示指定任务已拍照完成
            参数：
                  taskName -- 任务名
            返回：无
        */
        event DelegateCaptureFinish CaptureFinishEvent;


        /*
    功能：任务执行完成事件
    参数：
          taskName -- 任务名
          bSucess -- 任务执行结果
    返回：无
*/
        event DelegateTaskFinish taskFinishEvent;


        /*
    功能：获取对位结果事件
    参数：
          alignResult  -- 对位结果列表
    返回：无
*/
        event DelegateAlignResultOut alignResultEvent;

        /*
            功能：获取任务编辑窗口
            参数：无
            返回：窗口实例
        */
        Form GetMainForm();

        /*
            功能：加载任务参数文件
            参数：
                  paramPath  -- 参数文件路径
                  errCode  -- 错误信息
            返回：加载参数结果标志
        */
        bool LoadTaskParam(string paramPath, string productName, out string errCode);

        /*
            功能：运行任务
            参数：
                  strTaskNameLst  -- 任务名列表
                  bExternal  -- 外部调用标志
                  errCode  -- 运行错误信息
                  CapturePosition  -- 当前拍照位坐标VisionPointAngle (x,y,angle)
            返回：任务启动完成标志
        */
        bool TaskRun(List<string> strTaskNameLst, bool bExternal, out string errCode, VisionPointAngle CapturePosition = new VisionPointAngle());

        /*
            功能：获取任务结果数据
            参数：
                  strTaskName -- 获取数据的任务名
                  variableName -- 获取数据任务中的变量名
            返回：结果数据列表
        */
        List<OutputStruct> GetTaskOutput(string strTaskName, string variableName);

        List<OutputStruct> GetAllTaskOutput(List<string> taskNameLst = null);

        /*
            功能：使用对位信息触发执行对位
            参数：
                  strStationName -- 获取结果的工站名
                  alignTrigInfo -- 对位信息列表
            返回：触发对位结果
        */
        bool GetAlignResult(string strStationName, List<AlignTrigInfo> alignTrigInfo);

       
        /*
            功能：updateUIEvent响应函数中调用，用以刷新对应控件图形显示
            参数：
                  graph2d -- 图形控件实例
                  strTask -- 任务名
            返回：无
        */
        void UpdateResultToMap2d(Map2D graph2d, string strTask);

    }
}
