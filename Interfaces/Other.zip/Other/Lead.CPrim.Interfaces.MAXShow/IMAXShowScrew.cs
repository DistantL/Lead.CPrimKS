﻿namespace Lead.CPrim.Interfaces.MAXShow
{
    public interface IMAXShowScrew
    {
        MAXState RobotState { set; get; }
        MAXState SupplyState { set; get; }
        MAXState Tool1State { set; get; }
        MAXState Tool2State { set; get; }
        TrayInfo UpTray { set; get; }
    }
}