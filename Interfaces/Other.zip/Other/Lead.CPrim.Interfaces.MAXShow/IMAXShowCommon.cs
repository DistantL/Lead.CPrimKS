﻿using System;
using System.Collections.Concurrent;

namespace Lead.CPrim.Interfaces.MAXShow
{
    public enum MAXState
    {
        Idle,
        Run,
        Stop,
        Alarm,
        Error
    }

    public enum PartStatus
    {
        OK,
        NG,
        Unknown
    }

    public interface IMAXShowCommon
    {
        double DownCt { set; }
        int NumNg { set; }
        int NumOk { set; }
        MAXState RtDownState { set; }
        string RtDownStepInfo { set; }
        MAXState RtUpState { set; }
        string RtUpStepInfo { set; }
        string StationInfo { set; }
        double UpCt { set; }
        double Uph { set; }
        DateTime UpTrayInTime { set; }
        DateTime UpTrayOutTime { set; }
    }

    public class CellInfo
    {
        public string Id { set; get; }
        public string Name { set; get; }
        public PartStatus Status { set; get; }

        public override string ToString()
        {
            return Id;
        }
    }

    public class TrayInfo
    {
        public TrayInfo()
        {
            Name = "";
            Id = Guid.NewGuid().ToString();
            Cells = new ConcurrentDictionary<int, CellInfo>();
        }

        public ConcurrentDictionary<int, CellInfo> Cells { set; get; }
        public string Id { set; get; }
        public string Name { set; get; }

        public override string ToString()
        {
            return Id;
        }
    }
}