﻿namespace Lead.CPrim.Interfaces.MAXShow
{
    public interface IMAXShowConveyor
    {
        void UpdateCellInfo(int trayIndex, int cellIndex, string id, PartStatus status = PartStatus.OK);

        void UpdateTrayInfo(int trayIndex, string id, PartStatus status = PartStatus.OK);
    }
}