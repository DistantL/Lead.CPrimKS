﻿using System.Collections.Generic;

namespace Lead.CPrim.Interfaces.MAXShow
{
    public delegate void Del_MAXQualifyRun();

    public interface IMAXQualify
    {
        bool Inited { get; }
        string Operator { get; }
        int Times { get; }
        string TrayID { get; }
        event Del_MAXQualifyRun OnMAXQualifyRunCycle;

        event Del_MAXQualifyRun OnMAXQualifyRunOnce;

        int AddMultiPartInfo<T>(List<T> listEntiy, bool saveDataBase = false, string qualifyDtName = "Qualify")
            where T : class;

        int AddMultiPartInfo<T>(T entiy, bool saveDataBase = false, string qualifyDtName = "Qualify") where T : class;
    }
}