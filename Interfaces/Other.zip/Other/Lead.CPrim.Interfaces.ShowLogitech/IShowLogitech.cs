﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lead.CPrim.Interfaces.ShowLogitech
{
    public interface IShowLogitech
    {
        int AddProInfo<T>(List<T> listEntiy, bool saveDataBase = false, string proTypeName = "",
            bool updateStatistic = false, Dictionary<string, bool> results = null) where T : class;

        int AddProInfo<T>(T entiy, bool saveDataBase = false, string proTypeName = "", bool updateStatistic = false,
            Dictionary<string, bool> results = null) where T : class;
        void UpdateBarcode(string barCode);

        void UpdateCt(double ct);
        void UpdateRt(double rt);
        void UpdateTotalTime(double time);
        void UpdateProduct(string result = "ok", string barCode = "");

        void UpdateProduct(int result = 1, string barCode = "");

        void UpdateProductType(string newType);
        void ClearStatistics();
        PnClass GetProductType(string pn);

        void GetStatisticInfo(out string barcode, out double ct, out int okCount, out int ngCount, out int totalCount, out double totalTime,
            out double rt, out double passRate);
    }

    public class PnClass
    {
        public string PN { set; get; }
        public string AoiTaskName { set; get; }
        public string Template { set; get; }
        public string ProductType { set; get; }

        public PnClass(string pn, string aoiTaskName, string template, string productType)
        {
            PN = pn;
            AoiTaskName = aoiTaskName;
            Template = template;
            ProductType = productType;
        }
    }
    public class LogitechLabel
    {
        public int Index { set; get; }
        public string Sn { set; get; }
        public string Result { set; get; }
        public int TestCount { set; get; }
    }
}
