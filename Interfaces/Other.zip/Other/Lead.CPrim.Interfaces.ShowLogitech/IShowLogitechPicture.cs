﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lead.CPrim.Interfaces.ShowLogitech
{
    public interface IShowLogitechPicture
    {
        void ClearLabels();
        void AddLabels(List<string> snList);
        void UpdateLabel(string sn, string result);
        int UpdateLabelResult(string sn, string result);
        void OpenNgForm();
        void OpenNgForm(string ngFilesPath);
        void RefreshOkPicture(string filePath);
        List<LogitechLabel> GetNoResultLabels();
        int GetLastBlankResults();
    }
}
