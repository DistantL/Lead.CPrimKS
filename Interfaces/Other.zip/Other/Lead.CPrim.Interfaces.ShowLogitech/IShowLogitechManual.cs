﻿using Lead.CPrim.Interfaces.Ele;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lead.CPrim.Interfaces.ShowLogitech
{
    public delegate void DelTrans(object obj);
    public delegate void DelTransFlag(object obj, bool flag);
    public delegate void DelPrint(string id, string filePath, int startIndex, int endIndex);
    public interface IShowLogitechManual
    {
        event DelTrans OnButtonPressed;
        event DelTransFlag OnUnlockDoor;
        event DelPrint OnPrintLabels;
        bool IsStepMode { set; get; }
        int ClearEvent();
        void InitCartesian(List<IEleAxis> carts);
        void OpenPrintWorkOrderForm();
        void UpdateWorkOrder(string id);
        void UpdateWorkOrderFile(string filePath);
        void UpdateProductType(string proType);
        void UpdatePrintStatus(string info);
        void AddLabels(List<string> listSns);
        void UpdateButton(string btnName, Color backColor, bool enable);
        void SwitchTabToManual(bool falg = true);
        int UpdateLabel(string sn);
        int UpdateLabel(int labelsNum);
        void ClearLabels();
    }
}
