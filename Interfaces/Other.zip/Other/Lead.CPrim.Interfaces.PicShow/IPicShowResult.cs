﻿namespace Lead.CPrim.Interfaces
{
    public interface IPicShowResult
    {
        int AddFaiByLocation(string faiName, double faiValue, int xPos, int yPos,
            ShowColor labelColor = ShowColor.Black);

        int AddResult(string labelName, int rowNum, int colNum, string labelFont = null, string labelColor = null);

        int AddResultByLocation(string labelName, int xPos, int yPos, string labelFont = null,
            string labelColor = null);

        int AddResultByLocation(string labelName, int xPos, int yPos, ShowColor labelColor = ShowColor.Black,
            string labelFont = null);

        int AddResults(string[] labelNames, int[] rowNums, int[] colNums);

        int AddResults(string[] labelNames);

        int ClearPicture();

        int ClearResults();

        bool IsContainLabelInfo(string labelName);

        int LoadPicture(string productName = null);

        int UpdateTable(int rowCount, int colCount);

        int UpdateTable(int rowCount, int colCount, int originX, int originY, int intervalX, int intervalY);
    }
}