﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lead.CPrim.Interfaces.Bracket
{
    public delegate void Del_PauseAndQuery();
    public interface IBracket
    {
        event Del_PauseAndQuery OnPauseAndQuery;
        string PlatingDate { get; set; }
        string LineNum { get; set; }
        string PlatingVendor { get; set; }
        bool BarcodeEnable { get; set; }
        bool RepeatUpload { set; get; }
        string StationName { set; get; }
        bool StartTest { set; get; }
        bool QueryDone { set; get; }
    }

    public class DataUpload
    {
        public int Index { set; get; }
        public string StartTime { set; get; }
        public string EndTime { set; get; }
        public bool Uploaded { set; get; }
    }
}
