﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lead.CPrim.Interfaces.Ftp
{
    public interface IFtpClient
    {
        string HostAddress { set; get; }
        int Port { set; get; }
        string UserName { set; get; }
        string PassWord { set; get; }
        int Connect();
        int UploadFile(string localFilePath, string remoteDirPath);
        int UploadManyFiles(string[] localFiles, string remoteDir);
        int UploadDirectory(string localFolder, string remoteFolder);
        int DownloadFile(string localDirPath, string remoteFilePath);
        int DownloadManyFiles(string localDir, string[] remoteFiles);
        int DownloadDirectory(string localFolder, string remoteFolder);
        bool IsFileExists(string remoteFilepath);
        bool DirectoryExists(string remoteDirPath);
        int DeleteFile(string path);
        int DeleteDirectory(string path);
        int ExecuteFTPCommand(string cmd, out string reply);
    }
}
