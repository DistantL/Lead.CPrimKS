﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lead.CPrim.Interfaces.SensorSmartRay
{
    public interface ISensorSmartRay
    {
        string ProductName { set; get; }
        /// <summary>
        ///     清除传感器数据
        /// </summary>
        int ClearBatch();

        /// <summary>
        ///     拿取数据
        /// </summary>
        /// <returns></returns>
        List<List<ProfilePoint>> GetBatch();

        /// <summary>
        ///     获取数据数量
        /// </summary>
        /// <returns></returns>
        int GetBatchCount();

        /// <summary>
        ///     ushort数组转换profile
        /// </summary>
        /// <param name="packages"></param>
        /// <returns></returns>
        List<List<ProfilePoint>> GetPointfromProfile(ushort[] packages);

        /// <summary>
        ///     设置触发数量
        /// </summary>
        /// <param name="numofprofile"></param>
        /// <returns></returns>
        int SetTriggerNum(uint numofprofile);

        /// <summary>
        ///     开始采集
        /// </summary>
        /// <returns></returns>
        int StartAcquisitiont();
        /// <summary>
        /// 结束采集
        /// </summary>
        /// <returns>System.Int32.</returns>
        int StopAcquisitiont();
    }

    [Serializable]
    public class ProfilePoint
    {
        public double x;
        public double y;
        public double z;
    }

    public class SensorInfo
    {
        /// <summary>
        ///     配置文件名
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        ///     路径
        /// </summary>
        public string FilePath { get; set; }

        public int ImageLength { get; set; }

        /// <summary>
        ///     线宽度
        /// </summary>
        public int ImageWidth { get; set; }

        /// <summary>
        ///     index
        /// </summary>
        public int Index { get; set; } = 1;

        /// <summary>
        ///     IP
        /// </summary>
        public string IP { get; set; } = "192.168.178.200";

        /// <summary>
        ///     名字
        /// </summary>
        public string Name { get; set; } = "sensor0";

        public int Orgx { get; set; }

        public int Orgy { get; set; }

        /// <summary>
        ///     触发间距
        /// </summary>
        public double Pitch { get; set; }

        /// <summary>
        ///     Port
        /// </summary>
        public ushort Port { get; set; } = 40;

        /// <summary>
        ///     触发数量
        /// </summary>
        public int TrigNum { get; set; }

        public float Yres { get; set; }
        public float Zres { get; set; }
    }
}
