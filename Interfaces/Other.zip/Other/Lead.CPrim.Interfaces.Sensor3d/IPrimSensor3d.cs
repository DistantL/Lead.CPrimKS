﻿using System.Collections.Generic;
using CommonStruct.Type3D;

namespace Lead.CPrim.Interfaces.Sensor3d
{
    /// <summary>
    /// 用于3D传感器的通用接口
    /// </summary>
    public interface IPrimSensor3d
    {
        /// <summary>
        /// 开始测量
        /// </summary>
        /// <param name="deviceId">传感器Id，默认为0</param>
        /// <returns></returns>
        int StartMeasure(int deviceId = 0);
        /// <summary>
        /// 结束测量
        /// </summary>
        /// <param name="deviceId">传感器Id，默认为0</param>
        /// <returns></returns>
        int StopMeasure(int deviceId = 0);
        /// <summary>
        /// 获取当前传感器批量处理的点位集合
        /// </summary>
        /// <param name="yPoses">Y向坐标集合</param>
        /// <param name="deviceId">传感器Id，默认为0</param>
        /// <param name="isMirror">X向是否镜像</param>
        /// <param name="layerIndex">层数</param>
        /// <returns></returns>
        List<List<PointFS>> GetBatchData(List<double> yPoses, int deviceId = 0, bool isMirror = false, int layerIndex = 0);
        /// <summary>
        /// 获取当前传感器批量处理的点位集合（高速方式）
        /// </summary>
        /// <param name="yPoses">Y向坐标集合</param>
        /// <param name="deviceId">传感器Id，默认为0</param>
        /// <param name="isMirror">X向是否镜像</param>
        /// <param name="layerIndex">层数</param>
        /// <returns></returns>
        XDPOINT[,] GetBatchArrayData(List<double> yPoses, int deviceId = 0, bool isMirror = false, int layerIndex = 0);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="startIndex">起始序号</param>
        /// <param name="linesCount">需求线的数量</param>
        /// <param name="yPoses">Y向坐标集合</param>
        /// <param name="deviceId">传感器Id，默认为0</param>
        /// <param name="isMirror">X向是否镜像</param>
        /// <param name="layerIndex">层数</param>
        /// <returns></returns>
        XDPOINT[,] GetBatchArrayData(int startIndex, int linesCount, List<double> yPoses, int deviceId = 0, bool isMirror = false, int layerIndex = 0);
        /// <summary>
        /// 获取当前传感器批量处理的点位集合
        /// </summary>
        /// <param name="zValues">获取到的Z值集合</param>
        /// <param name="intensityValues">获取到的Intensity值集合</param>
        /// <param name="deviceId">传感器Id，默认为0</param>
        /// <param name="layerIndex">层数</param>
        /// <returns>点位集合个数</returns>n
        int GetBatchData(out List<List<double>> zValues, out List<List<int>> intensityValues, int deviceId = 0, int layerIndex = 0);
        /// <summary>
        /// 获取当前传感器批量处理的点位集合大小
        /// </summary>
        /// <param name="deviceId">传感器Id，默认为0</param>
        /// <returns></returns>
        int GetBatchDataCount(int deviceId = 0);
        /// <summary>
        /// 清除内存中存储的已获取到的点位集合
        /// </summary>
        /// <param name="deviceId">传感器Id，默认为0</param>
        /// <returns></returns>
        int ClearBatchData(int deviceId = 0);
        /// <summary>
        /// 清除传感器报警
        /// </summary>
        /// <param name="deviceId">传感器Id，默认为0</param>
        /// <returns></returns>
        int ResetAlarm(int deviceId = 0);
        /// <summary>
        /// 更改传感器控制器运行的当前配方
        /// </summary>
        /// <param name="productType">配方值</param>
        /// <param name="deviceId">传感器Id，默认为0</param>
        /// <returns></returns>
        int ChangeActiveJob(object productType, int deviceId = 0);
        /// <summary>
        /// 设定传感器的点间距
        /// </summary>
        /// <param name="interval">点间距值</param>
        /// <param name="deviceId">传感器Id，默认为0</param>
        /// <returns></returns>
        int SetIntervalValueOfPoint(double interval, int deviceId = 0);

    }
}
