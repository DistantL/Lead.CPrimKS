﻿using System.Xml;

namespace Lead.CPrim.Interfaces
{
    public interface IGuiCreator
    {
        IGuiTypeAttributes ConcreteGuiTypeAttributes { get; }

        IGui Create();

        IGui Create(XmlNode guiConfig);
    }
}