﻿using System;
using System.Windows.Forms;
using System.Xml;

namespace Lead.CPrim.Interfaces
{
    public interface IGui
    {
        Control GuiConfigUI { get; }
        Control GuiDebugUI { get; }
        bool GuiEnable { set; get; }
        Control GuiOutputUI { get; }
        string GuiTypeName { set; get; }
        Guid Id { set; get; }
        string Name { set; get; }
        string Ver { set; get; }

        int IGuiDispose();

        XmlNode IGuiExportDataConfigXml();

        int IGuiImportConfigXml(XmlNode xmlNode);

        int IGuiImportDataConfigXml(XmlNode xmlNode);

        int IGuiInit();

        int IGuiStart();

        int IGuiStop();

        XmlNode IPrimExportConfigXml();
    }
}