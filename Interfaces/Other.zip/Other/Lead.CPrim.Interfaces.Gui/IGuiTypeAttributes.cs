﻿using System.Collections.Generic;
using System.Drawing;

namespace Lead.CPrim.Interfaces
{
    public interface IGuiTypeAttributes
    {
        IEnumerable<KeyValuePair<string, object>> Attributes { get; }
        string Description { get; }
        string DisplayGroup { get; }
        string DisplayName { get; }
        string Group { get; }
        Image Icon { get; }
        byte MajorVersion { get; }
        byte MinorVersion { get; }
        string Name { get; }
        object this[string attrName] { get; }
    }
}