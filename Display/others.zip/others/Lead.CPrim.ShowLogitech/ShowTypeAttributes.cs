﻿using System.Drawing;
using System.Resources;
using Lead.CPrim.Interfaces;

namespace Lead.CPrim.ShowLogitech
{
    public class ShowTypeAttributes : IShowTypeAttributes
    {
        public string Description => "Show for Logitech";
        public string DisplayGroup => "Logitech";
        public string DisplayName => "Logitech";
        public string Group => "Logitech";

        public Image Icon
        {
            get
            {
                var manager = new ResourceManager(typeof(ResourceDefault));
                return (Image) manager.GetObject("Default");
            }
        }

        public byte MajorVersion => 1;
        public byte MinorVersion => 0;
        public string Name => "Logitech";
    }
}