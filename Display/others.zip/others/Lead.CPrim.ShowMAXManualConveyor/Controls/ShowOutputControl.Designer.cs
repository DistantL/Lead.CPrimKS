﻿namespace Lead.CPrim.ShowMAXManualConveyor.Controls
{
    partial class ShowOutputControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tbStationInfo = new System.Windows.Forms.TextBox();
            this.tbRtUpState = new System.Windows.Forms.TextBox();
            this.tbRtUpStepInfo = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbUpCt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.panelUpConveyor = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tbUpPart23 = new System.Windows.Forms.TextBox();
            this.tbUpPart25 = new System.Windows.Forms.TextBox();
            this.tbUpPart24 = new System.Windows.Forms.TextBox();
            this.tbUpPart21 = new System.Windows.Forms.TextBox();
            this.tbUpPart26 = new System.Windows.Forms.TextBox();
            this.tbUpTrayId2 = new System.Windows.Forms.TextBox();
            this.tbUpPart22 = new System.Windows.Forms.TextBox();
            this.tablePanelUpTray1 = new System.Windows.Forms.TableLayoutPanel();
            this.tbUpPart13 = new System.Windows.Forms.TextBox();
            this.tbUpPart15 = new System.Windows.Forms.TextBox();
            this.tbUpPart14 = new System.Windows.Forms.TextBox();
            this.tbUpPart11 = new System.Windows.Forms.TextBox();
            this.tbUpPart16 = new System.Windows.Forms.TextBox();
            this.tbUpTrayId1 = new System.Windows.Forms.TextBox();
            this.tbUpPart12 = new System.Windows.Forms.TextBox();
            this.tbNumUph = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbNumNg = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbNumOk = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbDownCt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panelDownConveyor = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tbDownPart13 = new System.Windows.Forms.TextBox();
            this.tbDownPart15 = new System.Windows.Forms.TextBox();
            this.tbDownPart14 = new System.Windows.Forms.TextBox();
            this.tbDownPart11 = new System.Windows.Forms.TextBox();
            this.tbDownPart16 = new System.Windows.Forms.TextBox();
            this.tbDownTrayId1 = new System.Windows.Forms.TextBox();
            this.tbDownPart12 = new System.Windows.Forms.TextBox();
            this.tbRtDownStepInfo = new System.Windows.Forms.TextBox();
            this.tbRtDownState = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panelUpConveyor.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tablePanelUpTray1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panelDownConveyor.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbStationInfo
            // 
            this.tbStationInfo.BackColor = System.Drawing.Color.LightSalmon;
            this.tbStationInfo.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.tbStationInfo.Location = new System.Drawing.Point(108, 17);
            this.tbStationInfo.Name = "tbStationInfo";
            this.tbStationInfo.ReadOnly = true;
            this.tbStationInfo.Size = new System.Drawing.Size(432, 29);
            this.tbStationInfo.TabIndex = 0;
            this.tbStationInfo.Text = "2 Manual - Top housing manual loading";
            this.tbStationInfo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbRtUpState
            // 
            this.tbRtUpState.BackColor = System.Drawing.Color.LimeGreen;
            this.tbRtUpState.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.tbRtUpState.Location = new System.Drawing.Point(104, 3);
            this.tbRtUpState.Name = "tbRtUpState";
            this.tbRtUpState.ReadOnly = true;
            this.tbRtUpState.Size = new System.Drawing.Size(53, 29);
            this.tbRtUpState.TabIndex = 1;
            this.tbRtUpState.Text = "Run";
            this.tbRtUpState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbRtUpStepInfo
            // 
            this.tbRtUpStepInfo.BackColor = System.Drawing.Color.LimeGreen;
            this.tbRtUpStepInfo.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.tbRtUpStepInfo.Location = new System.Drawing.Point(175, 3);
            this.tbRtUpStepInfo.Name = "tbRtUpStepInfo";
            this.tbRtUpStepInfo.ReadOnly = true;
            this.tbRtUpStepInfo.Size = new System.Drawing.Size(404, 29);
            this.tbRtUpStepInfo.TabIndex = 2;
            this.tbRtUpStepInfo.Text = "Step 1:Check ID";
            this.tbRtUpStepInfo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.tbUpCt);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.textBox15);
            this.panel1.Controls.Add(this.textBox16);
            this.panel1.Controls.Add(this.textBox7);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.panelUpConveyor);
            this.panel1.Controls.Add(this.tbNumUph);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.tbNumNg);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.tbNumOk);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.tbRtUpStepInfo);
            this.panel1.Controls.Add(this.tbRtUpState);
            this.panel1.Location = new System.Drawing.Point(3, 66);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(658, 306);
            this.panel1.TabIndex = 3;
            // 
            // tbUpCt
            // 
            this.tbUpCt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbUpCt.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbUpCt.ForeColor = System.Drawing.Color.LimeGreen;
            this.tbUpCt.Location = new System.Drawing.Point(595, 45);
            this.tbUpCt.Name = "tbUpCt";
            this.tbUpCt.Size = new System.Drawing.Size(48, 18);
            this.tbUpCt.TabIndex = 15;
            this.tbUpCt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.label4.ForeColor = System.Drawing.Color.LimeGreen;
            this.label4.Location = new System.Drawing.Point(561, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "CT:";
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.Color.LightGray;
            this.textBox15.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox15.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.textBox15.ForeColor = System.Drawing.Color.DodgerBlue;
            this.textBox15.Location = new System.Drawing.Point(426, 255);
            this.textBox15.Multiline = true;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(65, 41);
            this.textBox15.TabIndex = 13;
            this.textBox15.Text = " 口\r\nHuman2";
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.Color.LightGray;
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox16.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.textBox16.ForeColor = System.Drawing.Color.DodgerBlue;
            this.textBox16.Location = new System.Drawing.Point(155, 255);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(65, 41);
            this.textBox16.TabIndex = 12;
            this.textBox16.Text = " 口\r\nHuman1";
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.LightGray;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.textBox7.ForeColor = System.Drawing.Color.DodgerBlue;
            this.textBox7.Location = new System.Drawing.Point(426, 99);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(65, 41);
            this.textBox7.TabIndex = 11;
            this.textBox7.Text = " 口\r\nHuman4";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.LightGray;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.textBox6.ForeColor = System.Drawing.Color.DodgerBlue;
            this.textBox6.Location = new System.Drawing.Point(155, 99);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(65, 41);
            this.textBox6.TabIndex = 10;
            this.textBox6.Text = " 口\r\nHuman3";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panelUpConveyor
            // 
            this.panelUpConveyor.BackColor = System.Drawing.Color.PaleGreen;
            this.panelUpConveyor.Controls.Add(this.tableLayoutPanel1);
            this.panelUpConveyor.Controls.Add(this.tablePanelUpTray1);
            this.panelUpConveyor.Location = new System.Drawing.Point(11, 146);
            this.panelUpConveyor.Name = "panelUpConveyor";
            this.panelUpConveyor.Size = new System.Drawing.Size(632, 103);
            this.panelUpConveyor.TabIndex = 9;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel1.Controls.Add(this.tbUpPart23, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tbUpPart25, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tbUpPart24, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tbUpPart21, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tbUpPart26, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tbUpTrayId2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tbUpPart22, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(336, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.22222F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(235, 97);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // tbUpPart23
            // 
            this.tbUpPart23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpPart23.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbUpPart23.ForeColor = System.Drawing.Color.Blue;
            this.tbUpPart23.Location = new System.Drawing.Point(157, 34);
            this.tbUpPart23.Name = "tbUpPart23";
            this.tbUpPart23.Size = new System.Drawing.Size(75, 25);
            this.tbUpPart23.TabIndex = 11;
            this.tbUpPart23.Text = "ID";
            this.tbUpPart23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbUpPart25
            // 
            this.tbUpPart25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpPart25.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbUpPart25.ForeColor = System.Drawing.Color.Blue;
            this.tbUpPart25.Location = new System.Drawing.Point(80, 69);
            this.tbUpPart25.Name = "tbUpPart25";
            this.tbUpPart25.Size = new System.Drawing.Size(71, 25);
            this.tbUpPart25.TabIndex = 10;
            this.tbUpPart25.Text = "ID";
            this.tbUpPart25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbUpPart24
            // 
            this.tbUpPart24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpPart24.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbUpPart24.ForeColor = System.Drawing.Color.Blue;
            this.tbUpPart24.Location = new System.Drawing.Point(3, 69);
            this.tbUpPart24.Name = "tbUpPart24";
            this.tbUpPart24.Size = new System.Drawing.Size(71, 25);
            this.tbUpPart24.TabIndex = 9;
            this.tbUpPart24.Text = "ID";
            this.tbUpPart24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbUpPart21
            // 
            this.tbUpPart21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpPart21.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbUpPart21.ForeColor = System.Drawing.Color.Blue;
            this.tbUpPart21.Location = new System.Drawing.Point(3, 34);
            this.tbUpPart21.Name = "tbUpPart21";
            this.tbUpPart21.Size = new System.Drawing.Size(71, 25);
            this.tbUpPart21.TabIndex = 8;
            this.tbUpPart21.Text = "ID";
            this.tbUpPart21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbUpPart26
            // 
            this.tbUpPart26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpPart26.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbUpPart26.ForeColor = System.Drawing.Color.Blue;
            this.tbUpPart26.Location = new System.Drawing.Point(157, 69);
            this.tbUpPart26.Name = "tbUpPart26";
            this.tbUpPart26.Size = new System.Drawing.Size(75, 25);
            this.tbUpPart26.TabIndex = 7;
            this.tbUpPart26.Text = "ID";
            this.tbUpPart26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbUpTrayId2
            // 
            this.tbUpTrayId2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tableLayoutPanel1.SetColumnSpan(this.tbUpTrayId2, 3);
            this.tbUpTrayId2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpTrayId2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.tbUpTrayId2.ForeColor = System.Drawing.Color.LimeGreen;
            this.tbUpTrayId2.Location = new System.Drawing.Point(3, 3);
            this.tbUpTrayId2.Name = "tbUpTrayId2";
            this.tbUpTrayId2.Size = new System.Drawing.Size(229, 22);
            this.tbUpTrayId2.TabIndex = 5;
            this.tbUpTrayId2.Text = "TrayID";
            this.tbUpTrayId2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbUpPart22
            // 
            this.tbUpPart22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpPart22.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbUpPart22.ForeColor = System.Drawing.Color.Blue;
            this.tbUpPart22.Location = new System.Drawing.Point(80, 34);
            this.tbUpPart22.Name = "tbUpPart22";
            this.tbUpPart22.Size = new System.Drawing.Size(71, 25);
            this.tbUpPart22.TabIndex = 6;
            this.tbUpPart22.Text = "ID";
            this.tbUpPart22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tablePanelUpTray1
            // 
            this.tablePanelUpTray1.ColumnCount = 3;
            this.tablePanelUpTray1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tablePanelUpTray1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tablePanelUpTray1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tablePanelUpTray1.Controls.Add(this.tbUpPart13, 0, 1);
            this.tablePanelUpTray1.Controls.Add(this.tbUpPart15, 0, 2);
            this.tablePanelUpTray1.Controls.Add(this.tbUpPart14, 0, 2);
            this.tablePanelUpTray1.Controls.Add(this.tbUpPart11, 0, 1);
            this.tablePanelUpTray1.Controls.Add(this.tbUpPart16, 0, 2);
            this.tablePanelUpTray1.Controls.Add(this.tbUpTrayId1, 0, 0);
            this.tablePanelUpTray1.Controls.Add(this.tbUpPart12, 0, 1);
            this.tablePanelUpTray1.Location = new System.Drawing.Point(63, 3);
            this.tablePanelUpTray1.Name = "tablePanelUpTray1";
            this.tablePanelUpTray1.RowCount = 3;
            this.tablePanelUpTray1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.22222F));
            this.tablePanelUpTray1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.66667F));
            this.tablePanelUpTray1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tablePanelUpTray1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tablePanelUpTray1.Size = new System.Drawing.Size(235, 97);
            this.tablePanelUpTray1.TabIndex = 0;
            // 
            // tbUpPart13
            // 
            this.tbUpPart13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpPart13.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbUpPart13.ForeColor = System.Drawing.Color.Blue;
            this.tbUpPart13.Location = new System.Drawing.Point(157, 34);
            this.tbUpPart13.Name = "tbUpPart13";
            this.tbUpPart13.Size = new System.Drawing.Size(75, 25);
            this.tbUpPart13.TabIndex = 11;
            this.tbUpPart13.Text = "ID";
            this.tbUpPart13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbUpPart15
            // 
            this.tbUpPart15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpPart15.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbUpPart15.ForeColor = System.Drawing.Color.Blue;
            this.tbUpPart15.Location = new System.Drawing.Point(80, 69);
            this.tbUpPart15.Name = "tbUpPart15";
            this.tbUpPart15.Size = new System.Drawing.Size(71, 25);
            this.tbUpPart15.TabIndex = 10;
            this.tbUpPart15.Text = "ID";
            this.tbUpPart15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbUpPart14
            // 
            this.tbUpPart14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpPart14.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbUpPart14.ForeColor = System.Drawing.Color.Blue;
            this.tbUpPart14.Location = new System.Drawing.Point(3, 69);
            this.tbUpPart14.Name = "tbUpPart14";
            this.tbUpPart14.Size = new System.Drawing.Size(71, 25);
            this.tbUpPart14.TabIndex = 9;
            this.tbUpPart14.Text = "ID";
            this.tbUpPart14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbUpPart11
            // 
            this.tbUpPart11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpPart11.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbUpPart11.ForeColor = System.Drawing.Color.Blue;
            this.tbUpPart11.Location = new System.Drawing.Point(3, 34);
            this.tbUpPart11.Name = "tbUpPart11";
            this.tbUpPart11.Size = new System.Drawing.Size(71, 25);
            this.tbUpPart11.TabIndex = 8;
            this.tbUpPart11.Text = "ID";
            this.tbUpPart11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbUpPart16
            // 
            this.tbUpPart16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpPart16.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbUpPart16.ForeColor = System.Drawing.Color.Blue;
            this.tbUpPart16.Location = new System.Drawing.Point(157, 69);
            this.tbUpPart16.Name = "tbUpPart16";
            this.tbUpPart16.Size = new System.Drawing.Size(75, 25);
            this.tbUpPart16.TabIndex = 7;
            this.tbUpPart16.Text = "ID";
            this.tbUpPart16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbUpTrayId1
            // 
            this.tbUpTrayId1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tablePanelUpTray1.SetColumnSpan(this.tbUpTrayId1, 3);
            this.tbUpTrayId1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpTrayId1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.tbUpTrayId1.ForeColor = System.Drawing.Color.LimeGreen;
            this.tbUpTrayId1.Location = new System.Drawing.Point(3, 3);
            this.tbUpTrayId1.Name = "tbUpTrayId1";
            this.tbUpTrayId1.Size = new System.Drawing.Size(229, 22);
            this.tbUpTrayId1.TabIndex = 5;
            this.tbUpTrayId1.Text = "TrayID";
            this.tbUpTrayId1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbUpPart12
            // 
            this.tbUpPart12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbUpPart12.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbUpPart12.ForeColor = System.Drawing.Color.Blue;
            this.tbUpPart12.Location = new System.Drawing.Point(80, 34);
            this.tbUpPart12.Name = "tbUpPart12";
            this.tbUpPart12.Size = new System.Drawing.Size(71, 25);
            this.tbUpPart12.TabIndex = 6;
            this.tbUpPart12.Text = "ID";
            this.tbUpPart12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbNumUph
            // 
            this.tbNumUph.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbNumUph.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbNumUph.ForeColor = System.Drawing.Color.LimeGreen;
            this.tbNumUph.Location = new System.Drawing.Point(54, 92);
            this.tbNumUph.Name = "tbNumUph";
            this.tbNumUph.Size = new System.Drawing.Size(38, 18);
            this.tbNumUph.TabIndex = 8;
            this.tbNumUph.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.label3.ForeColor = System.Drawing.Color.LimeGreen;
            this.label3.Location = new System.Drawing.Point(5, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "UPH:";
            // 
            // tbNumNg
            // 
            this.tbNumNg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbNumNg.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbNumNg.ForeColor = System.Drawing.Color.Red;
            this.tbNumNg.Location = new System.Drawing.Point(53, 61);
            this.tbNumNg.Name = "tbNumNg";
            this.tbNumNg.Size = new System.Drawing.Size(38, 18);
            this.tbNumNg.TabIndex = 6;
            this.tbNumNg.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(4, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "NG:";
            // 
            // tbNumOk
            // 
            this.tbNumOk.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbNumOk.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbNumOk.ForeColor = System.Drawing.Color.LimeGreen;
            this.tbNumOk.Location = new System.Drawing.Point(53, 31);
            this.tbNumOk.Name = "tbNumOk";
            this.tbNumOk.Size = new System.Drawing.Size(38, 18);
            this.tbNumOk.TabIndex = 4;
            this.tbNumOk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.label1.ForeColor = System.Drawing.Color.LimeGreen;
            this.label1.Location = new System.Drawing.Point(4, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "OK:";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.tbDownCt);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.panelDownConveyor);
            this.panel3.Controls.Add(this.tbRtDownStepInfo);
            this.panel3.Controls.Add(this.tbRtDownState);
            this.panel3.Location = new System.Drawing.Point(3, 378);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(658, 198);
            this.panel3.TabIndex = 4;
            // 
            // tbDownCt
            // 
            this.tbDownCt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbDownCt.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbDownCt.ForeColor = System.Drawing.Color.LimeGreen;
            this.tbDownCt.Location = new System.Drawing.Point(595, 45);
            this.tbDownCt.Name = "tbDownCt";
            this.tbDownCt.Size = new System.Drawing.Size(48, 18);
            this.tbDownCt.TabIndex = 15;
            this.tbDownCt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.label5.ForeColor = System.Drawing.Color.LimeGreen;
            this.label5.Location = new System.Drawing.Point(561, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 20);
            this.label5.TabIndex = 14;
            this.label5.Text = "CT:";
            // 
            // panelDownConveyor
            // 
            this.panelDownConveyor.BackColor = System.Drawing.Color.PaleGreen;
            this.panelDownConveyor.Controls.Add(this.tableLayoutPanel2);
            this.panelDownConveyor.Location = new System.Drawing.Point(11, 80);
            this.panelDownConveyor.Name = "panelDownConveyor";
            this.panelDownConveyor.Size = new System.Drawing.Size(632, 103);
            this.panelDownConveyor.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34F));
            this.tableLayoutPanel2.Controls.Add(this.tbDownPart13, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.tbDownPart15, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.tbDownPart14, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.tbDownPart11, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.tbDownPart16, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.tbDownTrayId1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tbDownPart12, 0, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(220, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.22222F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(235, 97);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tbDownPart13
            // 
            this.tbDownPart13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbDownPart13.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbDownPart13.ForeColor = System.Drawing.Color.Blue;
            this.tbDownPart13.Location = new System.Drawing.Point(157, 34);
            this.tbDownPart13.Name = "tbDownPart13";
            this.tbDownPart13.Size = new System.Drawing.Size(75, 25);
            this.tbDownPart13.TabIndex = 11;
            this.tbDownPart13.Text = "ID";
            this.tbDownPart13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbDownPart15
            // 
            this.tbDownPart15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbDownPart15.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbDownPart15.ForeColor = System.Drawing.Color.Blue;
            this.tbDownPart15.Location = new System.Drawing.Point(80, 69);
            this.tbDownPart15.Name = "tbDownPart15";
            this.tbDownPart15.Size = new System.Drawing.Size(71, 25);
            this.tbDownPart15.TabIndex = 10;
            this.tbDownPart15.Text = "ID";
            this.tbDownPart15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbDownPart14
            // 
            this.tbDownPart14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbDownPart14.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbDownPart14.ForeColor = System.Drawing.Color.Blue;
            this.tbDownPart14.Location = new System.Drawing.Point(3, 69);
            this.tbDownPart14.Name = "tbDownPart14";
            this.tbDownPart14.Size = new System.Drawing.Size(71, 25);
            this.tbDownPart14.TabIndex = 9;
            this.tbDownPart14.Text = "ID";
            this.tbDownPart14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbDownPart11
            // 
            this.tbDownPart11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbDownPart11.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbDownPart11.ForeColor = System.Drawing.Color.Blue;
            this.tbDownPart11.Location = new System.Drawing.Point(3, 34);
            this.tbDownPart11.Name = "tbDownPart11";
            this.tbDownPart11.Size = new System.Drawing.Size(71, 25);
            this.tbDownPart11.TabIndex = 8;
            this.tbDownPart11.Text = "ID";
            this.tbDownPart11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbDownPart16
            // 
            this.tbDownPart16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbDownPart16.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbDownPart16.ForeColor = System.Drawing.Color.Blue;
            this.tbDownPart16.Location = new System.Drawing.Point(157, 69);
            this.tbDownPart16.Name = "tbDownPart16";
            this.tbDownPart16.Size = new System.Drawing.Size(75, 25);
            this.tbDownPart16.TabIndex = 7;
            this.tbDownPart16.Text = "ID";
            this.tbDownPart16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbDownTrayId1
            // 
            this.tbDownTrayId1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tableLayoutPanel2.SetColumnSpan(this.tbDownTrayId1, 3);
            this.tbDownTrayId1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbDownTrayId1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.tbDownTrayId1.ForeColor = System.Drawing.Color.LimeGreen;
            this.tbDownTrayId1.Location = new System.Drawing.Point(3, 3);
            this.tbDownTrayId1.Name = "tbDownTrayId1";
            this.tbDownTrayId1.Size = new System.Drawing.Size(229, 22);
            this.tbDownTrayId1.TabIndex = 5;
            this.tbDownTrayId1.Text = "TrayID";
            this.tbDownTrayId1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbDownPart12
            // 
            this.tbDownPart12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbDownPart12.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.tbDownPart12.ForeColor = System.Drawing.Color.Blue;
            this.tbDownPart12.Location = new System.Drawing.Point(80, 34);
            this.tbDownPart12.Name = "tbDownPart12";
            this.tbDownPart12.Size = new System.Drawing.Size(71, 25);
            this.tbDownPart12.TabIndex = 6;
            this.tbDownPart12.Text = "ID";
            this.tbDownPart12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbRtDownStepInfo
            // 
            this.tbRtDownStepInfo.BackColor = System.Drawing.Color.LimeGreen;
            this.tbRtDownStepInfo.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.tbRtDownStepInfo.Location = new System.Drawing.Point(175, 3);
            this.tbRtDownStepInfo.Name = "tbRtDownStepInfo";
            this.tbRtDownStepInfo.ReadOnly = true;
            this.tbRtDownStepInfo.Size = new System.Drawing.Size(404, 29);
            this.tbRtDownStepInfo.TabIndex = 2;
            this.tbRtDownStepInfo.Text = "Step 1:Check ID";
            this.tbRtDownStepInfo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbRtDownState
            // 
            this.tbRtDownState.BackColor = System.Drawing.Color.LimeGreen;
            this.tbRtDownState.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.tbRtDownState.Location = new System.Drawing.Point(104, 3);
            this.tbRtDownState.Name = "tbRtDownState";
            this.tbRtDownState.ReadOnly = true;
            this.tbRtDownState.Size = new System.Drawing.Size(53, 29);
            this.tbRtDownState.TabIndex = 1;
            this.tbRtDownState.Text = "Run";
            this.tbRtDownState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ShowOutputControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tbStationInfo);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ShowOutputControl";
            this.Size = new System.Drawing.Size(664, 589);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelUpConveyor.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tablePanelUpTray1.ResumeLayout(false);
            this.tablePanelUpTray1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panelDownConveyor.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbStationInfo;
        private System.Windows.Forms.TextBox tbRtUpState;
        private System.Windows.Forms.TextBox tbRtUpStepInfo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tbUpCt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Panel panelUpConveyor;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox tbUpPart23;
        private System.Windows.Forms.TextBox tbUpPart25;
        private System.Windows.Forms.TextBox tbUpPart24;
        private System.Windows.Forms.TextBox tbUpPart21;
        private System.Windows.Forms.TextBox tbUpPart26;
        private System.Windows.Forms.TextBox tbUpTrayId2;
        private System.Windows.Forms.TextBox tbUpPart22;
        private System.Windows.Forms.TableLayoutPanel tablePanelUpTray1;
        private System.Windows.Forms.TextBox tbUpPart13;
        private System.Windows.Forms.TextBox tbUpPart15;
        private System.Windows.Forms.TextBox tbUpPart14;
        private System.Windows.Forms.TextBox tbUpPart11;
        private System.Windows.Forms.TextBox tbUpPart16;
        private System.Windows.Forms.TextBox tbUpTrayId1;
        private System.Windows.Forms.TextBox tbUpPart12;
        private System.Windows.Forms.TextBox tbNumUph;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbNumNg;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbNumOk;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tbDownCt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panelDownConveyor;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox tbDownPart13;
        private System.Windows.Forms.TextBox tbDownPart15;
        private System.Windows.Forms.TextBox tbDownPart14;
        private System.Windows.Forms.TextBox tbDownPart11;
        private System.Windows.Forms.TextBox tbDownPart16;
        private System.Windows.Forms.TextBox tbDownTrayId1;
        private System.Windows.Forms.TextBox tbDownPart12;
        private System.Windows.Forms.TextBox tbRtDownStepInfo;
        private System.Windows.Forms.TextBox tbRtDownState;
    }
}
