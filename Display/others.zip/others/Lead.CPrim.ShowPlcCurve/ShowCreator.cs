﻿using Lead.CPrim.Interfaces;
using System.Xml;

namespace Lead.CPrim.ShowPlcCurve
{
    public class ShowCreator : IShowCreator
    {
        public IShowTypeAttributes ConcreteShowTypeAttributes => new ShowTypeAttributes();
        public IShow Create()
        {
            return new ShowPlcCurve();
        }
        public IShow Create(XmlNode showConfig)
        {
            return new ShowPlcCurve(showConfig);
        }
    }
}
