﻿/******************************************************************************
 * CPrim
 * CopyRight (C) 2020-2030.
 * FileName: ShowAtlasCurveConfig.cs
 * Author: Victor
 * Description: Atlas 配置管理类
 * CreateTime: 2022-09-13
 * 
 * If you use this code, please keep this note.
 * 如果您使用此代码，请保留此说明。
 ******************************************************************************
 * 版本迭代说明&修改记录
 * 3.3.22.0904 -> 
 * <Author> (Victor)    <Time> (20220913)
 * 1、初版1.0
******************************************************************************/

using System;

namespace Lead.CPrim.ShowPlcCurve
{
    /// <summary>压力曲线配置</summary>
    public class ShowPlcCurveConfig
    {
        #region Ctor无参
        public ShowPlcCurveConfig()
        {
            
        } 
        #endregion



        #region Define
        public int ChartNum { get; set; }
        public string  PlcPath { get; set; }
        public string PlcPath2 { get; set; }
        #endregion



        #region Override IPrim
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string ShowTypeName { get; set; }
        public bool Enable { get; set; }
        public string Version { get; set; }
        #endregion
    }
}
