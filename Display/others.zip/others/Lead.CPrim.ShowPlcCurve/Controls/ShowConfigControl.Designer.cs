﻿using Lead.CPrim.ProxyTools.SunnyUI.Controls;

namespace Lead.CPrim.ShowPlcCurve.Controls
{
    partial class ShowConfigControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnApply = new System.Windows.Forms.Button();
            this.cbChartNum = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.uiUserControl1 = new Lead.CPrim.ProxyTools.SunnyUI.Controls.UIUserControl();
            this.txtPlcPath = new Lead.CPrim.ProxyTools.SunnyUI.Controls.UITextBox();
            this.btnSavePath = new Lead.CPrim.ProxyTools.SunnyUI.Controls.UISymbolButton();
            this.lblName = new Lead.CPrim.ProxyTools.SunnyUI.Controls.UILabel();
            this.uiLabel1 = new Lead.CPrim.ProxyTools.SunnyUI.Controls.UILabel();
            this.txtPlcPath2 = new Lead.CPrim.ProxyTools.SunnyUI.Controls.UITextBox();
            this.btnSavePath2 = new Lead.CPrim.ProxyTools.SunnyUI.Controls.UISymbolButton();
            this.uiLabel2 = new Lead.CPrim.ProxyTools.SunnyUI.Controls.UILabel();
            this.uiUserControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnApply
            // 
            this.btnApply.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnApply.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnApply.Location = new System.Drawing.Point(0, 360);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(750, 35);
            this.btnApply.TabIndex = 4;
            this.btnApply.Text = "Apply";
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // cbChartNum
            // 
            this.cbChartNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbChartNum.FormattingEnabled = true;
            this.cbChartNum.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.cbChartNum.Location = new System.Drawing.Point(163, 41);
            this.cbChartNum.Name = "cbChartNum";
            this.cbChartNum.Size = new System.Drawing.Size(165, 35);
            this.cbChartNum.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(19, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 27);
            this.label2.TabIndex = 7;
            this.label2.Text = "曲线显示数量";
            // 
            // uiUserControl1
            // 
            this.uiUserControl1.Controls.Add(this.label2);
            this.uiUserControl1.Controls.Add(this.cbChartNum);
            this.uiUserControl1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiUserControl1.Location = new System.Drawing.Point(15, 48);
            this.uiUserControl1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiUserControl1.Name = "uiUserControl1";
            this.uiUserControl1.Radius = 10;
            this.uiUserControl1.Size = new System.Drawing.Size(350, 199);
            this.uiUserControl1.TabIndex = 15;
            this.uiUserControl1.Text = "uiUserControl1";
            this.uiUserControl1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiUserControl1.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // txtPlcPath
            // 
            this.txtPlcPath.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPlcPath.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtPlcPath.Location = new System.Drawing.Point(103, 272);
            this.txtPlcPath.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPlcPath.MinimumSize = new System.Drawing.Size(1, 16);
            this.txtPlcPath.Name = "txtPlcPath";
            this.txtPlcPath.ShowText = false;
            this.txtPlcPath.Size = new System.Drawing.Size(435, 29);
            this.txtPlcPath.TabIndex = 16;
            this.txtPlcPath.Watermark = "PLC曲线保存位置1";
            this.txtPlcPath.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // btnSavePath
            // 
            this.btnSavePath.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSavePath.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnSavePath.Location = new System.Drawing.Point(549, 269);
            this.btnSavePath.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnSavePath.Name = "btnSavePath";
            this.btnSavePath.Size = new System.Drawing.Size(38, 35);
            this.btnSavePath.Symbol = 61761;
            this.btnSavePath.TabIndex = 17;
            this.btnSavePath.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnSavePath.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.btnSavePath.Click += new System.EventHandler(this.btnSavePath_Click);
            // 
            // lblName
            // 
            this.lblName.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblName.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblName.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblName.Location = new System.Drawing.Point(0, 0);
            this.lblName.Margin = new System.Windows.Forms.Padding(1);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(750, 30);
            this.lblName.TabIndex = 19;
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblName.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // uiLabel1
            // 
            this.uiLabel1.AutoSize = true;
            this.uiLabel1.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel1.Location = new System.Drawing.Point(15, 273);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(84, 27);
            this.uiLabel1.TabIndex = 20;
            this.uiLabel1.Text = "位置1：";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiLabel1.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // txtPlcPath2
            // 
            this.txtPlcPath2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPlcPath2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtPlcPath2.Location = new System.Drawing.Point(103, 311);
            this.txtPlcPath2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPlcPath2.MinimumSize = new System.Drawing.Size(1, 16);
            this.txtPlcPath2.Name = "txtPlcPath2";
            this.txtPlcPath2.ShowText = false;
            this.txtPlcPath2.Size = new System.Drawing.Size(435, 29);
            this.txtPlcPath2.TabIndex = 16;
            this.txtPlcPath2.Watermark = "PLC曲线保存位置2";
            this.txtPlcPath2.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // btnSavePath2
            // 
            this.btnSavePath2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSavePath2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnSavePath2.Location = new System.Drawing.Point(549, 308);
            this.btnSavePath2.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnSavePath2.Name = "btnSavePath2";
            this.btnSavePath2.Size = new System.Drawing.Size(38, 35);
            this.btnSavePath2.Symbol = 61761;
            this.btnSavePath2.TabIndex = 17;
            this.btnSavePath2.TipsFont = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnSavePath2.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            this.btnSavePath2.Click += new System.EventHandler(this.btnSavePath2_Click);
            // 
            // uiLabel2
            // 
            this.uiLabel2.AutoSize = true;
            this.uiLabel2.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiLabel2.Location = new System.Drawing.Point(15, 312);
            this.uiLabel2.Name = "uiLabel2";
            this.uiLabel2.Size = new System.Drawing.Size(84, 27);
            this.uiLabel2.TabIndex = 20;
            this.uiLabel2.Text = "位置2：";
            this.uiLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiLabel2.ZoomScaleRect = new System.Drawing.Rectangle(0, 0, 0, 0);
            // 
            // ShowConfigControl
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.uiLabel2);
            this.Controls.Add(this.uiLabel1);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnSavePath2);
            this.Controls.Add(this.btnSavePath);
            this.Controls.Add(this.txtPlcPath2);
            this.Controls.Add(this.txtPlcPath);
            this.Controls.Add(this.uiUserControl1);
            this.Controls.Add(this.btnApply);
            this.Name = "ShowConfigControl";
            this.Size = new System.Drawing.Size(750, 395);
            this.Load += new System.EventHandler(this.ShowConfigControl_Load);
            this.uiUserControl1.ResumeLayout(false);
            this.uiUserControl1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnApply;
        private System.Windows.Forms.ComboBox cbChartNum;
        private System.Windows.Forms.Label label2;
        private ProxyTools.SunnyUI.Controls.UIUserControl uiUserControl1;
        private UITextBox txtPlcPath;
        private UISymbolButton btnSavePath;
        private UILabel lblName;
        private UILabel uiLabel1;
        private UITextBox txtPlcPath2;
        private UISymbolButton btnSavePath2;
        private UILabel uiLabel2;
    }
}
