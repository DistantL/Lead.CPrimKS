﻿/******************************************************************************
 * CPrim
 * CopyRight (C) 2020-2030.
 * FileName: ShowOutputControl.cs
 * Author: Victor
 * Description: config界面，对参数进行配置
 * CreateTime: 2022-09-13
 * 
 * If you use this code, please keep this note.
 * 如果您使用此代码，请保留此说明。
 ******************************************************************************
 * 版本迭代说明&修改记录
 * <3.3.22.0904><Victor><20220913>
 * 1、初版1.0
 * 
 * <3.3.22.1117><Victor><20221118>
 * 1、增加PLC曲线保存位置2
 * ******************************************************************************/

using Lead.CPrim.Interfaces;
using Lead.CPrim.ProxyTools;
using Lead.CPrim.ProxyTools.SunnyUI.Controls;
using System;

namespace Lead.CPrim.ShowPlcCurve.Controls
{
    public partial class ShowConfigControl : UIUserControl
    {
        #region Field
        /// <summary>压力曲线管理器</summary>
        private ShowPlcCurve _show;
        #endregion



        #region Ctor
        /// <summary>Ctor无参</summary>
        public ShowConfigControl(ShowPlcCurve show)
        {
            InitializeComponent();
            SetStyleFlags();
            _show = show;
        }
        #endregion



        #region System_Event
        /// <summary>Load事件</summary>
        private void ShowConfigControl_Load(object sender, EventArgs e)
        {
            cbChartNum.SelectedIndex = (_show.ChartNum == 1 || _show.ChartNum == 2 || _show.ChartNum == 3 || _show.ChartNum == 4 || _show.ChartNum == 5 || _show.ChartNum == 6) ? _show.ChartNum - 1 : -1;
            txtPlcPath.Text = _show.PlcPath;
            txtPlcPath2.Text = _show.PlcPath2;
            lblName.Text = _show.Name;
        }
        #endregion



        #region Button_Event
        /// <summary>路径保存</summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSavePath_Click(object sender, EventArgs e)
        {
            string path = txtPlcPath.Text;
            if(FileHelper.OpenFolderDialogMethod(ref path))
            {
                txtPlcPath.Text = path;
            }
        }
        private void btnSavePath2_Click(object sender, EventArgs e)
        {
            string path = txtPlcPath2.Text;
            if(FileHelper.OpenFolderDialogMethod(ref path))
            {
                txtPlcPath2.Text = path;
            }
        }
        /// <summary>应用</summary>
        private void btnApply_Click(object sender, EventArgs e)
        {
            try
            {
                if(string.IsNullOrEmpty(cbChartNum.SelectedItem?.ToString()))
                {
                    throw new Exception("显示曲线数量为空");
                }
                //bool isSame = false;
                //Dictionary<string, string> temp = new Dictionary<string, string>();
                //foreach (var item in _id)
                //{
                //    if (!temp.ContainsKey(item.Text.Trim()))
                //    {
                //        temp.Add(item.Text.Trim(), item.Text.Trim());
                //    }
                //    else
                //    {
                //        isSame = true;
                //        break;
                //    }
                //}
                //if (isSame)
                //{
                //    throw new Exception("ID不能相同");
                //}
                _show.ChartNum = int.TryParse(cbChartNum.SelectedItem.ToString(), out var num) ? num : throw new Exception("曲线显示数量值无效");
                _show.PlcPath = txtPlcPath.Text.Trim();
                _show.PlcPath2 = txtPlcPath2.Text.Trim();

                _show.LogAdd($"应用成功", LogLevel.Info);
            }
            catch (Exception ex)
            {
                _show.LogAdd($"应用失败：{ex.Message}", LogLevel.Warn, 0, true);
            }
        }
        #endregion



        #region Method_ExternalUsing

        /// <summary>显示基元名称更新</summary>
        /// <param name="name"></param>
        public void ShowNameUpdate(string name)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action<string>(ShowNameUpdate), name);
            }
            else
            {
                lblName.Text = name;
            }
        }
        #endregion
    }
}
