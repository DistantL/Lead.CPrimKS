﻿using System.Xml;
using Lead.CPrim.Interfaces;
namespace Lead.CPrim.ShowBracket
{
    public class ShowCreator:IShowCreator
    {
        public IShowTypeAttributes ConcreteShowTypeAttributes => new ShowTypeAttributes();

        IShow IShowCreator.Create(XmlNode showConfig)
        {
            return  new ShowBracket(showConfig);
        }

        IShow IShowCreator.Create()
        {
            return new ShowBracket();
        }
    }
}
