﻿using System;
using System.Collections.Generic;
using Lead.CPrim.Interfaces;
using Lead.CPrim.ShowBracket.Control;
using Lead.CPrim.XmlHelper;
using System.Xml;
using Lead.CPrim.Interfaces.Bracket;

namespace Lead.CPrim.ShowBracket
{
    
     public class ShowBracket : IShow,IBracket
    {
        internal ShowBracketConfig _config;
        private bool _queryDone;
        private bool _startTest;
        public event Del_PauseAndQuery OnPauseAndQuery;

        public ShowBracket()
        {
            _config = new ShowBracketConfig();
            ConfigUi = new ShowConfigControl(this);
            OutputUi = new ShowOutputControl(this);
        }
        public ShowBracket(XmlNode xmlNode)
        {
            if (xmlNode != null)
                _config = XMLHelper.XMLToObject(xmlNode, typeof(ShowBracketConfig)) as ShowBracketConfig;
            else
                return;
                
            ConfigUi = new ShowConfigControl(this);
            OutputUi = new ShowOutputControl(this);
        }
        public System.Windows.Forms.Control ConfigUi { get; }

        public bool Enable
        {
            set => _config.Enable = value;
            get => _config.Enable;
        }
        public Guid Id
        {
            get => _config.Id;
            set => _config.Id = value;
        }
        public string Name
        {
            set => _config.Name = value;
            get => _config.Name;
        }
        public string ShowTypeName
        {
            set => _config.ShowTypeName = value;
            get => _config.ShowTypeName;
        }
        public string QueryTaskPath
        {
            set => _config.QueryTaskPath = value;
            get => _config.QueryTaskPath;
        }

        public bool RepeatUpload
        {
            set => _config.RepeatUpload = value;
            get => _config.RepeatUpload;
        }
        internal bool StopByMsgBox
        {
            set => _config.StopByMsgBox = value;
            get => _config.StopByMsgBox;
        }
        internal bool ChangeEnable
        {
            set => _config.ChangeEnable = value;
            get => _config.ChangeEnable;
        }
        public string StationName
        {
            set => _config.StationName = value;
            get => _config.StationName;
        }
        public int AutoUploadCount
        {
            set => _config.AutoUploadCount = value;
            get => _config.AutoUploadCount;
        }
        public bool AutoUploadEnable
        {
            set => _config.AutoUploadEnable = value;
            get => _config.AutoUploadEnable;
        }
        public double CycletTime
        {
            set => _config.CycletTime = value;
            get => _config.CycletTime;
        }
        public List<DataUpload> DataUploads
        {
            set => _config.DataUploads = value;
            get => _config.DataUploads;
        }
        public bool StartTest
        {
            get => _startTest;
            set
            {
                _startTest = value;
                ((ShowOutputControl) OutputUi).SetStartTestFlag(value);
            }
        }

        public bool QueryDone
        {
            get => _queryDone;
            set
            {
                _queryDone = value;
                ((ShowOutputControl) OutputUi).SetQueryDone(value);
            }
        }

        public System.Windows.Forms.Control OutputUi { get; }
        public string Version
        {
            set;
            get;
        }

        public int IShowDispose()
        {
            var iRet = 0;
            return iRet;
        }

        public int IShowImportConfigXml(XmlNode xmlNode)
        {
            var iRet = 0;
            if (xmlNode != null)
                _config = XMLHelper.XMLToObject(xmlNode, typeof(ShowBracketConfig)) as ShowBracketConfig;
            else
                return -1;
            return iRet;
        }

        public XmlNode IShowExportConfigXml()
        {
            if (_config == null) return null;
            var node = XMLHelper.ObjectToXML(_config);

            return node;
        }

        public string PlatingDate { get; set; }
        public string LineNum { get; set; }
        public string PlatingVendor { get; set; }
        public bool BarcodeEnable { get; set; }

        internal void PauseAndQuery()
        {
            OnPauseAndQuery?.Invoke();
        }
       
    }
}
