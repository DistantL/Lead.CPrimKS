﻿using System;
using System.Collections.Generic;
using Lead.CPrim.Interfaces.Bracket;

namespace Lead.CPrim.ShowBracket
{
     public class ShowBracketConfig
    {
        public bool Enable { set; get; }
        public Guid Id { set; get; }
        public string Name { set; get; }
        public string ShowTypeName { set; get; }
        public bool RepeatUpload { set; get; }
        public bool StopByMsgBox { set; get; }
        public bool ChangeEnable { set; get; }
        public string QueryTaskPath { set; get; }
        public string StationName { set; get; }
        public int AutoUploadCount { set; get; }
        public bool AutoUploadEnable { set; get; }
        public double CycletTime { set; get; } = 30;
        public List<DataUpload> DataUploads { set; get; } = new List<DataUpload>();
    }
}
