﻿using Lead.CPrim.CommonTools;
using Lead.CPrim.TaskHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lead.CPrim.Interfaces.Bracket;
using Lead.CPrim.Interfaces.StateMachine;
using LeadScriptLibrary;

namespace Lead.CPrim.ShowBracket.Control
{
    public partial class ShowConfigControl : UserControl
    {
        public ShowBracket _showBracket;
        private readonly string _collection = "Bracket_AutoUpload";
        private Task _autoUpLoadTask;
        private bool _firstFlag;
        public ShowConfigControl()
        {
            InitializeComponent();
        }
        public ShowConfigControl(ShowBracket showBracket)
        {
            InitializeComponent();
            _showBracket = showBracket;
            if (_autoUpLoadTask == null)
            {
                _autoUpLoadTask = new Task(() => AutoUpload());
            }

            if (_showBracket.AutoUploadEnable)
            {
                _autoUpLoadTask.Start();
                _firstFlag = true;
            }
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            _showBracket.QueryTaskPath = tbComplexQueryTaskFilePath.Text;
            _showBracket.RepeatUpload = chkRepeatUpload.Checked;
            _showBracket.StopByMsgBox = chkStopByMsgbox.Checked;
            _showBracket.StationName = cmbStations.SelectedItem != null ? cmbStations.SelectedItem.ToString() : "";
            _showBracket.AutoUploadEnable = chkAutoUploadEnable.Checked;
            _showBracket.AutoUploadCount = int.TryParse(tbAutoUploadCount.Text, out var count) ? count : 0;
            _showBracket.CycletTime = double.TryParse(tbCycleTime.Text, out var time) && time > 0 ? time : 30;
        }

        private void ShowConfigControl_Load(object sender, EventArgs e)
        {
            tbComplexQueryTaskFilePath.Text = _showBracket.QueryTaskPath;
            chkRepeatUpload.Checked = _showBracket.RepeatUpload;
            chkStopByMsgbox.Checked = _showBracket.StopByMsgBox;
            cmbStations.Items.Clear();
            foreach (var taskSm in TaskSmManger.Instance.TaskSMs) cmbStations.Items.Add(taskSm.Key);
            if (cmbStations.Items.Contains(_showBracket.StationName))
            {
                cmbStations.SelectedItem = _showBracket.StationName;
            }

            tbAutoUploadCount.Text = _showBracket.AutoUploadCount.ToString();
            chkAutoUploadEnable.Checked = _showBracket.AutoUploadEnable;
            tbCycleTime.Text = _showBracket.CycletTime.ToString();
            if (_showBracket.AutoUploadEnable && _autoUpLoadTask.Status != TaskStatus.Running)
            {
                _autoUpLoadTask.Start();
                _firstFlag = true;
            }
        }

        private void AutoUpload()
        {
            while (true)
            {
                Application.DoEvents();
                Thread.Sleep(1000 * (int)_showBracket.CycletTime);
                if (!_showBracket.AutoUploadEnable || !TaskSmManger.Instance.TaskSMs.ContainsKey(_showBracket.StationName)
                                                   || AutoManualStationSM.Instance.State != SmStates.Manual)
                {
                    continue;
                }

                if (!_showBracket.QueryDone && !_firstFlag)
                {
                    continue;
                }

                _firstFlag = false;
                _showBracket.QueryDone = false;
                var curDate = DateTime.Now.ToString("yyyy/MM/dd");
                //向数据库中添加当天新的数据记录
                for (var i = 0; i < _showBracket.AutoUploadCount; i++)
                {
                    if (_showBracket.DataUploads.All(p => p.Index != i))
                    {
                        continue;
                    }
                    var strSTime = _showBracket.DataUploads[i].StartTime.Split(' ')[1];
                    var strETime = _showBracket.DataUploads[i].EndTime.Split(' ')[1];
                    var strStartTime = $"{curDate} {strSTime}";
                    var strEndTime = $"{curDate} {strETime}";
                    var startTime = Convert.ToDateTime(strStartTime);
                    var endTime = Convert.ToDateTime(strEndTime);
                    if (MongodbHelper.MongodbHelper.QueryOne("StartTime", strStartTime, out DataUpload curUpload, _collection) != 0 || curUpload == null)
                    {
                        curUpload = new DataUpload { Index = i, StartTime = strStartTime, EndTime = strEndTime };
                        MongodbHelper.MongodbHelper.InsertOne(curUpload, _collection);
                    }
                }

                if (MongodbHelper.MongodbHelper.QueryAll(out List<DataUpload> uploadRecords, _collection) == 0 && uploadRecords != null && uploadRecords.Count > 0)
                {
                    foreach (var t in uploadRecords)
                    {
                        if (!t.Uploaded && DateTime.Now > Convert.ToDateTime(t.EndTime)) //未上传且当前时间大于该记录的截至时间则执行查询和任务运行
                        {
                            //Cursor = Cursors.WaitCursor;
                            var filePath = _showBracket.QueryTaskPath;
                            if (string.IsNullOrEmpty(filePath))
                            {
                                MessageBox.Show($@"复杂查询所用脚本不存在，请检查！");
                                //Cursor = DefaultCursor;
                                return;
                            }
                            var filePaths = new string[1];
                            filePaths[0] = filePath;
                            try
                            {
                                var helper = new AsmHelper(LeadScript.LoadFiles(filePaths));
                                var instance = helper.TryCreateObject("RunState");
                                var result = helper.InvokeInst(instance, "Init", t.StartTime, t.EndTime);
                                t.Uploaded = true;
                                MongodbHelper.MongodbHelper.UpdateOne<DataUpload>("StartTime", t.StartTime, "Uploaded",
                                    "true", _collection);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message);
                               // Cursor = DefaultCursor;
                            }
                            //Cursor = DefaultCursor;
                        }
                    }
                }

            }
        }
        private void btnBrowseComplexQueryTaskFilePath_Click(object sender, EventArgs e)
        {
            var t = tbComplexQueryTaskFilePath.Text;
            FileHelper.OpenFileDialogMethod(ref t);
            tbComplexQueryTaskFilePath.Text = t;
        }

        private void numAutoUpload_ValueChanged(object sender, EventArgs e)
        {
            var index = Convert.ToInt32(numAutoUpload.Value - 1);
            if (index < 0 || index >= _showBracket.AutoUploadCount)
            {
                return;
            }
            if (_showBracket.DataUploads.All(p => p.Index != index))
            {
                var newUpload = new DataUpload {Index = index, StartTime = "2020/8/29 08:00:00", EndTime = "2020/8/29 12:00:00" };
                _showBracket.DataUploads.Add(newUpload);
            }
            var dataUpload = _showBracket.DataUploads.FirstOrDefault(p => p.Index == index);
            dtpStartTime.Value = Convert.ToDateTime(dataUpload.StartTime);
            dtpEndTime.Value = Convert.ToDateTime(dataUpload.EndTime);
        }

        private void dtpStartTime_ValueChanged(object sender, EventArgs e)
        {
            var index = Convert.ToInt32(numAutoUpload.Value - 1);
            if (index < 0 || index >= _showBracket.AutoUploadCount)
            {
                return;
            }

            var dataUpload = _showBracket.DataUploads.FirstOrDefault(p => p.Index == index);
            dataUpload.StartTime= dtpStartTime.Value.ToString("yyyy/MM/dd HH:mm:ss");
        }

        private void dtpEndTime_ValueChanged(object sender, EventArgs e)
        {
            var index = Convert.ToInt32(numAutoUpload.Value - 1);
            if (index < 0 || index >= _showBracket.AutoUploadCount)
            {
                return;
            }
            var dataUpload = _showBracket.DataUploads.FirstOrDefault(p => p.Index == index);
            dataUpload.EndTime = dtpEndTime.Value.ToString("yyyy/MM/dd HH:mm:ss");
        }
    }
}
