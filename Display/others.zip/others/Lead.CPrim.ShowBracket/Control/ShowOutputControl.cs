﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using LeadScriptLibrary;

namespace Lead.CPrim.ShowBracket.Control
{
    public partial class ShowOutputControl : UserControl
    {
        private ShowBracket _bracket;
        public ShowOutputControl(ShowBracket bracket)
        {
            InitializeComponent();
            _bracket = bracket;
        }
        private void ShowOutputControl_Load(object sender, EventArgs e)
        {
           dtpStartTime.Value = DateTime.Now;
           btnPauseAndUpload.Enabled = false;
        }

        private void tbPlatingDate_TextChanged(object sender, EventArgs e)
        {
            _bracket.PlatingDate = tbPlatingDate.Text;
        }

        private void tbLineNum_TextChanged(object sender, EventArgs e)
        {
            _bracket.LineNum = tbLineNum.Text;
        }

        private void tbPlatingVendor_TextChanged(object sender, EventArgs e)
        {
            _bracket.PlatingVendor = tbPlatingVendor.Text;
        }

        private void chkBarcodeEnable_CheckedChanged(object sender, EventArgs e)
        {
            _bracket.BarcodeEnable = chkBarcodeEnable.Checked;
        }

        private void btnStartTest_Click(object sender, EventArgs e)
        {
            if (!chkBarcodeEnable.Checked && (string.IsNullOrEmpty(tbLineNum.Text) || string.IsNullOrEmpty(tbPlatingDate.Text) || string.IsNullOrEmpty(tbPlatingVendor.Text)))
            {
                MessageBox.Show(@"不带二维码模式下，必须手动录入电镀日期，线体号，电镀厂商。", "警告", MessageBoxButtons.OK);
                return;
            }
            dtpStartTime.Value = DateTime.Now;
            _bracket.StartTest = true;
        }

        private void btnPauseAndUpload_Click(object sender, EventArgs e)
        {
            if (_bracket.StopByMsgBox)
            {
                var diaResult = MessageBox.Show($@"确定要结束本次测量并上传数据吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
                if (diaResult != DialogResult.Yes)
                {
                    return;
                }
            }
            _bracket.PauseAndQuery();
            dtpEndTime.Value = DateTime.Now;
            btnQueryData_Click(null, null);
            _bracket.StartTest = false;
        }

        private void btnQueryData_Click(object sender, EventArgs e)
        {
            if (!chkBarcodeEnable.Checked && (string.IsNullOrEmpty(tbLineNum.Text) || string.IsNullOrEmpty(tbPlatingDate.Text) || string.IsNullOrEmpty(tbPlatingVendor.Text)))
            {
                MessageBox.Show(@"不带二维码模式下，必须手动录入电镀日期，线体号，电镀厂商。", "警告", MessageBoxButtons.OK);
                return;
            }
            _bracket.QueryDone = false;
            Cursor = Cursors.WaitCursor;
            var filePath = _bracket.QueryTaskPath;
            if (string.IsNullOrEmpty(filePath))
            {
                MessageBox.Show($@"复杂查询所用脚本不存在，请检查！");
                Cursor = DefaultCursor;
                return;
            }
            var filePaths = new string[1];
            filePaths[0] = filePath;
            try
            {
                var helper = new AsmHelper(LeadScript.LoadFiles(filePaths));
                var instance = helper.TryCreateObject("RunState");
                var result = helper.InvokeInst(instance, "Init", dtpStartTime.Value, dtpEndTime.Value);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                _bracket.QueryDone = true;
            }
            Cursor = DefaultCursor;
        }

        internal void SetStartTestFlag(bool value)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action<bool>(SetStartTestFlag), value);
            }
            else
            {
                btnPauseAndUpload.Enabled = value;
                btnStartTest.Enabled = !value;
                if (!_bracket.ChangeEnable)
                {
                    tbLineNum.Enabled = !value;
                    tbPlatingDate.Enabled = !value;
                    tbPlatingVendor.Enabled = !value;
                }
            }
        }

        internal void SetQueryDone(bool value)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action<bool>(SetQueryDone), value);
            }
            else
            {
                if (!value)
                {
                    btnPauseAndUpload.Enabled = false;
                }
                btnQueryData.Enabled = value;
            }
        }
    }
}
