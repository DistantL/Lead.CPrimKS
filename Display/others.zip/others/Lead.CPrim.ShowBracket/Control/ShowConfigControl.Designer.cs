﻿namespace Lead.CPrim.ShowBracket.Control
{
    partial class ShowConfigControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.btnBrowseComplexQueryTaskFilePath = new System.Windows.Forms.Button();
            this.tbComplexQueryTaskFilePath = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chkRepeatUpload = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbStations = new System.Windows.Forms.ComboBox();
            this.chkStopByMsgbox = new System.Windows.Forms.CheckBox();
            this.chkAutoUploadEnable = new System.Windows.Forms.CheckBox();
            this.numAutoUpload = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbAutoUploadCount = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpEndTime = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpStartTime = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.tbCycleTime = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numAutoUpload)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LawnGreen;
            this.button1.Location = new System.Drawing.Point(789, 210);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 32);
            this.button1.TabIndex = 2;
            this.button1.Text = "Apply";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // btnBrowseComplexQueryTaskFilePath
            // 
            this.btnBrowseComplexQueryTaskFilePath.Location = new System.Drawing.Point(691, 16);
            this.btnBrowseComplexQueryTaskFilePath.Name = "btnBrowseComplexQueryTaskFilePath";
            this.btnBrowseComplexQueryTaskFilePath.Size = new System.Drawing.Size(34, 25);
            this.btnBrowseComplexQueryTaskFilePath.TabIndex = 323;
            this.btnBrowseComplexQueryTaskFilePath.Text = "...";
            this.btnBrowseComplexQueryTaskFilePath.Click += new System.EventHandler(this.btnBrowseComplexQueryTaskFilePath_Click);
            // 
            // tbComplexQueryTaskFilePath
            // 
            this.tbComplexQueryTaskFilePath.Location = new System.Drawing.Point(151, 20);
            this.tbComplexQueryTaskFilePath.Name = "tbComplexQueryTaskFilePath";
            this.tbComplexQueryTaskFilePath.Size = new System.Drawing.Size(514, 23);
            this.tbComplexQueryTaskFilePath.TabIndex = 322;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(13, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 20);
            this.label3.TabIndex = 321;
            this.label3.Text = "复杂查询任务路径：";
            // 
            // chkRepeatUpload
            // 
            this.chkRepeatUpload.AutoSize = true;
            this.chkRepeatUpload.Location = new System.Drawing.Point(16, 68);
            this.chkRepeatUpload.Name = "chkRepeatUpload";
            this.chkRepeatUpload.Size = new System.Drawing.Size(123, 21);
            this.chkRepeatUpload.TabIndex = 324;
            this.chkRepeatUpload.Text = "允许数据重复上传";
            this.chkRepeatUpload.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 17);
            this.label1.TabIndex = 326;
            this.label1.Text = "工站:";
            // 
            // cmbStations
            // 
            this.cmbStations.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStations.FormattingEnabled = true;
            this.cmbStations.Location = new System.Drawing.Point(70, 110);
            this.cmbStations.Name = "cmbStations";
            this.cmbStations.Size = new System.Drawing.Size(121, 25);
            this.cmbStations.TabIndex = 325;
            // 
            // chkStopByMsgbox
            // 
            this.chkStopByMsgbox.AutoSize = true;
            this.chkStopByMsgbox.Location = new System.Drawing.Point(227, 68);
            this.chkStopByMsgbox.Name = "chkStopByMsgbox";
            this.chkStopByMsgbox.Size = new System.Drawing.Size(135, 21);
            this.chkStopByMsgbox.TabIndex = 327;
            this.chkStopByMsgbox.Text = "结束测量时弹窗提示";
            this.chkStopByMsgbox.UseVisualStyleBackColor = true;
            // 
            // chkAutoUploadEnable
            // 
            this.chkAutoUploadEnable.AutoSize = true;
            this.chkAutoUploadEnable.Location = new System.Drawing.Point(16, 170);
            this.chkAutoUploadEnable.Name = "chkAutoUploadEnable";
            this.chkAutoUploadEnable.Size = new System.Drawing.Size(123, 21);
            this.chkAutoUploadEnable.TabIndex = 328;
            this.chkAutoUploadEnable.Text = "启用自动上传功能";
            this.chkAutoUploadEnable.UseVisualStyleBackColor = true;
            // 
            // numAutoUpload
            // 
            this.numAutoUpload.Location = new System.Drawing.Point(125, 22);
            this.numAutoUpload.Name = "numAutoUpload";
            this.numAutoUpload.Size = new System.Drawing.Size(77, 23);
            this.numAutoUpload.TabIndex = 329;
            this.numAutoUpload.ValueChanged += new System.EventHandler(this.numAutoUpload_ValueChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbAutoUploadCount);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.dtpEndTime);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.dtpStartTime);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.numAutoUpload);
            this.groupBox1.Location = new System.Drawing.Point(227, 110);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(422, 132);
            this.groupBox1.TabIndex = 330;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "自动上传时间段设定";
            // 
            // tbAutoUploadCount
            // 
            this.tbAutoUploadCount.Location = new System.Drawing.Point(270, 22);
            this.tbAutoUploadCount.Name = "tbAutoUploadCount";
            this.tbAutoUploadCount.Size = new System.Drawing.Size(100, 23);
            this.tbAutoUploadCount.TabIndex = 336;
            this.tbAutoUploadCount.Text = "4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(220, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 17);
            this.label5.TabIndex = 335;
            this.label5.Text = "总计：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(7, 97);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 19, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 21);
            this.label4.TabIndex = 333;
            this.label4.Text = "结束时间：";
            // 
            // dtpEndTime
            // 
            this.dtpEndTime.CustomFormat = "HH:mm:ss";
            this.dtpEndTime.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.dtpEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEndTime.Location = new System.Drawing.Point(101, 96);
            this.dtpEndTime.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.dtpEndTime.Name = "dtpEndTime";
            this.dtpEndTime.Size = new System.Drawing.Size(118, 25);
            this.dtpEndTime.TabIndex = 334;
            this.dtpEndTime.Value = new System.DateTime(2020, 8, 29, 12, 0, 0, 0);
            this.dtpEndTime.ValueChanged += new System.EventHandler(this.dtpEndTime_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(7, 57);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 19, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 21);
            this.label6.TabIndex = 331;
            this.label6.Text = "起始时间：";
            // 
            // dtpStartTime
            // 
            this.dtpStartTime.CustomFormat = "HH:mm:ss";
            this.dtpStartTime.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.dtpStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpStartTime.Location = new System.Drawing.Point(101, 56);
            this.dtpStartTime.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.dtpStartTime.Name = "dtpStartTime";
            this.dtpStartTime.Size = new System.Drawing.Size(118, 25);
            this.dtpStartTime.TabIndex = 332;
            this.dtpStartTime.Value = new System.DateTime(2020, 8, 29, 8, 0, 0, 0);
            this.dtpStartTime.ValueChanged += new System.EventHandler(this.dtpStartTime_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 17);
            this.label2.TabIndex = 330;
            this.label2.Text = "次数（从1开始）：";
            // 
            // tbCycleTime
            // 
            this.tbCycleTime.Location = new System.Drawing.Point(121, 211);
            this.tbCycleTime.Name = "tbCycleTime";
            this.tbCycleTime.Size = new System.Drawing.Size(80, 23);
            this.tbCycleTime.TabIndex = 338;
            this.tbCycleTime.Text = "30";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 214);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 17);
            this.label7.TabIndex = 337;
            this.label7.Text = "扫描间隔（秒）：";
            // 
            // ShowConfigControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Controls.Add(this.tbCycleTime);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.chkAutoUploadEnable);
            this.Controls.Add(this.chkStopByMsgbox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbStations);
            this.Controls.Add(this.chkRepeatUpload);
            this.Controls.Add(this.btnBrowseComplexQueryTaskFilePath);
            this.Controls.Add(this.tbComplexQueryTaskFilePath);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ShowConfigControl";
            this.Size = new System.Drawing.Size(883, 254);
            this.Load += new System.EventHandler(this.ShowConfigControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numAutoUpload)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnBrowseComplexQueryTaskFilePath;
        private System.Windows.Forms.TextBox tbComplexQueryTaskFilePath;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkRepeatUpload;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbStations;
        private System.Windows.Forms.CheckBox chkStopByMsgbox;
        private System.Windows.Forms.CheckBox chkAutoUploadEnable;
        private System.Windows.Forms.NumericUpDown numAutoUpload;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtpStartTime;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpEndTime;
        private System.Windows.Forms.TextBox tbAutoUploadCount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbCycleTime;
        private System.Windows.Forms.Label label7;
    }
}
