﻿namespace Lead.CPrim.ShowBracket.Control
{
    partial class ShowOutputControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.tbPlatingVendor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbLineNum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbPlatingDate = new System.Windows.Forms.TextBox();
            this.chkBarcodeEnable = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpEndTime = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpStartTime = new System.Windows.Forms.DateTimePicker();
            this.btnPauseAndUpload = new System.Windows.Forms.Button();
            this.btnStartTest = new System.Windows.Forms.Button();
            this.btnQueryData = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(451, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 19);
            this.label3.TabIndex = 14;
            this.label3.Text = "电镀厂商：";
            // 
            // tbPlatingVendor
            // 
            this.tbPlatingVendor.Location = new System.Drawing.Point(536, 64);
            this.tbPlatingVendor.Name = "tbPlatingVendor";
            this.tbPlatingVendor.Size = new System.Drawing.Size(100, 23);
            this.tbPlatingVendor.TabIndex = 13;
            this.tbPlatingVendor.TextChanged += new System.EventHandler(this.tbPlatingVendor_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(232, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 19);
            this.label2.TabIndex = 12;
            this.label2.Text = "线体号：";
            // 
            // tbLineNum
            // 
            this.tbLineNum.Location = new System.Drawing.Point(317, 64);
            this.tbLineNum.Name = "tbLineNum";
            this.tbLineNum.Size = new System.Drawing.Size(100, 23);
            this.tbLineNum.TabIndex = 11;
            this.tbLineNum.TextChanged += new System.EventHandler(this.tbLineNum_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(17, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 19);
            this.label1.TabIndex = 10;
            this.label1.Text = "电镀日期：";
            // 
            // tbPlatingDate
            // 
            this.tbPlatingDate.Location = new System.Drawing.Point(102, 64);
            this.tbPlatingDate.Name = "tbPlatingDate";
            this.tbPlatingDate.Size = new System.Drawing.Size(100, 23);
            this.tbPlatingDate.TabIndex = 9;
            this.tbPlatingDate.TextChanged += new System.EventHandler(this.tbPlatingDate_TextChanged);
            // 
            // chkBarcodeEnable
            // 
            this.chkBarcodeEnable.AutoSize = true;
            this.chkBarcodeEnable.Font = new System.Drawing.Font("微软雅黑", 14F, System.Drawing.FontStyle.Bold);
            this.chkBarcodeEnable.Location = new System.Drawing.Point(16, 17);
            this.chkBarcodeEnable.Name = "chkBarcodeEnable";
            this.chkBarcodeEnable.Size = new System.Drawing.Size(145, 30);
            this.chkBarcodeEnable.TabIndex = 8;
            this.chkBarcodeEnable.Text = "产品带二维码";
            this.chkBarcodeEnable.UseVisualStyleBackColor = true;
            this.chkBarcodeEnable.CheckedChanged += new System.EventHandler(this.chkBarcodeEnable_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(665, 65);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 19, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 21);
            this.label4.TabIndex = 27;
            this.label4.Text = "终止时间：";
            // 
            // dtpEndTime
            // 
            this.dtpEndTime.CustomFormat = "yyyy/MM/dd HH:mm:ss";
            this.dtpEndTime.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.dtpEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEndTime.Location = new System.Drawing.Point(759, 64);
            this.dtpEndTime.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.dtpEndTime.Name = "dtpEndTime";
            this.dtpEndTime.Size = new System.Drawing.Size(186, 25);
            this.dtpEndTime.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(665, 12);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 19, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 21);
            this.label6.TabIndex = 25;
            this.label6.Text = "起始时间：";
            // 
            // dtpStartTime
            // 
            this.dtpStartTime.CustomFormat = "yyyy/MM/dd HH:mm:ss";
            this.dtpStartTime.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.dtpStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpStartTime.Location = new System.Drawing.Point(759, 11);
            this.dtpStartTime.Margin = new System.Windows.Forms.Padding(4, 12, 4, 4);
            this.dtpStartTime.Name = "dtpStartTime";
            this.dtpStartTime.Size = new System.Drawing.Size(186, 25);
            this.dtpStartTime.TabIndex = 26;
            // 
            // btnPauseAndUpload
            // 
            this.btnPauseAndUpload.BackColor = System.Drawing.Color.OrangeRed;
            this.btnPauseAndUpload.ForeColor = System.Drawing.Color.Transparent;
            this.btnPauseAndUpload.Location = new System.Drawing.Point(952, -1);
            this.btnPauseAndUpload.Name = "btnPauseAndUpload";
            this.btnPauseAndUpload.Size = new System.Drawing.Size(127, 57);
            this.btnPauseAndUpload.TabIndex = 32;
            this.btnPauseAndUpload.Text = "结束测量并汇总数据";
            this.btnPauseAndUpload.UseVisualStyleBackColor = false;
            this.btnPauseAndUpload.Click += new System.EventHandler(this.btnPauseAndUpload_Click);
            // 
            // btnStartTest
            // 
            this.btnStartTest.BackColor = System.Drawing.Color.GreenYellow;
            this.btnStartTest.Font = new System.Drawing.Font("微软雅黑", 15F);
            this.btnStartTest.Location = new System.Drawing.Point(455, 6);
            this.btnStartTest.Margin = new System.Windows.Forms.Padding(4);
            this.btnStartTest.Name = "btnStartTest";
            this.btnStartTest.Size = new System.Drawing.Size(182, 48);
            this.btnStartTest.TabIndex = 33;
            this.btnStartTest.Text = "开启测量";
            this.btnStartTest.UseVisualStyleBackColor = false;
            this.btnStartTest.Click += new System.EventHandler(this.btnStartTest_Click);
            // 
            // btnQueryData
            // 
            this.btnQueryData.BackColor = System.Drawing.Color.Yellow;
            this.btnQueryData.ForeColor = System.Drawing.Color.Black;
            this.btnQueryData.Location = new System.Drawing.Point(962, 62);
            this.btnQueryData.Name = "btnQueryData";
            this.btnQueryData.Size = new System.Drawing.Size(109, 31);
            this.btnQueryData.TabIndex = 34;
            this.btnQueryData.Text = "手动抓取数据";
            this.btnQueryData.UseVisualStyleBackColor = false;
            this.btnQueryData.Click += new System.EventHandler(this.btnQueryData_Click);
            // 
            // ShowOutputControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Controls.Add(this.btnQueryData);
            this.Controls.Add(this.btnStartTest);
            this.Controls.Add(this.btnPauseAndUpload);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtpEndTime);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dtpStartTime);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbPlatingVendor);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbLineNum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbPlatingDate);
            this.Controls.Add(this.chkBarcodeEnable);
            this.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "ShowOutputControl";
            this.Size = new System.Drawing.Size(1082, 112);
            this.Load += new System.EventHandler(this.ShowOutputControl_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbPlatingVendor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbLineNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbPlatingDate;
        private System.Windows.Forms.CheckBox chkBarcodeEnable;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpEndTime;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtpStartTime;
        private System.Windows.Forms.Button btnPauseAndUpload;
        private System.Windows.Forms.Button btnStartTest;
        private System.Windows.Forms.Button btnQueryData;
    }
}
