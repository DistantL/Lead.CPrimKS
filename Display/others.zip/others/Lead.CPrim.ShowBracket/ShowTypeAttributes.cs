﻿using System.Drawing;
using System.Resources;
using Lead.CPrim.Interfaces;

namespace Lead.CPrim.ShowBracket
{
    public class ShowTypeAttributes : IShowTypeAttributes
    {
        public string Description => "ShowBracket";

        public string DisplayGroup => "PAX";

        public string DisplayName => "Bracket";

        public string Group => "PAX";

        public Image Icon
        {
            get
            {
                var manager = new ResourceManager(typeof(ResourceDefault));
                return (Image)manager.GetObject("Default"); 
            }
        }


        public byte MajorVersion => 1;

        public byte MinorVersion => 1;

        public string Name => "ShowBracket";
    }
}
