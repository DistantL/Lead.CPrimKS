﻿namespace Lead.CPrim.ShowPicShowResult.Controls
{
    partial class ShowConfigControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.tbPrimName = new System.Windows.Forms.TextBox();
            this.lbTitle = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.pic1 = new System.Windows.Forms.Panel();
            this.table = new System.Windows.Forms.TableLayoutPanel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tPageConfig = new System.Windows.Forms.TabPage();
            this.btnApplyConfigs = new System.Windows.Forms.Button();
            this.btnBrowserLabelsConfigPath = new System.Windows.Forms.Button();
            this.tbLabelsFilePath = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnUpdateTable = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.tbRowCount = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tbColCount = new System.Windows.Forms.TextBox();
            this.tbIntervalYPos = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbIntervalXPos = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbY1Pos = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbX1Pos = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbY2Pos = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbX2Pos = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnLoadPic = new System.Windows.Forms.Button();
            this.tbPicName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBrowser = new System.Windows.Forms.Button();
            this.tbFilePath = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tPageLabels = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.btnDeleteLabel = new System.Windows.Forms.Button();
            this.btnAddNewLabel = new System.Windows.Forms.Button();
            this.flowLabels = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.pic1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tPageConfig.SuspendLayout();
            this.tPageLabels.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.tbPrimName);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 43);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(875, 44);
            this.panel1.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.SkyBlue;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 44);
            this.label1.TabIndex = 12;
            this.label1.Text = "PicShowResult Name";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbPrimName
            // 
            this.tbPrimName.BackColor = System.Drawing.Color.OldLace;
            this.tbPrimName.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbPrimName.Location = new System.Drawing.Point(202, 3);
            this.tbPrimName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbPrimName.Multiline = true;
            this.tbPrimName.Name = "tbPrimName";
            this.tbPrimName.Size = new System.Drawing.Size(211, 39);
            this.tbPrimName.TabIndex = 13;
            this.tbPrimName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbTitle
            // 
            this.lbTitle.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lbTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbTitle.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTitle.Location = new System.Drawing.Point(0, 0);
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.Size = new System.Drawing.Size(875, 43);
            this.lbTitle.TabIndex = 18;
            this.lbTitle.Text = "PicShowResult Config";
            this.lbTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 87);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.pic1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer1.Size = new System.Drawing.Size(875, 429);
            this.splitContainer1.SplitterDistance = 214;
            this.splitContainer1.TabIndex = 20;
            // 
            // pic1
            // 
            this.pic1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pic1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic1.Controls.Add(this.table);
            this.pic1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pic1.Location = new System.Drawing.Point(0, 0);
            this.pic1.Name = "pic1";
            this.pic1.Size = new System.Drawing.Size(875, 214);
            this.pic1.TabIndex = 26;
            this.pic1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pic1_MouseClick);
            this.pic1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.pic1_MouseDoubleClick);
            // 
            // table
            // 
            this.table.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.table.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.table.ColumnCount = 2;
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.table.Location = new System.Drawing.Point(51, 43);
            this.table.Name = "table";
            this.table.RowCount = 2;
            this.table.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.table.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.table.Size = new System.Drawing.Size(200, 100);
            this.table.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tPageConfig);
            this.tabControl1.Controls.Add(this.tPageLabels);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(875, 211);
            this.tabControl1.TabIndex = 0;
            // 
            // tPageConfig
            // 
            this.tPageConfig.Controls.Add(this.btnApplyConfigs);
            this.tPageConfig.Controls.Add(this.btnBrowserLabelsConfigPath);
            this.tPageConfig.Controls.Add(this.tbLabelsFilePath);
            this.tPageConfig.Controls.Add(this.label4);
            this.tPageConfig.Controls.Add(this.btnUpdateTable);
            this.tPageConfig.Controls.Add(this.label14);
            this.tPageConfig.Controls.Add(this.tbRowCount);
            this.tPageConfig.Controls.Add(this.label15);
            this.tPageConfig.Controls.Add(this.tbColCount);
            this.tPageConfig.Controls.Add(this.tbIntervalYPos);
            this.tPageConfig.Controls.Add(this.label9);
            this.tPageConfig.Controls.Add(this.tbIntervalXPos);
            this.tPageConfig.Controls.Add(this.label10);
            this.tPageConfig.Controls.Add(this.tbY1Pos);
            this.tPageConfig.Controls.Add(this.label7);
            this.tPageConfig.Controls.Add(this.tbX1Pos);
            this.tPageConfig.Controls.Add(this.label8);
            this.tPageConfig.Controls.Add(this.tbY2Pos);
            this.tPageConfig.Controls.Add(this.label5);
            this.tPageConfig.Controls.Add(this.tbX2Pos);
            this.tPageConfig.Controls.Add(this.label6);
            this.tPageConfig.Controls.Add(this.btnLoadPic);
            this.tPageConfig.Controls.Add(this.tbPicName);
            this.tPageConfig.Controls.Add(this.label2);
            this.tPageConfig.Controls.Add(this.btnBrowser);
            this.tPageConfig.Controls.Add(this.tbFilePath);
            this.tPageConfig.Controls.Add(this.label3);
            this.tPageConfig.Location = new System.Drawing.Point(4, 26);
            this.tPageConfig.Name = "tPageConfig";
            this.tPageConfig.Padding = new System.Windows.Forms.Padding(3);
            this.tPageConfig.Size = new System.Drawing.Size(867, 181);
            this.tPageConfig.TabIndex = 0;
            this.tPageConfig.Text = "配置";
            this.tPageConfig.UseVisualStyleBackColor = true;
            // 
            // btnApplyConfigs
            // 
            this.btnApplyConfigs.BackColor = System.Drawing.Color.LawnGreen;
            this.btnApplyConfigs.Location = new System.Drawing.Point(769, 105);
            this.btnApplyConfigs.Name = "btnApplyConfigs";
            this.btnApplyConfigs.Size = new System.Drawing.Size(67, 51);
            this.btnApplyConfigs.TabIndex = 43;
            this.btnApplyConfigs.Text = "应用";
            this.btnApplyConfigs.UseVisualStyleBackColor = false;
            this.btnApplyConfigs.Click += new System.EventHandler(this.btnApplyConfigs_Click);
            // 
            // btnBrowserLabelsConfigPath
            // 
            this.btnBrowserLabelsConfigPath.Location = new System.Drawing.Point(515, 133);
            this.btnBrowserLabelsConfigPath.Name = "btnBrowserLabelsConfigPath";
            this.btnBrowserLabelsConfigPath.Size = new System.Drawing.Size(75, 23);
            this.btnBrowserLabelsConfigPath.TabIndex = 42;
            this.btnBrowserLabelsConfigPath.Text = "保存";
            this.btnBrowserLabelsConfigPath.UseVisualStyleBackColor = true;
            this.btnBrowserLabelsConfigPath.Click += new System.EventHandler(this.btnBrowserLabelsConfigPath_Click);
            // 
            // tbLabelsFilePath
            // 
            this.tbLabelsFilePath.Location = new System.Drawing.Point(77, 133);
            this.tbLabelsFilePath.Name = "tbLabelsFilePath";
            this.tbLabelsFilePath.Size = new System.Drawing.Size(432, 23);
            this.tbLabelsFilePath.TabIndex = 41;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 17);
            this.label4.TabIndex = 40;
            this.label4.Text = "标签存储：";
            // 
            // btnUpdateTable
            // 
            this.btnUpdateTable.Location = new System.Drawing.Point(623, 57);
            this.btnUpdateTable.Name = "btnUpdateTable";
            this.btnUpdateTable.Size = new System.Drawing.Size(64, 34);
            this.btnUpdateTable.TabIndex = 39;
            this.btnUpdateTable.Text = "表格更新";
            this.btnUpdateTable.UseVisualStyleBackColor = true;
            this.btnUpdateTable.Click += new System.EventHandler(this.btnUpdateTable_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(503, 57);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 17);
            this.label14.TabIndex = 35;
            this.label14.Text = "行数：";
            // 
            // tbRowCount
            // 
            this.tbRowCount.Location = new System.Drawing.Point(550, 54);
            this.tbRowCount.Name = "tbRowCount";
            this.tbRowCount.Size = new System.Drawing.Size(55, 23);
            this.tbRowCount.TabIndex = 36;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(503, 82);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 17);
            this.label15.TabIndex = 37;
            this.label15.Text = "列数：";
            // 
            // tbColCount
            // 
            this.tbColCount.Location = new System.Drawing.Point(550, 79);
            this.tbColCount.Name = "tbColCount";
            this.tbColCount.Size = new System.Drawing.Size(55, 23);
            this.tbColCount.TabIndex = 38;
            // 
            // tbIntervalYPos
            // 
            this.tbIntervalYPos.Location = new System.Drawing.Point(421, 85);
            this.tbIntervalYPos.Name = "tbIntervalYPos";
            this.tbIntervalYPos.ReadOnly = true;
            this.tbIntervalYPos.Size = new System.Drawing.Size(55, 23);
            this.tbIntervalYPos.TabIndex = 34;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(344, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 17);
            this.label9.TabIndex = 33;
            this.label9.Text = "Y间距：";
            // 
            // tbIntervalXPos
            // 
            this.tbIntervalXPos.Location = new System.Drawing.Point(421, 41);
            this.tbIntervalXPos.Name = "tbIntervalXPos";
            this.tbIntervalXPos.ReadOnly = true;
            this.tbIntervalXPos.Size = new System.Drawing.Size(55, 23);
            this.tbIntervalXPos.TabIndex = 32;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(344, 44);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 17);
            this.label10.TabIndex = 31;
            this.label10.Text = "X间距：";
            // 
            // tbY1Pos
            // 
            this.tbY1Pos.Location = new System.Drawing.Point(83, 85);
            this.tbY1Pos.Name = "tbY1Pos";
            this.tbY1Pos.ReadOnly = true;
            this.tbY1Pos.Size = new System.Drawing.Size(55, 23);
            this.tbY1Pos.TabIndex = 30;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 85);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 17);
            this.label7.TabIndex = 29;
            this.label7.Text = "Y1坐标：";
            // 
            // tbX1Pos
            // 
            this.tbX1Pos.Location = new System.Drawing.Point(83, 41);
            this.tbX1Pos.Name = "tbX1Pos";
            this.tbX1Pos.ReadOnly = true;
            this.tbX1Pos.Size = new System.Drawing.Size(55, 23);
            this.tbX1Pos.TabIndex = 28;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 44);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 17);
            this.label8.TabIndex = 27;
            this.label8.Text = "X1坐标：";
            // 
            // tbY2Pos
            // 
            this.tbY2Pos.Location = new System.Drawing.Point(257, 85);
            this.tbY2Pos.Name = "tbY2Pos";
            this.tbY2Pos.ReadOnly = true;
            this.tbY2Pos.Size = new System.Drawing.Size(55, 23);
            this.tbY2Pos.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(180, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 17);
            this.label5.TabIndex = 25;
            this.label5.Text = "Y2坐标：";
            // 
            // tbX2Pos
            // 
            this.tbX2Pos.Location = new System.Drawing.Point(257, 41);
            this.tbX2Pos.Name = "tbX2Pos";
            this.tbX2Pos.ReadOnly = true;
            this.tbX2Pos.Size = new System.Drawing.Size(55, 23);
            this.tbX2Pos.TabIndex = 24;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(180, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 17);
            this.label6.TabIndex = 23;
            this.label6.Text = "X2坐标：";
            // 
            // btnLoadPic
            // 
            this.btnLoadPic.BackColor = System.Drawing.Color.LawnGreen;
            this.btnLoadPic.Location = new System.Drawing.Point(769, 8);
            this.btnLoadPic.Name = "btnLoadPic";
            this.btnLoadPic.Size = new System.Drawing.Size(75, 23);
            this.btnLoadPic.TabIndex = 14;
            this.btnLoadPic.Text = "加载";
            this.btnLoadPic.UseVisualStyleBackColor = false;
            this.btnLoadPic.Click += new System.EventHandler(this.btnLoadPic_Click);
            // 
            // tbPicName
            // 
            this.tbPicName.Location = new System.Drawing.Point(667, 10);
            this.tbPicName.Name = "tbPicName";
            this.tbPicName.Size = new System.Drawing.Size(77, 23);
            this.tbPicName.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(596, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "图片名称：";
            // 
            // btnBrowser
            // 
            this.btnBrowser.Location = new System.Drawing.Point(515, 8);
            this.btnBrowser.Name = "btnBrowser";
            this.btnBrowser.Size = new System.Drawing.Size(75, 23);
            this.btnBrowser.TabIndex = 11;
            this.btnBrowser.Text = "浏览";
            this.btnBrowser.UseVisualStyleBackColor = true;
            this.btnBrowser.Click += new System.EventHandler(this.btnBrowser_Click);
            // 
            // tbFilePath
            // 
            this.tbFilePath.Location = new System.Drawing.Point(77, 10);
            this.tbFilePath.Name = "tbFilePath";
            this.tbFilePath.Size = new System.Drawing.Size(432, 23);
            this.tbFilePath.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "图片路径：";
            // 
            // tPageLabels
            // 
            this.tPageLabels.Controls.Add(this.splitContainer2);
            this.tPageLabels.Location = new System.Drawing.Point(4, 22);
            this.tPageLabels.Name = "tPageLabels";
            this.tPageLabels.Padding = new System.Windows.Forms.Padding(3);
            this.tPageLabels.Size = new System.Drawing.Size(867, 185);
            this.tPageLabels.TabIndex = 1;
            this.tPageLabels.Text = "标签";
            this.tPageLabels.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(3, 3);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.btnDeleteLabel);
            this.splitContainer2.Panel1.Controls.Add(this.btnAddNewLabel);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.flowLabels);
            this.splitContainer2.Size = new System.Drawing.Size(861, 179);
            this.splitContainer2.SplitterDistance = 86;
            this.splitContainer2.TabIndex = 0;
            // 
            // btnDeleteLabel
            // 
            this.btnDeleteLabel.BackColor = System.Drawing.Color.OrangeRed;
            this.btnDeleteLabel.Location = new System.Drawing.Point(6, 58);
            this.btnDeleteLabel.Name = "btnDeleteLabel";
            this.btnDeleteLabel.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteLabel.TabIndex = 1;
            this.btnDeleteLabel.Text = "删除标签";
            this.btnDeleteLabel.UseVisualStyleBackColor = false;
            this.btnDeleteLabel.Click += new System.EventHandler(this.btnDeleteLabel_Click);
            // 
            // btnAddNewLabel
            // 
            this.btnAddNewLabel.BackColor = System.Drawing.Color.GreenYellow;
            this.btnAddNewLabel.Location = new System.Drawing.Point(5, 19);
            this.btnAddNewLabel.Name = "btnAddNewLabel";
            this.btnAddNewLabel.Size = new System.Drawing.Size(75, 23);
            this.btnAddNewLabel.TabIndex = 0;
            this.btnAddNewLabel.Text = "新增标签";
            this.btnAddNewLabel.UseVisualStyleBackColor = false;
            this.btnAddNewLabel.Click += new System.EventHandler(this.btnAddNewLabel_Click);
            // 
            // flowLabels
            // 
            this.flowLabels.AutoScroll = true;
            this.flowLabels.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLabels.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLabels.Location = new System.Drawing.Point(0, 0);
            this.flowLabels.Name = "flowLabels";
            this.flowLabels.Size = new System.Drawing.Size(769, 177);
            this.flowLabels.TabIndex = 0;
            // 
            // PrimConfigControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbTitle);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "PrimConfigControl";
            this.Size = new System.Drawing.Size(875, 516);
            this.Load += new System.EventHandler(this.PrimConfigControl_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.pic1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tPageConfig.ResumeLayout(false);
            this.tPageConfig.PerformLayout();
            this.tPageLabels.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbPrimName;
        private System.Windows.Forms.Label lbTitle;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel pic1;
        private System.Windows.Forms.TableLayoutPanel table;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tPageConfig;
        private System.Windows.Forms.Button btnUpdateTable;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbRowCount;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbColCount;
        private System.Windows.Forms.TextBox tbIntervalYPos;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbIntervalXPos;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbY1Pos;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbX1Pos;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbY2Pos;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbX2Pos;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnLoadPic;
        private System.Windows.Forms.TextBox tbPicName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBrowser;
        private System.Windows.Forms.TextBox tbFilePath;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tPageLabels;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Button btnDeleteLabel;
        private System.Windows.Forms.Button btnAddNewLabel;
        private System.Windows.Forms.FlowLayoutPanel flowLabels;
        private System.Windows.Forms.Button btnBrowserLabelsConfigPath;
        private System.Windows.Forms.TextBox tbLabelsFilePath;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnApplyConfigs;
    }
}
