﻿using System;
using System.Collections.Concurrent;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Xml;
using Lead.CPrim.Interfaces;
using Lead.CPrim.ShowPicShowResult.Controls;
using Lead.CPrim.XmlHelper;

namespace Lead.CPrim.ShowPicShowResult
{
    public class ShowPicShowResult : IShow, IPicShowResult
    {
        private PicShowResultConfig _config;

        public ShowPicShowResult()
        {
            _config = new PicShowResultConfig();
            ConfigUi = new ShowConfigControl(this);
            OutputUi = new ShowOutputControl(this);
        }

        public ShowPicShowResult(XmlNode xmlNode)
        {
            if (xmlNode != null)
                _config = XMLHelper.XMLToObject(xmlNode, typeof(PicShowResultConfig)) as PicShowResultConfig;
            else
                return;

            ImportLabels();
            ConfigUi = new ShowConfigControl(this);
            OutputUi = new ShowOutputControl(this);
        }

        public int AddFaiByLocation(string faiName, double faiValue, int xPos, int yPos,
            ShowColor labelColor = ShowColor.Black)
        {
            var font = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Bold);
            Color color;
            switch (labelColor)
            {
                case ShowColor.Red:
                    color = Color.Red;
                    break;

                case ShowColor.Black:
                    color = Color.Black;
                    break;

                case ShowColor.White:
                    color = Color.White;
                    break;

                case ShowColor.Yellow:
                    color = Color.Yellow;
                    break;

                case ShowColor.Blue:
                    color = Color.Blue;
                    break;

                case ShowColor.Green:
                    color = Color.Green;
                    break;

                default:
                    throw new ArgumentOutOfRangeException(nameof(labelColor), labelColor, null);
            }

            ((ShowOutputControl)OutputUi).AddFaiByLocation(faiName, faiValue, xPos, yPos, font, color);
            return 0;
        }

        public int AddResult(string labelName, int rowNum, int colNum, string labelFont = null,
            string labelColor = null)
        {
            var font = SystemFonts.DefaultFont;
            var color = SystemColors.Control;
            var label = Labels.FirstOrDefault(p => p.Value.LabelName == labelName);

            if (label.Value != null) //找到该label
            {
                if (!string.IsNullOrEmpty(label.Value.LabelFont))
                    font = new FontConverter().ConvertFromString(label.Value.LabelFont) as Font;

                if (!string.IsNullOrEmpty(label.Value.LabelColor))
                    color = (Color)new ColorConverter().ConvertFromString(label.Value.LabelColor);
            }

            if (!string.IsNullOrEmpty(labelFont)) font = new FontConverter().ConvertFromString(labelFont) as Font;

            if (!string.IsNullOrEmpty(labelColor)) color = (Color)new ColorConverter().ConvertFromString(labelColor);

            //((PrimConfigControl)_primConfigUI).AddLabel(labelName, rowNum, colNum, font, color);
            ((ShowOutputControl)OutputUi).AddLabel(labelName, rowNum, colNum, font, color);
            return 0;
        }

        public int AddResultByLocation(string labelName, int xPos, int yPos, string labelFont = null,
            string labelColor = null)
        {
            var font = SystemFonts.DefaultFont;
            var color = Color.Black;
            var label = Labels.FirstOrDefault(p => p.Value.LabelName == labelName);

            if (label.Value != null) //找到该label
            {
                if (!string.IsNullOrEmpty(label.Value.LabelFont))
                    font = new FontConverter().ConvertFromString(label.Value.LabelFont) as Font;

                if (!string.IsNullOrEmpty(label.Value.LabelColor))
                    color = (Color)new ColorConverter().ConvertFromString(label.Value.LabelColor);
            }

            if (!string.IsNullOrEmpty(labelFont)) font = new FontConverter().ConvertFromString(labelFont) as Font;

            if (!string.IsNullOrEmpty(labelColor)) color = (Color)new ColorConverter().ConvertFromString(labelColor);

            //((PrimConfigControl)_primConfigUI).AddLabelByLocation(labelName, xPos, yPos, font, color);
            ((ShowOutputControl)OutputUi).AddLabelByLocation(labelName, xPos, yPos, font, color);

            return 0;
        }

        public int AddResultByLocation(string labelName, int xPos, int yPos, ShowColor labelColor = ShowColor.Black,
            string labelFont = null)
        {
            var font = SystemFonts.DefaultFont;
            Color color;
            switch (labelColor)
            {
                case ShowColor.Red:
                    color = Color.Red;
                    break;

                case ShowColor.Black:
                    color = Color.Black;
                    break;

                case ShowColor.White:
                    color = Color.White;
                    break;

                case ShowColor.Yellow:
                    color = Color.Yellow;
                    break;

                case ShowColor.Blue:
                    color = Color.Blue;
                    break;

                default:
                    throw new ArgumentOutOfRangeException(nameof(labelColor), labelColor, null);
            }

            if (!string.IsNullOrEmpty(labelFont)) font = new FontConverter().ConvertFromString(labelFont) as Font;

            //((PrimConfigControl)_primConfigUI).AddLabelByLocation(labelName, xPos, yPos, font, color);
            ((ShowOutputControl)OutputUi).AddLabelByLocation(labelName, xPos, yPos, font, color);

            return 0;
        }

        public int AddResults(string[] labelNames, int[] rowNums, int[] colNums)
        {
            if (labelNames.Length == rowNums.Length && rowNums.Length != colNums.Length)
            {
                for (var i = 0; i < labelNames.Length; i++) AddResult(labelNames[i], rowNums[i], colNums[i]);
                return 0;
            }

            return -1;
        }

        public int AddResults(string[] labelNames)
        {
            for (var i = 0; i < labelNames.Length; i++)
            {
                if (i + 1 > RowCount * ColumnCount) break;

                AddResult(labelNames[i], i / ColumnCount + 1, i % ColumnCount + 1);
            }

            return 0;
        }

        public int ClearPicture()
        {
            ((ShowConfigControl)ConfigUi).ClearPicture();
            ((ShowOutputControl)OutputUi).ClearPicture();
            return 0;
        }

        public int ClearResults()
        {
            ((ShowConfigControl)ConfigUi).ClearLabels();
            ((ShowOutputControl)OutputUi).ClearLabels();
            return 0;
        }

        public void ExportLabels()
        {
            JsonHelper.JsonHelper.SerializeObjectToFile(Labels, LabelsConfigPath);
        }

        public void ImportLabels()
        {
            Labels =
                JsonHelper.JsonHelper.DeserializeJsonFileToObject<ConcurrentDictionary<Guid, LabelInfo>>(
                    LabelsConfigPath);
        }

        public bool IsContainLabelInfo(string labelName)
        {
            var label = Labels.FirstOrDefault(p => p.Value.LabelName == labelName);

            return label.Value != null;
        }

        public int IShowDispose()
        {
            var iRet = 0;
            return iRet;
        }

        public XmlNode IShowExportConfigXml()
        {
            if (_config == null) return null;

            var node = XMLHelper.ObjectToXML(_config);

            return node;
        }

        public int IShowImportConfigXml(XmlNode xmlNode)
        {
            var iRet = 0;
            if (xmlNode != null)
                _config = XMLHelper.XMLToObject(xmlNode, typeof(PicShowResultConfig)) as PicShowResultConfig;
            else
                return -1;

            return iRet;
        }

        public int LoadPicture(string productName = null)
        {
            if (string.IsNullOrEmpty(productName))
            {
                ((ShowConfigControl)ConfigUi).LoadPicture(PicFilePath, PicFileName);
                ((ShowOutputControl)OutputUi).LoadPicture(PicFilePath, PicFileName);
            }
            else
            {
                ((ShowConfigControl)ConfigUi).LoadPicture($@"{PicFilePath}\{productName}", PicFileName);
                ((ShowOutputControl)OutputUi).LoadPicture($@"{PicFilePath}\{productName}", PicFileName);
            }

            ((ShowConfigControl)ConfigUi).UpdateTable(OriginX, OriginY, RowCount,
                ColumnCount, IntervalX, IntervalY);
            ((ShowOutputControl)OutputUi).UpdateTable(OriginX, OriginY, RowCount,
                ColumnCount, IntervalX, IntervalY);

            ClearResults();

            return 0;
        }

        public int UpdateTable(int rowCount, int colCount)
        {
            ((ShowConfigControl)ConfigUi).UpdateTable(OriginX, OriginY, rowCount,
                colCount, IntervalX, IntervalY);
            ((ShowOutputControl)OutputUi).UpdateTable(OriginX, OriginY, rowCount,
                colCount, IntervalX, IntervalY);
            return 0;
        }

        public int UpdateTable(int rowCount, int colCount, int originX, int originY, int intervalX, int intervalY)
        {
            ((ShowConfigControl)ConfigUi).UpdateTable(originX, originY, rowCount,
                colCount, intervalX, intervalY);
            ((ShowOutputControl)OutputUi).UpdateTable(originX, originY, rowCount,
                colCount, intervalX, intervalY);
            return 0;
        }

        #region Override IShow's property

        public Control ConfigUi { get; }

        public bool Enable
        {
            set => _config.Enable = value;
            get => _config.Enable;
        }

        public Guid Id
        {
            set => _config.Id = value;
            get => _config.Id;
        }

        public string Name
        {
            set => _config.Name = value;
            get => _config.Name;
        }

        public Control OutputUi { get; }

        public string ShowTypeName
        {
            set => _config.ShowTypeName = value;
            get => _config.ShowTypeName;
        }

        public string Version
        {
            set => _config.Version = value;
            get => _config.Version;
        }

        #endregion Override IShow's property

        #region Override Config's other property

        public int ColumnCount
        {
            set => _config.ColumnCount = value;
            get => _config.ColumnCount;
        }

        public int IntervalX
        {
            set => _config.IntervalX = value;
            get => _config.IntervalX;
        }

        public int IntervalY
        {
            set => _config.IntervalY = value;
            get => _config.IntervalY;
        }

        public ConcurrentDictionary<Guid, LabelInfo> Labels { set; get; } = new ConcurrentDictionary<Guid, LabelInfo>();

        public string LabelsConfigPath
        {
            set => _config.LabelsConfigPath = value;
            get => _config.LabelsConfigPath;
        }

        public int OriginX
        {
            set => _config.OriginX = value;
            get => _config.OriginX;
        }

        public int OriginY
        {
            set => _config.OriginY = value;
            get => _config.OriginY;
        }

        public string PicFileName
        {
            set => _config.PicFileName = value;
            get => _config.PicFileName;
        }

        public string PicFilePath
        {
            set => _config.PicFilePath = value;
            get => _config.PicFilePath;
        }

        public int RowCount
        {
            set => _config.RowCount = value;
            get => _config.RowCount;
        }

        #endregion Override Config's other property
    }
}