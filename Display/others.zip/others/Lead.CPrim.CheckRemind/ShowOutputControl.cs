﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lead.CPrim.CommonTools;

namespace Lead.CPrim.CheckRemind
{
    public partial class ShowOutputControl : UserControl
    {
        private CheckRemind _show;
        private int _partIndex;
        public ShowOutputControl()
        {
            InitializeComponent();
        }
        public ShowOutputControl(CheckRemind show)
        {
            _show = show;
            InitializeComponent();
        }

        internal void ClearInfos()
        {
            _partIndex = 0;
            dgvRtData.Columns.Clear();
            dgvRtData.DataSource = null;
        }
        internal void AddPartInfo(string barCode, string result, Dictionary<object, object> dicFaiValues, Dictionary<string, bool> dicFaiResults, string productName = null, bool insertFlag = false)
        {
            if (!Created || !IsHandleCreated)
            {
                return;
            }
            if (dgvRtData.InvokeRequired)
            {
                BeginInvoke(new Action<string, string, Dictionary<object, object>, Dictionary<string, bool>, string, bool>(AddPartInfo), barCode, result, dicFaiValues, dicFaiResults, productName, insertFlag);
            }
            else
            {
                if (string.IsNullOrEmpty(productName))
                {
                    productName = _show.TotalTypeTruth.CurrentProduct;
                }

                if (!_show.TotalTypeTruth.TotalProcutTypeConfigs.ContainsKey(productName))
                {
                    return;
                }

                var curConfig = _show.TotalTypeTruth.TotalProcutTypeConfigs[productName];

                var dicColName = new Dictionary<int, string>();
                var columnIndex = 0;

                dicColName.Add(columnIndex++, "序号");
                dicColName.Add(columnIndex++, "Barcode");
                dicColName.Add(columnIndex++, "结果");
                if (curConfig.FaiConfigs.TotalFaiConfigs.Count > 0)
                {
                    foreach (var faiConfig in curConfig.FaiConfigs.TotalFaiConfigs)
                    {
                        dicColName.Add(columnIndex++, faiConfig.FaiName + "_真值");
                        dicColName.Add(columnIndex++, faiConfig.FaiName + "_实际值");
                    }
                }
                
                if (dgvRtData.Columns.Count == 0)
                {
                    foreach (var colName in dicColName)
                    {
                        dgvRtData.Columns.Add(colName.Value, colName.Value);
                    }
                }

                var values = new object[dicColName.Count];
                values[0] = _partIndex++;
                values[1] = barCode;
                values[2] = result;
                var truthConfig = curConfig.FindBarcode(barCode);
                foreach (var faiConfig in curConfig.FaiConfigs.TotalFaiConfigs)
                {
                    var colIndex = dicColName.FirstOrDefault(x => x.Value == faiConfig.FaiName + "_真值")
                        .Key;
                    values[colIndex] = truthConfig.TruthValues.ContainsKey(faiConfig.FaiName) ? truthConfig.TruthValues[faiConfig.FaiName] : 0;
                }

                foreach (var dicItem in dicFaiValues)
                {
                    if (!curConfig.FaiConfigs.ContainFaiName(dicItem.Key.ToString()))
                    {
                        continue;
                    }
                    var colIndex = dicColName.FirstOrDefault(x => x.Value == dicItem.Key + "_实际值")
                        .Key;
                    values[colIndex] = dicItem.Value;
                }

                if (insertFlag)
                {
                    dgvRtData.Rows.Insert(0, values);
                }
                else
                {
                    dgvRtData.Rows.Add(values);
                }

                var rowIndex = insertFlag ? 0 : dgvRtData.Rows.Count - 1;

                if (dicFaiResults != null)
                {
                    foreach (var fai in dicFaiResults.Keys)
                    {
                        foreach (var col in dicColName)
                        {
                            if (col.Value.Contains("_实际值"))
                            {
                                var colNames = col.Value.Split(new string[]{ "_实际值" }, StringSplitOptions.None);
                                if (colNames[0] == fai && dicFaiResults.ContainsKey(fai))
                                {
                                    dgvRtData.Rows[rowIndex].Cells[col.Key].Style.ForeColor = dicFaiResults[fai] ? Color.Green : Color.Red;
                                }
                            }
                        }
                    }
                }

                dgvRtData.Rows[rowIndex].Cells[2].Style.BackColor =
                    result.ToLower().Contains("ok") ? Color.Green : Color.Red;
            }
        }

        private void 导出数据ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ControlHelper.SaveDgvDataToCsvFile(ref dgvRtData);
        }
    }
}
