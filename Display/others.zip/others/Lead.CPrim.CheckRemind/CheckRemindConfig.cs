﻿using System;
using System.Collections.Generic;

namespace Lead.CPrim.CheckRemind
{
    public class CheckRemindConfig
    {
        public bool Enable { set; get; }
        public Guid Id { set; get; }
        public string Name { set; get; }
        public string ShowTypeName { set; get; }
        public string Version { set; get; }
        /// <summary>
        /// 点检提示时间间隔（天）
        /// </summary>
        public int CheckInterval { get; set; }
        /// <summary>
        /// 上次点检时间
        /// </summary>
        public DateTime LastCheckTime { get; set; }
        public string ConfigPath { get; set; }
    }
}
