﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Xml;
using Lead.CPrim.Interfaces;
using Lead.CPrim.XmlHelper;

namespace Lead.CPrim.CheckRemind
{
    public class CheckRemind : IShow
    {
        internal CheckRemindConfig _config;
        public TotalTypeTruth TotalTypeTruth { set; get; }
        public CheckRemind()
        {
            _config = new CheckRemindConfig();
            ConfigUi = new ShowConfigControl(this);
            OutputUi = new ShowOutputControl(this);
            TotalTypeTruth = new TotalTypeTruth();
        }
        public CheckRemind(XmlNode xmlNode)
        {
            if (xmlNode != null)
                _config = XMLHelper.XMLToObject(xmlNode, typeof(CheckRemindConfig)) as CheckRemindConfig;
            else
                return;
            
            ConfigUi = new ShowConfigControl(this);
            OutputUi = new ShowOutputControl(this);
            LoadConfig();
        }
        #region IShow Function
        public Control ConfigUi { get; }
        public Control OutputUi { get; }
        public bool Enable
        {
            set => _config.Enable = value;
            get => _config.Enable;
        }
        public Guid Id
        {
            get => _config.Id;
            set => _config.Id = value;
        }
        public string Name
        {
            set => _config.Name = value;
            get => _config.Name;
        }
        public string ShowTypeName
        {
            set => _config.ShowTypeName = value;
            get => _config.ShowTypeName;
        }
        public string Version
        {
            set => _config.Version = value;
            get => _config.Version;
        }
        public int CheckInterval
        {
            set => _config.CheckInterval = value;
            get => _config.CheckInterval;
        }
        public DateTime LastCheckTime
        {
            set => _config.LastCheckTime = value;
            get => _config.LastCheckTime;
        }
        public string ConfigPath
        {
            set => _config.ConfigPath = value;
            get => _config.ConfigPath;
        }
        public int IShowDispose()
        {
            var iRet = 0;
            return iRet;
        }

        public int IShowImportConfigXml(XmlNode xmlNode)
        {
            var iRet = 0;
            if (xmlNode != null)
                _config = XMLHelper.XMLToObject(xmlNode, typeof(CheckRemindConfig)) as CheckRemindConfig;
            else
                return -1;
            return iRet;
        }

        public XmlNode IShowExportConfigXml()
        {
            if (_config == null) return null;
            var node = XMLHelper.ObjectToXML(_config);

            return node;
        }

        internal int SaveConfig()
        {
            if (string.IsNullOrEmpty(ConfigPath))
            {
                return -1;
            }
            var serialzeFlag= JsonHelper.JsonHelper.SerializeObjectToFile(TotalTypeTruth, ConfigPath);
            return serialzeFlag ? 0 : -10;
        }
        internal int LoadConfig()
        {
            if (string.IsNullOrEmpty(ConfigPath))
            {
                TotalTypeTruth = new TotalTypeTruth();
            }
            else
            {
                TotalTypeTruth = JsonHelper.JsonHelper.DeserializeJsonFileToObject<TotalTypeTruth>(ConfigPath);
                if (TotalTypeTruth == null)
                {
                    TotalTypeTruth = new TotalTypeTruth();
                }
            }

            return 0;
        }

        internal int LoadProductConfig(string productName)
        {
            if (string.IsNullOrEmpty(productName))
            {
                return -1;
            }

            TotalTypeTruth.CurrentProduct = productName;
            return 0;
        }
        #endregion

        #region ICheckRemind's Function

        public void AddPart(string barCode, string result, Dictionary<object, object> dicFaiValues, Dictionary<string, bool> dicFaiResults, string productName = null, bool insertFlag = false)
        {
            ((ShowOutputControl)OutputUi).AddPartInfo(barCode, result, dicFaiValues, dicFaiResults, productName, insertFlag);
        }

        public void ClearDgv()
        {
            ((ShowOutputControl)OutputUi).ClearInfos();
        }
        #endregion
    }
}
