﻿using System.Xml;
using Lead.CPrim.Interfaces;
namespace Lead.CPrim.CheckRemind
{
    public class ShowCreator : IShowCreator
    {
        public IShowTypeAttributes ConcreteShowTypeAttributes => new ShowTypeAttributes();

        IShow IShowCreator.Create(XmlNode showConfig)
        {
            return new CheckRemind(showConfig);
        }

        IShow IShowCreator.Create()
        {
            return new CheckRemind();
        }
    }
}
