﻿
namespace Lead.CPrim.CheckRemind
{
    partial class ShowConfigControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBrowerEBusConfig = new System.Windows.Forms.Button();
            this.tbConfigPath = new System.Windows.Forms.TextBox();
            this.btnNewPro = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.cmbSelProduct = new System.Windows.Forms.ComboBox();
            this.labProductName = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.dgvTruth = new System.Windows.Forms.DataGridView();
            this.Index = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Barcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnAddInfo = new System.Windows.Forms.Button();
            this.btnTruthApply = new System.Windows.Forms.Button();
            this.btnDelTruth = new System.Windows.Forms.Button();
            this.btnAddTruth = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.dgvFai = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.grpbxCfg = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.domainUpDown1 = new System.Windows.Forms.DomainUpDown();
            this.chkEnOffset = new System.Windows.Forms.CheckBox();
            this.btnFaiApply = new System.Windows.Forms.Button();
            this.btnDelFai = new System.Windows.Forms.Button();
            this.btnAddFai = new System.Windows.Forms.Button();
            this.saveConfigFile = new System.Windows.Forms.SaveFileDialog();
            this.openConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.复制数据ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.粘贴数据ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTruth)).BeginInit();
            this.panel3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFai)).BeginInit();
            this.panel2.SuspendLayout();
            this.grpbxCfg.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tabControl1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.44344F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87.55656F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1307, 728);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnBrowerEBusConfig);
            this.panel1.Controls.Add(this.tbConfigPath);
            this.panel1.Controls.Add(this.btnNewPro);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.cmbSelProduct);
            this.panel1.Controls.Add(this.labProductName);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 4);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1301, 82);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(476, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 17);
            this.label1.TabIndex = 26;
            this.label1.Text = "配置文件路径：";
            // 
            // btnBrowerEBusConfig
            // 
            this.btnBrowerEBusConfig.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnBrowerEBusConfig.Location = new System.Drawing.Point(1181, 27);
            this.btnBrowerEBusConfig.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnBrowerEBusConfig.Name = "btnBrowerEBusConfig";
            this.btnBrowerEBusConfig.Size = new System.Drawing.Size(47, 28);
            this.btnBrowerEBusConfig.TabIndex = 25;
            this.btnBrowerEBusConfig.Text = "...";
            this.btnBrowerEBusConfig.UseVisualStyleBackColor = false;
            this.btnBrowerEBusConfig.Click += new System.EventHandler(this.btnBrowerEBusConfig_Click);
            // 
            // tbConfigPath
            // 
            this.tbConfigPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.tbConfigPath.Location = new System.Drawing.Point(588, 28);
            this.tbConfigPath.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.tbConfigPath.Name = "tbConfigPath";
            this.tbConfigPath.Size = new System.Drawing.Size(585, 20);
            this.tbConfigPath.TabIndex = 24;
            // 
            // btnNewPro
            // 
            this.btnNewPro.Location = new System.Drawing.Point(260, 16);
            this.btnNewPro.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnNewPro.Name = "btnNewPro";
            this.btnNewPro.Size = new System.Drawing.Size(101, 51);
            this.btnNewPro.TabIndex = 3;
            this.btnNewPro.Text = "新增产品";
            this.btnNewPro.UseVisualStyleBackColor = true;
            this.btnNewPro.Click += new System.EventHandler(this.btnNewPro_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(369, 16);
            this.btnSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 51);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "保存";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // cmbSelProduct
            // 
            this.cmbSelProduct.FormattingEnabled = true;
            this.cmbSelProduct.Location = new System.Drawing.Point(86, 28);
            this.cmbSelProduct.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbSelProduct.Name = "cmbSelProduct";
            this.cmbSelProduct.Size = new System.Drawing.Size(140, 25);
            this.cmbSelProduct.TabIndex = 1;
            this.cmbSelProduct.SelectedIndexChanged += new System.EventHandler(this.cmbSelProduct_SelectedIndexChanged);
            // 
            // labProductName
            // 
            this.labProductName.AutoSize = true;
            this.labProductName.Location = new System.Drawing.Point(17, 33);
            this.labProductName.Name = "labProductName";
            this.labProductName.Size = new System.Drawing.Size(56, 17);
            this.labProductName.TabIndex = 0;
            this.labProductName.Text = "当前产品";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(3, 94);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1301, 630);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tableLayoutPanel3);
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(1293, 600);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "真值配置";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 82.04182F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.95818F));
            this.tableLayoutPanel3.Controls.Add(this.dgvTruth, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel3, 1, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 4);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1287, 592);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // dgvTruth
            // 
            this.dgvTruth.AllowUserToAddRows = false;
            this.dgvTruth.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTruth.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Index,
            this.Barcode});
            this.dgvTruth.ContextMenuStrip = this.contextMenuStrip1;
            this.dgvTruth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTruth.Location = new System.Drawing.Point(3, 4);
            this.dgvTruth.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvTruth.Name = "dgvTruth";
            this.dgvTruth.RowTemplate.Height = 23;
            this.dgvTruth.Size = new System.Drawing.Size(1049, 584);
            this.dgvTruth.TabIndex = 0;
            // 
            // Index
            // 
            this.Index.HeaderText = "序号";
            this.Index.Name = "Index";
            // 
            // Barcode
            // 
            this.Barcode.HeaderText = "条码";
            this.Barcode.Name = "Barcode";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnClear);
            this.panel3.Controls.Add(this.btnAddInfo);
            this.panel3.Controls.Add(this.btnTruthApply);
            this.panel3.Controls.Add(this.btnDelTruth);
            this.panel3.Controls.Add(this.btnAddTruth);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(1058, 4);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(226, 584);
            this.panel3.TabIndex = 1;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(54, 290);
            this.btnClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(117, 48);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "清除";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnAddInfo
            // 
            this.btnAddInfo.Location = new System.Drawing.Point(54, 347);
            this.btnAddInfo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAddInfo.Name = "btnAddInfo";
            this.btnAddInfo.Size = new System.Drawing.Size(117, 48);
            this.btnAddInfo.TabIndex = 6;
            this.btnAddInfo.Text = "测试添加aa";
            this.btnAddInfo.UseVisualStyleBackColor = true;
            this.btnAddInfo.Click += new System.EventHandler(this.btnAddInfo_Click);
            // 
            // btnTruthApply
            // 
            this.btnTruthApply.Location = new System.Drawing.Point(29, 197);
            this.btnTruthApply.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTruthApply.Name = "btnTruthApply";
            this.btnTruthApply.Size = new System.Drawing.Size(117, 48);
            this.btnTruthApply.TabIndex = 5;
            this.btnTruthApply.Text = "应用";
            this.btnTruthApply.UseVisualStyleBackColor = true;
            this.btnTruthApply.Click += new System.EventHandler(this.btnTruthApply_Click);
            // 
            // btnDelTruth
            // 
            this.btnDelTruth.Location = new System.Drawing.Point(29, 113);
            this.btnDelTruth.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDelTruth.Name = "btnDelTruth";
            this.btnDelTruth.Size = new System.Drawing.Size(117, 50);
            this.btnDelTruth.TabIndex = 4;
            this.btnDelTruth.Text = "删除";
            this.btnDelTruth.UseVisualStyleBackColor = true;
            this.btnDelTruth.Click += new System.EventHandler(this.btnDelTruth_Click);
            // 
            // btnAddTruth
            // 
            this.btnAddTruth.Location = new System.Drawing.Point(29, 38);
            this.btnAddTruth.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAddTruth.Name = "btnAddTruth";
            this.btnAddTruth.Size = new System.Drawing.Size(117, 50);
            this.btnAddTruth.TabIndex = 3;
            this.btnAddTruth.Text = "新增";
            this.btnAddTruth.UseVisualStyleBackColor = true;
            this.btnAddTruth.Click += new System.EventHandler(this.btnAddTruth_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tableLayoutPanel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Size = new System.Drawing.Size(1293, 600);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Fai项配置";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75.52276F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.47725F));
            this.tableLayoutPanel2.Controls.Add(this.dgvFai, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel2, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 4);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1287, 592);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // dgvFai
            // 
            this.dgvFai.AllowUserToAddRows = false;
            this.dgvFai.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFai.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column3,
            this.Column2});
            this.dgvFai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvFai.Location = new System.Drawing.Point(3, 4);
            this.dgvFai.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvFai.Name = "dgvFai";
            this.dgvFai.RowTemplate.Height = 23;
            this.dgvFai.Size = new System.Drawing.Size(965, 584);
            this.dgvFai.TabIndex = 0;
            // 
            // Column1
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle4;
            this.Column1.HeaderText = "Fai名称";
            this.Column1.Name = "Column1";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "使能";
            this.Column3.Name = "Column3";
            this.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "偏差允许值";
            this.Column2.Name = "Column2";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.grpbxCfg);
            this.panel2.Controls.Add(this.btnFaiApply);
            this.panel2.Controls.Add(this.btnDelFai);
            this.panel2.Controls.Add(this.btnAddFai);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(974, 4);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(310, 584);
            this.panel2.TabIndex = 1;
            // 
            // grpbxCfg
            // 
            this.grpbxCfg.Controls.Add(this.groupBox2);
            this.grpbxCfg.Controls.Add(this.groupBox1);
            this.grpbxCfg.Controls.Add(this.chkEnOffset);
            this.grpbxCfg.Location = new System.Drawing.Point(3, 190);
            this.grpbxCfg.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpbxCfg.Name = "grpbxCfg";
            this.grpbxCfg.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpbxCfg.Size = new System.Drawing.Size(218, 364);
            this.grpbxCfg.TabIndex = 4;
            this.grpbxCfg.TabStop = false;
            this.grpbxCfg.Text = "点检配置";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Location = new System.Drawing.Point(8, 194);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(203, 82);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "上次点检时间";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(9, 30);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(186, 23);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "2021/4/12";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.domainUpDown1);
            this.groupBox1.Location = new System.Drawing.Point(8, 103);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(203, 82);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "点检间隔(天)";
            // 
            // domainUpDown1
            // 
            this.domainUpDown1.Items.Add("1");
            this.domainUpDown1.Items.Add("2");
            this.domainUpDown1.Items.Add("3");
            this.domainUpDown1.Items.Add("4");
            this.domainUpDown1.Items.Add("5");
            this.domainUpDown1.Items.Add("6");
            this.domainUpDown1.Items.Add("7");
            this.domainUpDown1.Items.Add("8");
            this.domainUpDown1.Items.Add("9");
            this.domainUpDown1.Items.Add("10");
            this.domainUpDown1.Items.Add("11");
            this.domainUpDown1.Items.Add("12");
            this.domainUpDown1.Items.Add("13");
            this.domainUpDown1.Items.Add("14");
            this.domainUpDown1.Items.Add("15");
            this.domainUpDown1.Items.Add("16");
            this.domainUpDown1.Items.Add("17");
            this.domainUpDown1.Items.Add("18");
            this.domainUpDown1.Items.Add("19");
            this.domainUpDown1.Items.Add("20");
            this.domainUpDown1.Items.Add("21");
            this.domainUpDown1.Items.Add("22");
            this.domainUpDown1.Items.Add("23");
            this.domainUpDown1.Items.Add("24");
            this.domainUpDown1.Items.Add("25");
            this.domainUpDown1.Items.Add("26");
            this.domainUpDown1.Items.Add("27");
            this.domainUpDown1.Items.Add("28");
            this.domainUpDown1.Items.Add("29");
            this.domainUpDown1.Items.Add("30");
            this.domainUpDown1.Location = new System.Drawing.Point(9, 28);
            this.domainUpDown1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.domainUpDown1.Name = "domainUpDown1";
            this.domainUpDown1.Size = new System.Drawing.Size(156, 23);
            this.domainUpDown1.TabIndex = 0;
            this.domainUpDown1.Text = "1";
            // 
            // chkEnOffset
            // 
            this.chkEnOffset.AutoSize = true;
            this.chkEnOffset.Location = new System.Drawing.Point(7, 42);
            this.chkEnOffset.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkEnOffset.Name = "chkEnOffset";
            this.chkEnOffset.Size = new System.Drawing.Size(99, 21);
            this.chkEnOffset.TabIndex = 3;
            this.chkEnOffset.Text = "自动修正补偿";
            this.chkEnOffset.UseVisualStyleBackColor = true;
            // 
            // btnFaiApply
            // 
            this.btnFaiApply.Location = new System.Drawing.Point(21, 133);
            this.btnFaiApply.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnFaiApply.Name = "btnFaiApply";
            this.btnFaiApply.Size = new System.Drawing.Size(117, 48);
            this.btnFaiApply.TabIndex = 2;
            this.btnFaiApply.Text = "应用";
            this.btnFaiApply.UseVisualStyleBackColor = true;
            this.btnFaiApply.Click += new System.EventHandler(this.btnFaiApply_Click);
            // 
            // btnDelFai
            // 
            this.btnDelFai.Location = new System.Drawing.Point(21, 75);
            this.btnDelFai.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDelFai.Name = "btnDelFai";
            this.btnDelFai.Size = new System.Drawing.Size(117, 50);
            this.btnDelFai.TabIndex = 1;
            this.btnDelFai.Text = "删除";
            this.btnDelFai.UseVisualStyleBackColor = true;
            this.btnDelFai.Click += new System.EventHandler(this.btnDelFai_Click);
            // 
            // btnAddFai
            // 
            this.btnAddFai.Location = new System.Drawing.Point(21, 17);
            this.btnAddFai.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAddFai.Name = "btnAddFai";
            this.btnAddFai.Size = new System.Drawing.Size(117, 50);
            this.btnAddFai.TabIndex = 0;
            this.btnAddFai.Text = "新增";
            this.btnAddFai.UseVisualStyleBackColor = true;
            this.btnAddFai.Click += new System.EventHandler(this.btnAddFai_Click);
            // 
            // saveConfigFile
            // 
            this.saveConfigFile.FileName = "Config";
            this.saveConfigFile.Filter = "json File|*.json|All File|*.*";
            // 
            // openConfigFile
            // 
            this.openConfigFile.FileName = "Config";
            this.openConfigFile.Filter = "json File|*.json|All File|*.*";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.复制数据ToolStripMenuItem,
            this.粘贴数据ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(125, 48);
            // 
            // 复制数据ToolStripMenuItem
            // 
            this.复制数据ToolStripMenuItem.Name = "复制数据ToolStripMenuItem";
            this.复制数据ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.复制数据ToolStripMenuItem.Text = "复制数据";
            this.复制数据ToolStripMenuItem.Click += new System.EventHandler(this.复制数据ToolStripMenuItem_Click);
            // 
            // 粘贴数据ToolStripMenuItem
            // 
            this.粘贴数据ToolStripMenuItem.Name = "粘贴数据ToolStripMenuItem";
            this.粘贴数据ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.粘贴数据ToolStripMenuItem.Text = "粘贴数据";
            this.粘贴数据ToolStripMenuItem.Click += new System.EventHandler(this.粘贴数据ToolStripMenuItem_Click);
            // 
            // ShowConfigControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ShowConfigControl";
            this.Size = new System.Drawing.Size(1307, 728);
            this.Load += new System.EventHandler(this.ShowConfigControl_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTruth)).EndInit();
            this.panel3.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFai)).EndInit();
            this.panel2.ResumeLayout(false);
            this.grpbxCfg.ResumeLayout(false);
            this.grpbxCfg.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnNewPro;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ComboBox cmbSelProduct;
        private System.Windows.Forms.Label labProductName;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.DataGridView dgvFai;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnFaiApply;
        private System.Windows.Forms.Button btnDelFai;
        private System.Windows.Forms.Button btnAddFai;
        private System.Windows.Forms.DataGridView dgvTruth;
        private System.Windows.Forms.DataGridViewTextBoxColumn Index;
        private System.Windows.Forms.DataGridViewTextBoxColumn Barcode;
        private System.Windows.Forms.CheckBox chkEnOffset;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnTruthApply;
        private System.Windows.Forms.Button btnDelTruth;
        private System.Windows.Forms.Button btnAddTruth;
        private System.Windows.Forms.GroupBox grpbxCfg;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DomainUpDown domainUpDown1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBrowerEBusConfig;
        private System.Windows.Forms.TextBox tbConfigPath;
        private System.Windows.Forms.SaveFileDialog saveConfigFile;
        private System.Windows.Forms.OpenFileDialog openConfigFile;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnAddInfo;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 复制数据ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 粘贴数据ToolStripMenuItem;
    }
}
