﻿using Lead.CPrim.CommonTools;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lead.CPrim.CheckRemind
{
    public partial class ShowConfigControl : UserControl
    {
        private CheckRemind _show;

        TotalTypeTruth TotalTypeTruth
        {
            get
            {
                if (_show != null)
                {
                    if (_show.TotalTypeTruth == null)
                    {
                        _show.TotalTypeTruth = new TotalTypeTruth();
                    }

                    return _show.TotalTypeTruth;
                }

                return null;
            }
        }
        FaiConfigs FaiConfigs
        {
            get
            {
                if (_show != null && _show.TotalTypeTruth != null && _show.TotalTypeTruth.CurrentProductTruth != null)
                {
                    if (_show.TotalTypeTruth.CurrentProductTruth.FaiConfigs == null)
                    {
                        _show.TotalTypeTruth.CurrentProductTruth.FaiConfigs = new FaiConfigs();
                    }

                    return _show.TotalTypeTruth.CurrentProductTruth.FaiConfigs;
                }

                return null;
            }
        }
        public ShowConfigControl()
        {
            InitializeComponent();

        }
        public ShowConfigControl(CheckRemind show)
        {
            InitializeComponent();
            _show = show;
        }
        private void cmbSelProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (TotalTypeTruth.TotalProcutTypeConfigs.ContainsKey(cmbSelProduct.SelectedItem.ToString()))
            {
                TotalTypeTruth.CurrentProduct = cmbSelProduct.SelectedItem.ToString();
                UpdateDgvFaiConfigs();
                UpdateDgvTruth();
            }
        }

        #region Fai配置
        private void btnFaiApply_Click(object sender, EventArgs e)
        {
            if (ControlHelper.CheckDgvCellRepeat(ref dgvFai, 0))
            {
                MessageBox.Show($@"有Fai名称重复，请检查标红项");
                return;
            }
            FaiConfigs.TotalFaiConfigs = new List<SingleFaiConfig>();
            FaiConfigs.TotalFaiConfigs.Clear();
            for (var i = 0; i < dgvFai.Rows.Count; i++)
            {
                var row = dgvFai.Rows[i];
                var newFaiConfigs = new SingleFaiConfig();
                if (row.Cells[0].Value != null)
                {
                    newFaiConfigs.FaiName = row.Cells[0].Value.ToString();
                }
                newFaiConfigs.Enable = bool.TryParse(row.Cells[1].Value.ToString(), out var bool1) && bool1;
                newFaiConfigs.LimitErr = double.TryParse(row.Cells[2].Value.ToString(), out var d22) ? d22 : 0;
                FaiConfigs.TotalFaiConfigs.Add(newFaiConfigs);
            }
            FaiConfigs.EnAutoOffset = chkEnOffset.Checked;
            RefreshDgvTruthCol();
        }

        private void btnAddFai_Click(object sender, EventArgs e)
        {
            var index = dgvFai.Rows.Add();
            var row = dgvFai.Rows[index];
            row.Cells[0].Value = "请输入Fai名称";
            row.Cells[1].Value = true;
            row.Cells[2].Value = 0.05;
            
        }

        private void btnDelFai_Click(object sender, EventArgs e)
        {
            var selectedRows = dgvFai.SelectedRows;
            if (selectedRows.Count == 0)
            {
                return;
            }
            foreach (DataGridViewRow row in selectedRows)
            {
                dgvFai.Rows.Remove(row);
            }
        }
        #endregion
        #region 真值配置
        /// <summary>
        /// 刷新真值表格列
        /// </summary>
        public void RefreshDgvTruthCol()
        {
            if (this.InvokeRequired)
            {
                BeginInvoke(new Action(RefreshDgvTruthCol));
            }
            else
            {
                foreach (var item in FaiConfigs.TotalFaiConfigs)
                {
                    if (!dgvTruth.Columns.Contains(item.FaiName))
                    {
                        dgvTruth.Columns.Add(item.FaiName, item.FaiName);
                    }
                }
                List<string> delDgvNameLst = new List<string>();
                for (int i = 2; i < dgvTruth.Columns.Count; i++)
                {
                    if (FaiConfigs.TotalFaiConfigs.FirstOrDefault(p => p.FaiName == dgvTruth.Columns[i].Name) == null)
                    {
                        delDgvNameLst.Add(dgvTruth.Columns[i].Name);
                    }
                }
                foreach (var item in delDgvNameLst)
                {
                    dgvTruth.Columns.Remove(item);
                }
            }
        }

        private void btnAddTruth_Click(object sender, EventArgs e)
        {
            var index = dgvTruth.Rows.Add();
            var row = dgvTruth.Rows[index];
            row.Cells[0].Value = index.ToString();
            row.Cells[1].Value = "输入二维码";
            for (int i = 2; i < dgvTruth.Columns.Count; i++)
            {
                row.Cells[1].Value = 0.00;
            }
        }
        private void btnDelTruth_Click(object sender, EventArgs e)
        {
            var selectedRows = dgvTruth.SelectedRows;
            if (selectedRows.Count == 0)
            {
                return;
            }
            foreach (DataGridViewRow row in selectedRows)
            {
                dgvTruth.Rows.Remove(row);
            }
        }
        private void btnTruthApply_Click(object sender, EventArgs e)
        {
            if (ControlHelper.CheckDgvCellRepeat(ref dgvTruth, 1))
            {
                MessageBox.Show($@"ID重复，请检查标红项");
                return;
            }
            TotalTypeTruth.CurrentProductTruth.TruthProducts = new List<SingleProductTruth>();
            for (var i = 0; i < dgvTruth.Rows.Count; i++)
            {
                var row = dgvTruth.Rows[i];
                var newTruth = new SingleProductTruth();
                newTruth.Barcode = row.Cells[1].Value.ToString();
                if (newTruth.TruthValues == null)
                {
                    newTruth.TruthValues = new Dictionary<string, double>();
                }
                for (int j = 0; j < dgvTruth.Columns.Count; j++)
                {
                    newTruth.TruthValues[dgvTruth.Columns[j].Name] = double.TryParse(row.Cells[j].Value.ToString(), out var d22) ? d22 : 0;
                }
                TotalTypeTruth.CurrentProductTruth.TruthProducts.Add(newTruth);
            }
        }
        private void UpdateDgvFaiConfigs()
        {
            if (FaiConfigs != null && FaiConfigs.TotalFaiConfigs.Count > 0)
            {
                chkEnOffset.Checked = FaiConfigs.EnAutoOffset;
                dgvFai.Rows.Clear();
                foreach (var faiConfig in FaiConfigs.TotalFaiConfigs)
                {
                    var added = dgvFai.Rows.Add();
                    dgvFai.Rows[added].Cells[0].Value = faiConfig.FaiName;
                    dgvFai.Rows[added].Cells[1].Value = faiConfig.Enable;
                    dgvFai.Rows[added].Cells[2].Value = faiConfig.LimitErr;
                }
                RefreshDgvTruthCol();
            }
        }
        private void UpdateDgvTruth()
        {
            if (TotalTypeTruth.CurrentProductTruth != null)
            {
                dgvTruth.Rows.Clear();
                if (TotalTypeTruth.CurrentProductTruth.TruthProducts.Count > 0)
                {
                    foreach (var singleProductTruth in TotalTypeTruth.CurrentProductTruth.TruthProducts)
                    {
                        var added = dgvTruth.Rows.Add();
                        var row = dgvTruth.Rows[added];
                        row.Cells[0].Value = added;
                        row.Cells[1].Value = singleProductTruth.Barcode;
                        for (var i = 2; i < dgvTruth.Columns.Count; i++)
                        {
                            var columnName = dgvTruth.Columns[i].HeaderText;
                            if (singleProductTruth.TruthValues.ContainsKey(columnName))
                            {
                                row.Cells[i].Value = singleProductTruth.TruthValues[columnName];
                            }
                            else
                            {
                                row.Cells[i].Value = 0.00;
                            }
                        }
                    }
                }
            }
        }
        #endregion

        private void btnNewPro_Click(object sender, EventArgs e)
        {
            var newProduct = new ProductTruth();
            newProduct.ProductType = cmbSelProduct.Text;
            if (TotalTypeTruth.TotalProcutTypeConfigs.ContainsKey(cmbSelProduct.Text))
            {
                MessageBox.Show("已存在产品类型：" + cmbSelProduct.Text);
                return;
            }
            TotalTypeTruth.TotalProcutTypeConfigs.Add(cmbSelProduct.Text, newProduct);
            TotalTypeTruth.CurrentProduct = cmbSelProduct.Text;
            cmbSelProduct.Items.Add(cmbSelProduct.Text);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            _show.SaveConfig();
        }

        private void btnBrowerEBusConfig_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbConfigPath.Text))
            {
                if (saveConfigFile.ShowDialog() == DialogResult.OK)
                {
                    tbConfigPath.Text = saveConfigFile.FileName;
                    _show.ConfigPath = tbConfigPath.Text;
                }
            }
            else
            {
                openConfigFile.InitialDirectory = Path.GetDirectoryName(tbConfigPath.Text);
                if (openConfigFile.ShowDialog() == DialogResult.OK)
                {
                    tbConfigPath.Text = openConfigFile.FileName;

                    if (string.IsNullOrEmpty(tbConfigPath.Text))
                    {
                        return;
                    }

                    if (!File.Exists(tbConfigPath.Text))
                    {
                        MessageBox.Show($@"文件{tbConfigPath.Text} 不存在");
                        return;
                    }
                    _show.ConfigPath = tbConfigPath.Text;
                    _show.LoadConfig();
                    ShowConfigControl_Load(null, null);
                }
            }
        }

        private void ShowConfigControl_Load(object sender, EventArgs e)
        {
            tbConfigPath.Text = _show.ConfigPath;

            cmbSelProduct.Items.Clear();
            if (TotalTypeTruth != null)
                cmbSelProduct.Items.AddRange(TotalTypeTruth.TotalProcutTypeConfigs.Keys.ToArray());
            if (!string.IsNullOrEmpty(TotalTypeTruth.CurrentProduct))
            {
                cmbSelProduct.SelectedItem = TotalTypeTruth.CurrentProduct;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            _show.ClearDgv();
        }

        private void btnAddInfo_Click(object sender, EventArgs e)
        {
            var fais = new Dictionary<object, object>();
            var faiResults = new Dictionary<string, bool>();
            var a = 0;
            foreach (var faiConfig in FaiConfigs.TotalFaiConfigs)
            {
                fais[faiConfig.FaiName] = 0.23;
                faiResults[faiConfig.FaiName] = a++ % 2 == 0;
            }
            _show.AddPart("aa", "OK", fais, faiResults);
            
        }

        private void 复制数据ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ControlHelper.DgvCopy(ref dgvTruth);
        }

        private void 粘贴数据ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ControlHelper.DgvPaste(ref dgvTruth);
        }
    }
}
