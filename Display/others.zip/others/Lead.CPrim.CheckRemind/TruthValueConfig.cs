﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Lead.CPrim.CheckRemind
{
    public class TotalTypeTruth
    {
        public string CurrentProduct { get; set; }
        [JsonIgnore]
        public ProductTruth CurrentProductTruth
        {
            get
            {
                if (!string.IsNullOrEmpty(CurrentProduct))
                {
                    if (!TotalProcutTypeConfigs.ContainsKey(CurrentProduct))
                    {
                        TotalProcutTypeConfigs[CurrentProduct] = new ProductTruth();
                    }
                    return TotalProcutTypeConfigs[CurrentProduct];
                }

                return new ProductTruth();
            }
        }

        public Dictionary<string, ProductTruth> TotalProcutTypeConfigs { get; set; }
        public TotalTypeTruth()
        {
            CurrentProduct = "";
            TotalProcutTypeConfigs = new Dictionary<string, ProductTruth>();
        }
    }
    public class ProductTruth
    {
        public string ProductType { get; set; }
        public FaiConfigs FaiConfigs { get; set; }
        public List<SingleProductTruth> TruthProducts { get; set; }

        public SingleProductTruth FindBarcode(string barCode)
        {
            if (TruthProducts.Count == 0)
            {
                return new SingleProductTruth();
            }
            foreach (var singleProductTruth in TruthProducts)
            {
                if (singleProductTruth.Barcode == barCode)
                {
                    return singleProductTruth;
                }
            }

            return new SingleProductTruth();
        }
        public double FindTruthValue(string barCode, string faiName)
        {
            if (TruthProducts.Count == 0)
            {
                return 0.0;
            }

            foreach (var singleProductTruth in TruthProducts)
            {
                if (singleProductTruth.Barcode == barCode)
                {
                    if (singleProductTruth.TruthValues.ContainsKey(faiName))
                    {
                        return singleProductTruth.TruthValues[faiName];
                    }
                }
            }

            return 0.0;
        }
    }
    public class SingleFaiConfig
    {
        public string FaiName { get; set; }
        public double LimitErr { get; set; }
        public bool Enable { get; set; }
        public SingleFaiConfig()
        {
            FaiName = "";
            LimitErr = 0.005;
            Enable = true;
        }
    }
    public class FaiConfigs
    {
        public List<SingleFaiConfig> TotalFaiConfigs { get; set; }
        public bool EnAutoOffset { get; set; }

        public bool ContainFaiName(string faiName)
        {
            var flag = false;
            if (TotalFaiConfigs.Count > 0)
            {
                foreach (var singleFaiConfig in TotalFaiConfigs)
                {
                    if (singleFaiConfig.FaiName == faiName)
                    {
                        flag = true;
                        break;
                    }
                }
            }

            return flag;
        }
    }
    public class SingleProductTruth
    {
        public string Barcode { get; set; }
        public Dictionary<string,double> TruthValues { get; set; }
    }
}
