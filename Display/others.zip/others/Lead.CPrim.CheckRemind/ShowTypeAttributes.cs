﻿using System.Drawing;
using System.Resources;
using Lead.CPrim.Interfaces;

namespace Lead.CPrim.CheckRemind
{
    public class ShowTypeAttributes : IShowTypeAttributes
    {
        public string Description => "CheckRemind";

        public string DisplayGroup => "PAX";

        public string DisplayName => "CheckRemind";

        public string Group => "PAX";

        public Image Icon
        {
            get
            {
                var manager = new ResourceManager(typeof(Resource1));
                return (Image)manager.GetObject("Default");
            }
        }


        public byte MajorVersion => 1;

        public byte MinorVersion => 1;

        public string Name => "CheckRemind";
    }
}
