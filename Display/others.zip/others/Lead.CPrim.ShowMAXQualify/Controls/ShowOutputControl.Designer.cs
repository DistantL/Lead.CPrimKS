﻿namespace Lead.CPrim.ShowMAXQualify.Controls
{
    partial class ShowOutputControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dgvQualify = new System.Windows.Forms.DataGridView();
            this.grbQualify = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbTimes = new System.Windows.Forms.TextBox();
            this.tbTrayID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbOperator = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmsDgvQualify = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmSaveCsv = new System.Windows.Forms.ToolStripMenuItem();
            this.btnInit = new System.Windows.Forms.Button();
            this.btnRunCycle = new System.Windows.Forms.Button();
            this.btnRunOnce = new System.Windows.Forms.Button();
            this.tbCount = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbRtAverageCt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQualify)).BeginInit();
            this.grbQualify.SuspendLayout();
            this.cmsDgvQualify.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dgvQualify);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.grbQualify);
            this.splitContainer1.Size = new System.Drawing.Size(979, 481);
            this.splitContainer1.SplitterDistance = 835;
            this.splitContainer1.TabIndex = 0;
            // 
            // dgvQualify
            // 
            this.dgvQualify.AllowUserToAddRows = false;
            this.dgvQualify.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQualify.ContextMenuStrip = this.cmsDgvQualify;
            this.dgvQualify.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvQualify.Location = new System.Drawing.Point(0, 0);
            this.dgvQualify.Name = "dgvQualify";
            this.dgvQualify.RowTemplate.Height = 23;
            this.dgvQualify.Size = new System.Drawing.Size(835, 481);
            this.dgvQualify.TabIndex = 0;
            // 
            // grbQualify
            // 
            this.grbQualify.BackColor = System.Drawing.Color.Transparent;
            this.grbQualify.Controls.Add(this.tbRtAverageCt);
            this.grbQualify.Controls.Add(this.label5);
            this.grbQualify.Controls.Add(this.tbCount);
            this.grbQualify.Controls.Add(this.label4);
            this.grbQualify.Controls.Add(this.btnRunOnce);
            this.grbQualify.Controls.Add(this.btnRunCycle);
            this.grbQualify.Controls.Add(this.btnInit);
            this.grbQualify.Controls.Add(this.tbOperator);
            this.grbQualify.Controls.Add(this.label3);
            this.grbQualify.Controls.Add(this.tbTrayID);
            this.grbQualify.Controls.Add(this.label2);
            this.grbQualify.Controls.Add(this.tbTimes);
            this.grbQualify.Controls.Add(this.label1);
            this.grbQualify.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grbQualify.Font = new System.Drawing.Font("微软雅黑", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grbQualify.Location = new System.Drawing.Point(0, 0);
            this.grbQualify.Name = "grbQualify";
            this.grbQualify.Size = new System.Drawing.Size(140, 481);
            this.grbQualify.TabIndex = 0;
            this.grbQualify.TabStop = false;
            this.grbQualify.Text = "Qualify";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(39, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Times:";
            // 
            // tbTimes
            // 
            this.tbTimes.BackColor = System.Drawing.Color.Wheat;
            this.tbTimes.Location = new System.Drawing.Point(20, 69);
            this.tbTimes.Name = "tbTimes";
            this.tbTimes.Size = new System.Drawing.Size(100, 25);
            this.tbTimes.TabIndex = 1;
            this.tbTimes.Text = "50";
            this.tbTimes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTrayID
            // 
            this.tbTrayID.BackColor = System.Drawing.Color.Wheat;
            this.tbTrayID.Location = new System.Drawing.Point(6, 137);
            this.tbTrayID.Name = "tbTrayID";
            this.tbTrayID.Size = new System.Drawing.Size(128, 25);
            this.tbTrayID.TabIndex = 3;
            this.tbTrayID.Text = "abc";
            this.tbTrayID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(36, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "TrayID:";
            // 
            // tbOperator
            // 
            this.tbOperator.BackColor = System.Drawing.Color.Wheat;
            this.tbOperator.Location = new System.Drawing.Point(6, 207);
            this.tbOperator.Name = "tbOperator";
            this.tbOperator.Size = new System.Drawing.Size(128, 25);
            this.tbOperator.TabIndex = 6;
            this.tbOperator.Text = "Tony";
            this.tbOperator.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(26, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 22);
            this.label3.TabIndex = 5;
            this.label3.Text = "Operator:";
            // 
            // cmsDgvQualify
            // 
            this.cmsDgvQualify.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmSaveCsv});
            this.cmsDgvQualify.Name = "cmsDgvQualify";
            this.cmsDgvQualify.Size = new System.Drawing.Size(163, 26);
            // 
            // tsmSaveCsv
            // 
            this.tsmSaveCsv.Name = "tsmSaveCsv";
            this.tsmSaveCsv.Size = new System.Drawing.Size(162, 22);
            this.tsmSaveCsv.Text = "Save to csv file";
            this.tsmSaveCsv.Click += new System.EventHandler(this.tsmSaveCsv_Click);
            // 
            // btnInit
            // 
            this.btnInit.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnInit.Location = new System.Drawing.Point(20, 239);
            this.btnInit.Margin = new System.Windows.Forms.Padding(2);
            this.btnInit.Name = "btnInit";
            this.btnInit.Size = new System.Drawing.Size(104, 30);
            this.btnInit.TabIndex = 21;
            this.btnInit.Text = "Qualify Init";
            this.btnInit.UseVisualStyleBackColor = true;
            this.btnInit.Click += new System.EventHandler(this.btnInit_Click);
            // 
            // btnRunCycle
            // 
            this.btnRunCycle.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnRunCycle.Location = new System.Drawing.Point(20, 319);
            this.btnRunCycle.Margin = new System.Windows.Forms.Padding(2);
            this.btnRunCycle.Name = "btnRunCycle";
            this.btnRunCycle.Size = new System.Drawing.Size(104, 30);
            this.btnRunCycle.TabIndex = 22;
            this.btnRunCycle.Text = "Run Cycle";
            this.btnRunCycle.UseVisualStyleBackColor = true;
            this.btnRunCycle.Click += new System.EventHandler(this.btnRunCycle_Click);
            // 
            // btnRunOnce
            // 
            this.btnRunOnce.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnRunOnce.Location = new System.Drawing.Point(20, 279);
            this.btnRunOnce.Margin = new System.Windows.Forms.Padding(2);
            this.btnRunOnce.Name = "btnRunOnce";
            this.btnRunOnce.Size = new System.Drawing.Size(104, 30);
            this.btnRunOnce.TabIndex = 23;
            this.btnRunOnce.Text = "Run Once";
            this.btnRunOnce.UseVisualStyleBackColor = true;
            this.btnRunOnce.Click += new System.EventHandler(this.btnRunOnce_Click);
            // 
            // tbCount
            // 
            this.tbCount.BackColor = System.Drawing.Color.Lime;
            this.tbCount.Enabled = false;
            this.tbCount.Location = new System.Drawing.Point(21, 386);
            this.tbCount.Name = "tbCount";
            this.tbCount.Size = new System.Drawing.Size(100, 25);
            this.tbCount.TabIndex = 25;
            this.tbCount.Text = "50";
            this.tbCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(39, 361);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 22);
            this.label4.TabIndex = 24;
            this.label4.Text = "Count:";
            // 
            // tbRtAverageCt
            // 
            this.tbRtAverageCt.BackColor = System.Drawing.Color.Lime;
            this.tbRtAverageCt.Enabled = false;
            this.tbRtAverageCt.Location = new System.Drawing.Point(21, 439);
            this.tbRtAverageCt.Name = "tbRtAverageCt";
            this.tbRtAverageCt.Size = new System.Drawing.Size(100, 25);
            this.tbRtAverageCt.TabIndex = 27;
            this.tbRtAverageCt.Text = "2.35";
            this.tbRtAverageCt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(55, 414);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 22);
            this.label5.TabIndex = 26;
            this.label5.Text = "Ct:";
            // 
            // PrimOutputControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ShowOutputControl";
            this.Size = new System.Drawing.Size(979, 481);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQualify)).EndInit();
            this.grbQualify.ResumeLayout(false);
            this.grbQualify.PerformLayout();
            this.cmsDgvQualify.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.DataGridView dgvQualify;
        private System.Windows.Forms.ContextMenuStrip cmsDgvQualify;
        private System.Windows.Forms.ToolStripMenuItem tsmSaveCsv;
        private System.Windows.Forms.GroupBox grbQualify;
        private System.Windows.Forms.TextBox tbOperator;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbTrayID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbTimes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRunCycle;
        private System.Windows.Forms.Button btnInit;
        private System.Windows.Forms.Button btnRunOnce;
        private System.Windows.Forms.TextBox tbCount;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbRtAverageCt;
        private System.Windows.Forms.Label label5;
    }
}
