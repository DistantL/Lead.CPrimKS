﻿using System;
using System.Linq;
using SuperSocket.Facility.Protocol;

namespace Lead.CPrim.PrimSuperServer
{
    public class LeadReceiveFilter : FixedHeaderReceiveFilter<LeadRequestInfo>
    {
        /// +-------+---+-------------------------------+
        /// |request| l |                               |
        /// | name  | e |    request body               |
        /// |  (2)  | n |                               |
        /// |       |(2)|                               |
        /// +-------+---+-------------------------------+
        public LeadReceiveFilter()
        : base(4)
        {
            //00 02 00 06 01 ...   功能:00 02 字节数:00 06 数据:01 02 03 04 05 06
        }

        protected override int GetBodyLengthFromHeader(byte[] header, int offset, int length)
        {
            return header[offset + 2] * 256 + header[offset + 3];
        }

        protected override LeadRequestInfo ResolveRequestInfo(ArraySegment<byte> header, byte[] bodyBuffer, int offset, int length)
        {
            var body = bodyBuffer.Skip(offset).Take(length).ToArray();
            return new LeadRequestInfo(header.Array, body);
        }
    }
}