﻿using Lead.CPrim.LocalizationService;
using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;

namespace Lead.CPrim.PrimSuperServer
{
    public class LeadServer : AppServer<LeadSession, LeadRequestInfo>
    {
        /// <summary>
        /// 通过配置文件安装服务从这里启动
        /// </summary>
        public LeadServer()
            : base(new DefaultReceiveFilterFactory<LeadReceiveFilter, LeadRequestInfo>())
        {
            this.NewSessionConnected += MyServer_NewSessionConnected;
            this.SessionClosed += MyServer_SessionClosed;
        }

        /// <summary>
        /// winform启动，不使用这里的事件
        /// </summary>
        public LeadServer(SessionHandler<LeadSession> NewSessionConnected, SessionHandler<LeadSession, CloseReason> SessionClosed)
            : base(new DefaultReceiveFilterFactory<LeadReceiveFilter, LeadRequestInfo>())
        {
            this.NewSessionConnected += NewSessionConnected;
            this.SessionClosed += SessionClosed;
        }

        private void MyServer_NewSessionConnected(LeadSession session)
        {
            //连接成功
        }

        private void MyServer_SessionClosed(LeadSession session, CloseReason value)
        {
        }

        protected override void OnStarted()
        {
            //启动成功
            SuperServer.LogDisplayAdd(string.Format(NLocalizer.GetString("PrimSuperServer_PrimOutputControl_SocketServerStartSuccessfully", "Socket server started successfully：{0}:{1}"), this.Config.Ip, this.Config.Port));
        }
    }
}