﻿using System.Text;
using SuperSocket.SocketBase.Protocol;

namespace Lead.CPrim.PrimSuperServer
{
    public class LeadRequestInfo : IRequestInfo
    {
        public LeadRequestInfo(byte[] header, byte[] bodyBuffer)
        {
            Key = ((header[0] * 256) + header[1]).ToString();
            Data = bodyBuffer;
        }

        /// <summary>
        /// 正文文本
        /// </summary>
        public string Body => Encoding.UTF8.GetString(Data);

        /// <summary>
        /// 正文字节码
        /// </summary>
        public byte[] Data { get; set; }

        /// <summary>
        /// 协议号对应自定义命令Name，会触摸自定义命令
        /// </summary>
        public string Key { get; set; }
    }
}