﻿using System;
using Lead.CPrim.LocalizationService;
using SuperSocket.SocketBase;

namespace Lead.CPrim.PrimSuperServer
{
    public class LeadSession : AppSession<LeadSession, LeadRequestInfo>
    {
        public string NickName = NLocalizer.GetString("PrimSuperServer_LeadSession_NotLoggedIn", "Not Logged in");

        public LeadSession()
        {
        }

        protected override void HandleException(Exception e)
        {
            SuperServer.LogDisplayAdd(NLocalizer.GetString("PrimSuperServer_LeadSession_HandleException", "Handle Exception!"));
        }

        protected override void HandleUnknownRequest(LeadRequestInfo requestInfo)
        {
            SuperServer.LogDisplayAdd(NLocalizer.GetString("PrimSuperServer_LeadSession_UnknownCommand", "Unknown Command!"));
        }

        protected override void OnInit()
        {
            base.OnInit();
        }

        protected override void OnSessionClosed(CloseReason reason)
        {
            base.OnSessionClosed(reason);
        }

        protected override void OnSessionStarted()
        {
        }
    }
}