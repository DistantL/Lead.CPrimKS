﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Resources;
using Lead.CPrim.Interfaces;

namespace Lead.CPrim.PrimSuperServer
{
    public class PrimTypeAttributes : IPrimTypeAttributes
    {
        public IEnumerable<KeyValuePair<string, object>> Attributes => throw new NotImplementedException();
        public string Description => "";
        public string DisplayGroup => "Dev";
        public string DisplayName => "SuperServer";
        public string Group => "Dev";

        public Image Icon
        {
            get
            {
                var manager = new ResourceManager(typeof(PrimSuperServer));
                return (Image)manager.GetObject("ss_Server");
            }
        }

        public byte MajorVersion => 1;
        public byte MinorVersion => 0;
        public string Name => "SuperServer";
        public object this[string attrName] => throw new NotImplementedException();
    }
}