﻿namespace Lead.CPrim.PrimSuperServer.Controls
{
    partial class PrimOutputControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PrimOutputControl));
            this.lbTitle = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tBoxName = new System.Windows.Forms.TextBox();
            this.tBoxConnState = new System.Windows.Forms.TextBox();
            this.tBoxRunState = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageConnState = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.tabPageClientTaskInfo = new System.Windows.Forms.TabPage();
            this.btnRefreshStation = new System.Windows.Forms.Button();
            this.treeViewTask = new System.Windows.Forms.TreeView();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPageConnState.SuspendLayout();
            this.tabPageClientTaskInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbTitle
            // 
            this.lbTitle.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lbTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbTitle.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTitle.Location = new System.Drawing.Point(0, 0);
            this.lbTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.Size = new System.Drawing.Size(1082, 36);
            this.lbTitle.TabIndex = 32;
            this.lbTitle.Text = "SupSkt Server ";
            this.lbTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tBoxName);
            this.panel1.Controls.Add(this.tBoxConnState);
            this.panel1.Controls.Add(this.tBoxRunState);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 36);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 11, 4, 11);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1082, 39);
            this.panel1.TabIndex = 34;
            // 
            // tBoxName
            // 
            this.tBoxName.BackColor = System.Drawing.Color.OldLace;
            this.tBoxName.Dock = System.Windows.Forms.DockStyle.Left;
            this.tBoxName.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tBoxName.Location = new System.Drawing.Point(141, 0);
            this.tBoxName.Margin = new System.Windows.Forms.Padding(4, 11, 4, 11);
            this.tBoxName.Multiline = true;
            this.tBoxName.Name = "tBoxName";
            this.tBoxName.Size = new System.Drawing.Size(178, 39);
            this.tBoxName.TabIndex = 16;
            this.tBoxName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tBoxConnState
            // 
            this.tBoxConnState.BackColor = System.Drawing.Color.Khaki;
            this.tBoxConnState.Dock = System.Windows.Forms.DockStyle.Right;
            this.tBoxConnState.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tBoxConnState.Location = new System.Drawing.Point(725, 0);
            this.tBoxConnState.Margin = new System.Windows.Forms.Padding(4, 11, 4, 11);
            this.tBoxConnState.Multiline = true;
            this.tBoxConnState.Name = "tBoxConnState";
            this.tBoxConnState.Size = new System.Drawing.Size(175, 39);
            this.tBoxConnState.TabIndex = 15;
            this.tBoxConnState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tBoxRunState
            // 
            this.tBoxRunState.BackColor = System.Drawing.Color.Khaki;
            this.tBoxRunState.Dock = System.Windows.Forms.DockStyle.Right;
            this.tBoxRunState.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tBoxRunState.Location = new System.Drawing.Point(900, 0);
            this.tBoxRunState.Margin = new System.Windows.Forms.Padding(4, 11, 4, 11);
            this.tBoxRunState.Multiline = true;
            this.tBoxRunState.Name = "tBoxRunState";
            this.tBoxRunState.Size = new System.Drawing.Size(182, 39);
            this.tBoxRunState.TabIndex = 14;
            this.tBoxRunState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.SkyBlue;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 39);
            this.label1.TabIndex = 12;
            this.label1.Text = "Server Name";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageConnState);
            this.tabControl1.Controls.Add(this.tabPageClientTaskInfo);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 75);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1082, 603);
            this.tabControl1.TabIndex = 35;
            // 
            // tabPageConnState
            // 
            this.tabPageConnState.Controls.Add(this.flowLayoutPanel);
            this.tabPageConnState.Location = new System.Drawing.Point(4, 29);
            this.tabPageConnState.Name = "tabPageConnState";
            this.tabPageConnState.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageConnState.Size = new System.Drawing.Size(1074, 570);
            this.tabPageConnState.TabIndex = 0;
            this.tabPageConnState.Text = "ConnState";
            this.tabPageConnState.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel
            // 
            this.flowLayoutPanel.AutoScroll = true;
            this.flowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel.Name = "flowLayoutPanel";
            this.flowLayoutPanel.Size = new System.Drawing.Size(1068, 564);
            this.flowLayoutPanel.TabIndex = 36;
            // 
            // tabPageClientTaskInfo
            // 
            this.tabPageClientTaskInfo.Controls.Add(this.btnRefreshStation);
            this.tabPageClientTaskInfo.Controls.Add(this.treeViewTask);
            this.tabPageClientTaskInfo.Location = new System.Drawing.Point(4, 29);
            this.tabPageClientTaskInfo.Name = "tabPageClientTaskInfo";
            this.tabPageClientTaskInfo.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageClientTaskInfo.Size = new System.Drawing.Size(1074, 570);
            this.tabPageClientTaskInfo.TabIndex = 1;
            this.tabPageClientTaskInfo.Text = "ClientTaskInfo";
            this.tabPageClientTaskInfo.UseVisualStyleBackColor = true;
            // 
            // btnRefreshStation
            // 
            this.btnRefreshStation.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRefreshStation.BackgroundImage")));
            this.btnRefreshStation.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRefreshStation.Location = new System.Drawing.Point(193, 16);
            this.btnRefreshStation.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRefreshStation.Name = "btnRefreshStation";
            this.btnRefreshStation.Size = new System.Drawing.Size(24, 24);
            this.btnRefreshStation.TabIndex = 10;
            this.btnRefreshStation.UseVisualStyleBackColor = true;
            this.btnRefreshStation.Click += new System.EventHandler(this.btnRefreshStation_Click_1);
            // 
            // treeViewTask
            // 
            this.treeViewTask.Dock = System.Windows.Forms.DockStyle.Left;
            this.treeViewTask.Location = new System.Drawing.Point(3, 3);
            this.treeViewTask.Name = "treeViewTask";
            this.treeViewTask.Size = new System.Drawing.Size(223, 564);
            this.treeViewTask.TabIndex = 9;
            // 
            // PrimOutputControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbTitle);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "PrimOutputControl";
            this.Size = new System.Drawing.Size(1082, 678);
            this.Load += new System.EventHandler(this.PrimOutputControl_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPageConnState.ResumeLayout(false);
            this.tabPageClientTaskInfo.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbTitle;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tBoxName;
        private System.Windows.Forms.TextBox tBoxConnState;
        private System.Windows.Forms.TextBox tBoxRunState;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageConnState;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel;
        private System.Windows.Forms.TabPage tabPageClientTaskInfo;
        private System.Windows.Forms.Button btnRefreshStation;
        private System.Windows.Forms.TreeView treeViewTask;
    }
}
