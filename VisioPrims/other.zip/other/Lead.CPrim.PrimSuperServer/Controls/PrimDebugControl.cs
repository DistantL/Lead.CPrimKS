﻿using System.Windows.Forms;

namespace Lead.CPrim.PrimSuperServer.Controls
{
    public partial class PrimDebugControl : UserControl
    {
        public PrimDebugControl()
        {
            InitializeComponent();
        }
    }
}