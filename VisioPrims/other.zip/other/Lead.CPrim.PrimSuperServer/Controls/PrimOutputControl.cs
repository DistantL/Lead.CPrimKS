using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Lead.CPrim.Interfaces;
using Lead.CPrim.LocalizationService;

namespace Lead.CPrim.PrimSuperServer.Controls
{
    public delegate void AddClientTasksDelegate(SuperMsgInfo msg);

    public delegate void AddCommStatusControlDelegate(CommStatus control);

    public delegate void UpdateClientTasksDelegate(SuperMsgInfo msg);

    public delegate void UpdatePrimConnState(PrimConnState state);

    public delegate void UpdatePrimRunState(PrimRunState state); //�ı�ؼ�״̬����

    public partial class PrimOutputControl : UserControl
    {
        private IPrim _prim = null;

        public PrimOutputControl()
        {
            InitializeComponent();
        }

        public PrimOutputControl(IPrim prim)
        {
            _prim = prim;
            InitializeComponent();
        }

        public string SuperServerName
        {
            set => tBoxName.Text = value;
        }

        private void btnRefreshStation_Click_1(object sender, EventArgs e)
        {
            ((ISuperServer)_prim).SetCmdUpdateClientTasks();
        }

        private void InitializeUI()
        {
            this.lbTitle.Text = NLocalizer.GetString("PrimSuperServer_PrimOutputControl_SupSktServer", "SupSkt Server ");
            this.label1.Text = NLocalizer.GetString("PrimSuperServer_PrimOutputControl_ServerName", "Server Name");
            this.tabPageConnState.Text = NLocalizer.GetString("PrimSuperServer_PrimOutputControl_ConnState", "ConnState");
            this.tabPageClientTaskInfo.Text = NLocalizer.GetString("PrimSuperServer_PrimOutputControl_ClientTaskInfo", "ClientTaskInfo");
        }

        private void PrimOutputControl_Load(object sender, EventArgs e)
        {
            tBoxName.Text = _prim.Name;
            tBoxConnState.Text = _prim.PrimConnStat.ToString();
            tBoxRunState.Text = _prim.PrimRunStat.ToString();
        }

        public void AddClientTasks(SuperMsgInfo msg)
        {
            if (treeViewTask.InvokeRequired)
            {
                treeViewTask.BeginInvoke(new AddClientTasksDelegate(AddClientTasks), msg);
            }
            else
            {
                var nodeClient = treeViewTask.Nodes.Add(msg.SrcName.Trim());

                var tasks = (List<string>)msg.Obj;

                foreach (var name in tasks)
                {
                    nodeClient.Nodes.Add(name);
                }
            }
        }

        public void AddCommStatusControl(CommStatus control)
        {
            if (flowLayoutPanel.InvokeRequired)
            {
                flowLayoutPanel.Invoke(new AddCommStatusControlDelegate(AddCommStatusControl), control);
            }
            else
            {
                flowLayoutPanel.Controls.Add(control);
            }
        }

        public void SetPrimConnState(PrimConnState state)
        {
            if (tBoxConnState.InvokeRequired)
            {
                var update = new UpdatePrimConnState(SetPrimConnState);
                tBoxConnState.BeginInvoke(update, new object[1] { state });
            }
            else
            {
                switch (state)
                {
                    case PrimConnState.UnConnected:
                        tBoxConnState.BackColor = Color.Khaki;
                        tBoxConnState.Text = "UnConnected";
                        break;

                    case PrimConnState.Connected:
                        tBoxConnState.BackColor = Color.LightGreen;
                        tBoxConnState.Text = "Connected";
                        break;

                    case PrimConnState.Other:
                        tBoxConnState.BackColor = Color.Khaki;
                        tBoxConnState.Text = "UnConnected";
                        break;
                }
            }
        }

        public void SetPrimRunState(PrimRunState state)
        {
            if (tBoxRunState.InvokeRequired) //ָʾ���÷��ڶԿؼ����з�������ʱ�Ƿ������� Invoke ��������Ϊ���÷�λ�ڴ����ؼ����ڵ��߳�������߳���
            {
                var update = new UpdatePrimRunState(SetPrimRunState);
                tBoxRunState.BeginInvoke(update, new object[1] { state });
            }
            else
            {
                switch (state)
                {
                    case PrimRunState.Idle:
                        tBoxRunState.BackColor = Color.Khaki;
                        tBoxRunState.Text = "Idle";
                        break;

                    case PrimRunState.Running:
                        tBoxRunState.BackColor = Color.LightGreen;
                        tBoxRunState.Text = "Running";
                        break;

                    case PrimRunState.Err:
                        tBoxRunState.BackColor = Color.SandyBrown;
                        tBoxRunState.Text = "Err";
                        break;

                    case PrimRunState.Other:
                        tBoxRunState.BackColor = Color.Khaki;
                        tBoxRunState.Text = "Idle";
                        break;
                }
            }
        }

        public void UpdateClientTasks(SuperMsgInfo msg)
        {
            if (treeViewTask.InvokeRequired)
            {
                treeViewTask.BeginInvoke(new UpdateClientTasksDelegate(UpdateClientTasks), msg);
            }
            else
            {
                foreach (TreeNode node in treeViewTask.Nodes)
                {
                    if (node.Text == msg.SrcName)
                    {
                        node.Nodes.Clear();

                        var tasks = (List<string>)msg.Obj;

                        foreach (var name in tasks)
                        {
                            node.Nodes.Add(name);
                        }
                        return;
                    }
                }
                var nodeNew = new TreeNode();
                nodeNew.Text = msg.SrcName;
                var tasksNew = (List<string>)msg.Obj;
                foreach (var name in tasksNew)
                {
                    nodeNew.Nodes.Add(name);
                }
                treeViewTask.Nodes.Add(nodeNew);
            }
        }
    }
}