using System;
using System.Drawing;
using System.Windows.Forms;
using Lead.CPrim.CommonTools;
using Lead.CPrim.Interfaces;
using Lead.CPrim.LocalizationService;

namespace Lead.CPrim.PrimSuperServer.Controls
{
    public delegate void SetConnState_Del(bool state);

    public delegate void SetTargetName_Del(string name);

    public partial class CommStatus : UserControl
    {
        private bool _connState = false;
        private SuperServer _prim = null;
        private string _targetName = "";

        public CommStatus(SuperServer prim)
        {
            InitializeComponent();
            InitializeUI();
            _prim = prim;
        }

        public bool ConnState
        {
            set => _connState = value;
            get => _connState;
        }

        public string TargetName
        {
            set => _targetName = value;
            get => _targetName;
        }

        private void InitializeUI()
        {
            this.lbTargetStationName.Text = NLocalizer.GetString("PrimSuperServer_CommStatus_StationName", "Station  Name");
            this.label1.Text = NLocalizer.GetString("PrimSuperServer_CommStatus_ConnStatus", "ConnStatus:");
            this.label2.Text = NLocalizer.GetString("PrimSuperServer_CommStatus_RunStatus", "RunStatus:");
            this.label3.Text = NLocalizer.GetString("PrimSuperServer_CommStatus_AlarmLevel", "AlarmLv:");
            this.label5.Text = NLocalizer.GetString("PrimSuperServer_CommStatus_RunMode", "RunMode:");
            this.label4.Text = NLocalizer.GetString("PrimSuperServer_CommStatus_MainTask", "MainTask:");
            this.label7.Text = NLocalizer.GetString("PrimSuperServer_CommStatus_Info", "Info:");
            this.lbConnState.Text = NLocalizer.GetString("PrimSuperServer_CommStatus_Disconnected", "DisConnected");
            this.lbRunState.Text = NLocalizer.GetString("PrimSuperServer_CommStatus_Idle", "Idle");
            this.lbAlarmLv.Text = NLocalizer.GetString("PrimSuperServer_CommStatus_Error", "Err");
            this.lbRunMode.Text = NLocalizer.GetString("PrimSuperServer_CommStatus_Single", "Single");
            this.lbMainTask.Text = NLocalizer.GetString("PrimSuperServer_CommStatus_AutoTask", "AutoTask");
        }

        private void pauseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _prim.SendCmd2Client(_targetName, "pause");
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _prim.SendCmd2Client(_targetName, "reset");
        }

        private void startToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _prim.SendCmd2Client(_targetName, "start");
        }

        private void stopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _prim.SendCmd2Client(_targetName, "stop");
        }

        public void SetAlarmLv(StationAlarmLv alarmLv)
        {
            ControlHelper.ChangeLabelText(ref lbAlarmLv, alarmLv.ToString());
            switch (alarmLv)
            {
                case StationAlarmLv.Fatal:
                    ControlHelper.ChangeLabelBackColor(ref lbAlarmLv, Color.DarkRed);
                    ControlHelper.ChangeLabelText(ref lbAlarmLv, "Fatal");
                    break;

                case StationAlarmLv.Error:
                    ControlHelper.ChangeLabelBackColor(ref lbAlarmLv, Color.OrangeRed);
                    ControlHelper.ChangeLabelText(ref lbAlarmLv, "Err");
                    break;

                case StationAlarmLv.Warn:
                    ControlHelper.ChangeLabelBackColor(ref lbAlarmLv, Color.LightYellow);
                    ControlHelper.ChangeLabelText(ref lbAlarmLv, "Warn");
                    break;

                case StationAlarmLv.Info:
                    ControlHelper.ChangeLabelBackColor(ref lbAlarmLv, Color.SlateGray);
                    ControlHelper.ChangeLabelText(ref lbAlarmLv, "Info");
                    break;

                case StationAlarmLv.Debug:
                    ControlHelper.ChangeLabelBackColor(ref lbAlarmLv, Color.LightGray);
                    ControlHelper.ChangeLabelText(ref lbAlarmLv, "Debug");
                    break;

                case StationAlarmLv.Trace:
                    ControlHelper.ChangeLabelBackColor(ref lbAlarmLv, Color.LightGray);
                    ControlHelper.ChangeLabelText(ref lbAlarmLv, "Trace");
                    break;

                case StationAlarmLv.Other:
                    ControlHelper.ChangeLabelBackColor(ref lbAlarmLv, Color.LightGray);
                    ControlHelper.ChangeLabelText(ref lbAlarmLv, "Other");
                    break;

                default:
                    throw new ArgumentOutOfRangeException(nameof(alarmLv), alarmLv, null);
            }
        }

        public void SetConnState(bool connState)
        {
            if (lbConnState.InvokeRequired) //指示调用方在对控件进行方法调用时是否必须调用 Invoke 方法，因为调用方位于创建控件所在的线程以外的线程中
            {
                var update = new SetConnState_Del(SetConnState);
                lbConnState.Invoke(update, new object[1] { connState });
            }
            else
            {
                if (connState)
                {
                    lbConnState.BackColor = Color.Green;
                    lbConnState.Text = "Connected";
                }
                else
                {
                    lbConnState.BackColor = Color.Red;
                    lbConnState.Text = "DisConnected";
                }
            }
        }

        public void SetRunMode(StationRunMode runMode)
        {
            ControlHelper.ChangeLabelText(ref lbRunMode, runMode.ToString());
            switch (runMode)
            {
                case StationRunMode.Single:
                    ControlHelper.ChangeLabelBackColor(ref lbRunMode, Color.LawnGreen);
                    ControlHelper.ChangeLabelText(ref lbRunMode, "Single");
                    break;

                case StationRunMode.Line:
                    ControlHelper.ChangeLabelBackColor(ref lbRunMode, Color.LawnGreen);
                    ControlHelper.ChangeLabelText(ref lbRunMode, "Line");
                    break;

                case StationRunMode.Other:
                    ControlHelper.ChangeLabelBackColor(ref lbRunMode, Color.SlateGray);
                    ControlHelper.ChangeLabelText(ref lbRunMode, "Other");
                    break;

                default:
                    throw new ArgumentOutOfRangeException(nameof(runMode), runMode, null);
            }
        }

        public void SetRunState(StationRunStatus runStatus)
        {
            ControlHelper.ChangeLabelText(ref lbRunState, runStatus.ToString());
            switch (runStatus)
            {
                case StationRunStatus.Idle:
                    ControlHelper.ChangeLabelBackColor(ref lbRunState, Color.LightYellow);
                    ControlHelper.ChangeLabelText(ref lbRunState, "Idle");
                    break;

                case StationRunStatus.Running:
                    ControlHelper.ChangeLabelBackColor(ref lbRunState, Color.Green);
                    ControlHelper.ChangeLabelText(ref lbRunState, "Running");
                    break;

                case StationRunStatus.Suspend:
                    ControlHelper.ChangeLabelBackColor(ref lbRunState, Color.OrangeRed);
                    ControlHelper.ChangeLabelText(ref lbRunState, "Suspend");
                    break;

                case StationRunStatus.Stop:
                    ControlHelper.ChangeLabelBackColor(ref lbRunState, Color.MediumVioletRed);
                    ControlHelper.ChangeLabelText(ref lbRunState, "Stop");
                    break;

                case StationRunStatus.Err:
                    ControlHelper.ChangeLabelBackColor(ref lbRunState, Color.DarkRed);
                    ControlHelper.ChangeLabelText(ref lbRunState, "Err");
                    break;

                case StationRunStatus.Other:
                    ControlHelper.ChangeLabelBackColor(ref lbRunState, Color.LightGray);
                    ControlHelper.ChangeLabelText(ref lbRunState, "Other");
                    break;

                default:
                    throw new ArgumentOutOfRangeException(nameof(runStatus), runStatus, null);
            }
        }

        public void SetTargetName(string name)
        {
            if (lbTargetStationName.InvokeRequired) //指示调用方在对控件进行方法调用时是否必须调用 Invoke 方法，因为调用方位于创建控件所在的线程以外的线程中
            {
                var update = new SetTargetName_Del(SetTargetName);
                lbTargetStationName.Invoke(update, new object[1] { name });
            }
            else
            {
                lbTargetStationName.Text = _targetName;
            }
        }
    }
}