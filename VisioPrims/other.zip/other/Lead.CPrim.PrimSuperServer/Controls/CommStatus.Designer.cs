﻿namespace Lead.CPrim.PrimSuperServer.Controls
{
    partial class CommStatus
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbTargetStationName = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lbInfo = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbRunMode = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbMainTask = new System.Windows.Forms.Label();
            this.lbAlarmLv = new System.Windows.Forms.Label();
            this.lbRunState = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbConnState = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.startToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pauseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1.SuspendLayout();
            this.contextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbTargetStationName
            // 
            this.lbTargetStationName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(140)))), ((int)(((byte)(120)))));
            this.lbTargetStationName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbTargetStationName.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbTargetStationName.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTargetStationName.ForeColor = System.Drawing.Color.Yellow;
            this.lbTargetStationName.Location = new System.Drawing.Point(0, 0);
            this.lbTargetStationName.Margin = new System.Windows.Forms.Padding(4, 19, 4, 0);
            this.lbTargetStationName.Name = "lbTargetStationName";
            this.lbTargetStationName.Size = new System.Drawing.Size(292, 33);
            this.lbTargetStationName.TabIndex = 24;
            this.lbTargetStationName.Text = "Station  Name";
            this.lbTargetStationName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.Controls.Add(this.lbInfo, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbRunMode, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbMainTask, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbAlarmLv, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbRunState, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbConnState, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 33);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(292, 197);
            this.tableLayoutPanel1.TabIndex = 25;
            // 
            // lbInfo
            // 
            this.lbInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbInfo.ForeColor = System.Drawing.Color.Black;
            this.lbInfo.Location = new System.Drawing.Point(121, 162);
            this.lbInfo.Name = "lbInfo";
            this.lbInfo.Size = new System.Drawing.Size(166, 33);
            this.lbInfo.TabIndex = 37;
            this.lbInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Location = new System.Drawing.Point(5, 162);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 33);
            this.label7.TabIndex = 36;
            this.label7.Text = "Info:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbRunMode
            // 
            this.lbRunMode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbRunMode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbRunMode.ForeColor = System.Drawing.Color.Black;
            this.lbRunMode.Location = new System.Drawing.Point(121, 98);
            this.lbRunMode.Name = "lbRunMode";
            this.lbRunMode.Size = new System.Drawing.Size(166, 30);
            this.lbRunMode.TabIndex = 35;
            this.lbRunMode.Text = "Single";
            this.lbRunMode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Location = new System.Drawing.Point(5, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 30);
            this.label5.TabIndex = 34;
            this.label5.Text = "RunMode:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbMainTask
            // 
            this.lbMainTask.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbMainTask.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbMainTask.ForeColor = System.Drawing.Color.Black;
            this.lbMainTask.Location = new System.Drawing.Point(121, 130);
            this.lbMainTask.Name = "lbMainTask";
            this.lbMainTask.Size = new System.Drawing.Size(166, 30);
            this.lbMainTask.TabIndex = 33;
            this.lbMainTask.Text = "AutoTask";
            this.lbMainTask.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbAlarmLv
            // 
            this.lbAlarmLv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAlarmLv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbAlarmLv.ForeColor = System.Drawing.Color.Black;
            this.lbAlarmLv.Location = new System.Drawing.Point(121, 66);
            this.lbAlarmLv.Name = "lbAlarmLv";
            this.lbAlarmLv.Size = new System.Drawing.Size(166, 30);
            this.lbAlarmLv.TabIndex = 32;
            this.lbAlarmLv.Text = "Err";
            this.lbAlarmLv.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbRunState
            // 
            this.lbRunState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbRunState.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbRunState.ForeColor = System.Drawing.Color.Black;
            this.lbRunState.Location = new System.Drawing.Point(121, 34);
            this.lbRunState.Name = "lbRunState";
            this.lbRunState.Size = new System.Drawing.Size(166, 30);
            this.lbRunState.TabIndex = 31;
            this.lbRunState.Text = "Idle";
            this.lbRunState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Location = new System.Drawing.Point(5, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 30);
            this.label4.TabIndex = 30;
            this.label4.Text = "MainTask:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(5, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 30);
            this.label3.TabIndex = 29;
            this.label3.Text = "AlarmLv:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(5, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 30);
            this.label2.TabIndex = 28;
            this.label2.Text = "RunStatus:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbConnState
            // 
            this.lbConnState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbConnState.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbConnState.ForeColor = System.Drawing.Color.Black;
            this.lbConnState.Location = new System.Drawing.Point(121, 2);
            this.lbConnState.Name = "lbConnState";
            this.lbConnState.Size = new System.Drawing.Size(166, 30);
            this.lbConnState.TabIndex = 26;
            this.lbConnState.Text = "DisConnected";
            this.lbConnState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(5, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 30);
            this.label1.TabIndex = 27;
            this.label1.Text = "ConnStatus:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startToolStripMenuItem,
            this.pauseToolStripMenuItem,
            this.resetToolStripMenuItem,
            this.stopToolStripMenuItem});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(121, 100);
            // 
            // startToolStripMenuItem
            // 
            this.startToolStripMenuItem.Name = "startToolStripMenuItem";
            this.startToolStripMenuItem.Size = new System.Drawing.Size(120, 24);
            this.startToolStripMenuItem.Text = "Start";
            this.startToolStripMenuItem.Click += new System.EventHandler(this.startToolStripMenuItem_Click);
            // 
            // pauseToolStripMenuItem
            // 
            this.pauseToolStripMenuItem.Name = "pauseToolStripMenuItem";
            this.pauseToolStripMenuItem.Size = new System.Drawing.Size(120, 24);
            this.pauseToolStripMenuItem.Text = "Pause";
            this.pauseToolStripMenuItem.Click += new System.EventHandler(this.pauseToolStripMenuItem_Click);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(120, 24);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // stopToolStripMenuItem
            // 
            this.stopToolStripMenuItem.Name = "stopToolStripMenuItem";
            this.stopToolStripMenuItem.Size = new System.Drawing.Size(120, 24);
            this.stopToolStripMenuItem.Text = "Stop";
            this.stopToolStripMenuItem.Click += new System.EventHandler(this.stopToolStripMenuItem_Click);
            // 
            // CommStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ContextMenuStrip = this.contextMenuStrip;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.lbTargetStationName);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "CommStatus";
            this.Size = new System.Drawing.Size(292, 230);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.contextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbTargetStationName;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lbMainTask;
        private System.Windows.Forms.Label lbAlarmLv;
        private System.Windows.Forms.Label lbRunState;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbConnState;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbInfo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbRunMode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem startToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pauseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stopToolStripMenuItem;
    }
}
