﻿using System.Xml;
using Lead.CPrim.Interfaces;

namespace Lead.CPrim.PrimSuperServer
{
    public class PrimCreator : IPrimCreator
    {
        public IPrimTypeAttributes ConcretePrimTypeAttributes => new PrimTypeAttributes();

        public IPrim Create()
        {
            return new SuperServer();
        }

        public IPrim Create(XmlNode taskPrimConfig)
        {
            return new SuperServer(taskPrimConfig);
        }
    }
}