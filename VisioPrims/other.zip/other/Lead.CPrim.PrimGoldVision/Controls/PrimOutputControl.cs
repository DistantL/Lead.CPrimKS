﻿
using Lead.CPrim.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using VisionGraphic2D;

namespace Lead.CPrim.PrimGoldVision
{
    public partial class PrimOutputControl : UserControl
    {
        private PrimGoldVision _prim;
        private Dictionary<string, Map2D> showDic = new Dictionary<string, Map2D>(); 
        
        public PrimOutputControl(PrimGoldVision prim)
        {
            InitializeComponent();
            _prim = prim;
        }

        private void PrimOutputControl_Load(object sender, System.EventArgs e)
        {
            _prim.UpdateUIEvent += _prim_UpdateUIEvent;
            UpdateTableLayout();
        }

        private bool _prim_UpdateUIEvent(string strTask)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new DelegateGuidRunOutsideShowEventHandle(_prim_UpdateUIEvent), strTask);
            }
            else
            {
                if (showDic.Keys.Contains(strTask))
                    _prim.Logic.UpdateResultToMap2d(showDic[strTask], strTask);
            }
            return true;
        }

        public void UpdateTableLayout()
        {
            showDic.Clear();
            foreach (var item in _prim.OutputConfig)
            {
                showDic[item] = new Map2D();
                showDic[item].Dock = DockStyle.Fill;
            }
            tableLayoutPanel1.ColumnCount = 0;
            tableLayoutPanel1.ColumnStyles.Clear();
            tableLayoutPanel1.Controls.Clear();
            if (_prim.OutputConfig.Count > 1)
            {
                for (int i = 0; i < _prim.OutputConfig.Count; i++)
                {
                    tableLayoutPanel1.ColumnCount++;
                    tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 1.0f / _prim.OutputConfig.Count * 100));
                }
            }
            foreach (var item in _prim.OutputConfig)
                tableLayoutPanel1.Controls.Add(showDic[item]);
        }

    }
}
