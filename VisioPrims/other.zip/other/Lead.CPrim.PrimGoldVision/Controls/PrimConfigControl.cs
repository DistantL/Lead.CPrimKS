﻿
using CommonStruct2D.VisionStruct;
using Lead.CPrim.Interfaces;
using LogicCenter2D;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Lead.CPrim.PrimGoldVision
{
    public delegate void UpdatePrimConnState(PrimConnState state);
    public delegate void UpdatePrimRunState(PrimRunState state);
    public delegate void UpdateRevMag(string msg);
    public partial class PrimConfigControl : UserControl
    {
        private PrimGoldVision _prim;
        public PrimConfigControl()
        {
            InitializeComponent();
        }

        public PrimConfigControl(PrimGoldVision prim)
        {
            InitializeComponent();
            _prim = prim;
        }
       
        private void PrimConfigControl_Load(object sender, EventArgs e)
        {
            tbGvFilePath.Text = _prim.GvFilePath;
            foreach(var item in _prim.OutputConfig)
            {
                int index = dataGridView1.Rows.Add();
                dataGridView1.Rows[index].Cells[0].Value = item;
            }
        }

        private void button_loadGV_Click(object sender, EventArgs e)
        {
            var dlg = new FolderBrowserDialog { ShowNewFolderButton = true };
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                tbGvFilePath.Text = dlg.SelectedPath;
                _prim.GvFilePath = dlg.SelectedPath;
            }
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.Rows.Add();
            dataGridView1.CurrentCell = dataGridView1.Rows[index].Cells[0];
            _prim.OutputConfig.Add(string.Empty);
        }

        private void removeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null && dataGridView1.CurrentRow.Index > -1)
            {
                _prim.OutputConfig.RemoveAt(dataGridView1.CurrentRow.Index);
                _prim.UpdateOutputControl();
                dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
            }
        }

        private void dataGridView1_CellValidated(object sender, DataGridViewCellEventArgs e)
        {
            if(dataGridView1.Rows[e.RowIndex].Cells[0].Value != null)
            {
                string curStr = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                List<string> strLst = _prim.OutputConfig.FindAll(p => p != _prim.OutputConfig[e.RowIndex]);
                if (strLst.Contains(curStr))
                {
                    dataGridView1.Rows[e.RowIndex].Cells[0].Value = _prim.OutputConfig[e.RowIndex];
                    MessageBox.Show("已存在名称：" + curStr);
                }
                else
                {
                    _prim.OutputConfig[e.RowIndex] = curStr;
                    _prim.UpdateOutputControl();
                }
            }
        }

        private void UpdateDateGridView()
        {
            _prim.OutputConfig = _prim.OutputConfig.FindAll(p=>p!=string.Empty);
            foreach (var item in _prim.OutputConfig)
            {
                int index = dataGridView1.Rows.Add();
                dataGridView1.Rows[index].Cells[0].Value = item;
            }
        }

        private void tbGvFileName_TextChanged(object sender, EventArgs e)
        {
            _prim.GvFileName = tbGvFileName.Text;
        }
    }
}
