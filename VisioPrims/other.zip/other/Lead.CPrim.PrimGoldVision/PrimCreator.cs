﻿
using Lead.CPrim.PrimGoldVision;
using System.Xml;

namespace Lead.CPrim.Interfaces
{
    public class PrimCreator : IPrimCreator
    {
        public IPrimTypeAttributes ConcretePrimTypeAttributes => new PrimTypeAttributes();

        public IPrim Create()
        {
            return new PrimGoldVision.PrimGoldVision();
        }

        public IPrim Create(XmlNode taskPrimConfig)
        {
            return new PrimGoldVision.PrimGoldVision(taskPrimConfig);
        }
    }
}
