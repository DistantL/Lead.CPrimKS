﻿using Lead.CPrim.Interfaces;
using System;
using System.Collections.Generic;

namespace Lead.CPrim.PrimGoldVision
{
    public class VisionConfig
    {
        #region Override IPrim's Property
        public string Name
        { set; get; }

        public string PrimTypeName
        { set; get; }

        public Guid Id
        { set; get; }

        //Prim 子类的类型
        public Type ChildType
        { set; get; }

        //Prim的硬件、软件类型
        public PrimType HSType
        { set; get; }

        public PrimManufacture Manu
        { set; get; }

        public PrimVer Ver
        { set; get; }
        public PrimConnState PrimConnStat
        { set; get; }

        public PrimRunState PrimRunStat
        { set; get; }

        public bool PrimSimulator
        { set; get; }

        public bool PrimDebug
        { set; get; }

        public bool PrimEnable
        { set; get; }
        public bool LogEnable
        { set; get; }
        #endregion

        #region Override ISkt Property

        #endregion

        #region GoldVision Property
        public string GvFilePath { get; set; }
        public string GvFileName { get; set; }
        public List<string> OutputConfig { get; set; }
        #endregion

        public VisionConfig()
        {
            OutputConfig = new List<string>();
        }
    }

}
