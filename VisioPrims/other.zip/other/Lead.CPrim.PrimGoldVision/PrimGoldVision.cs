﻿using Lead.CPrim.Interfaces;
using Lead.CPrim.LogHelper;
using Lead.CPrim.XmlHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using CommonStruct2D.VisionStruct;
using System.Linq;
using LogicCenter2D;
using VisionGraphic2D;

namespace Lead.CPrim.PrimGoldVision
{
    public class PrimGoldVision : IPrim, IGoldVision
    {

        public event PrimDataRefresh OnPrimDataRefresh;
        public event PrimOpLog OnPrimOpLog;
        public event PrimStateChanged OnPrimStateChanged;

        public event EventHandler OnConfigChanged;

        public event DelegateMotionCtrl motionCtrl;
        public event DelegateGuidRunOutsideShowEventHandle UpdateUIEvent;
        public event DelegateCaptureFinish CaptureFinishEvent;
        public event DelegateTaskFinish taskFinishEvent;
        public event DelegateAlignResultOut alignResultEvent;
        public event DelegateStringEventHandle updateMsgEvent;

        public VisionConfig _config = null;
        internal LogicControl Logic;

        #region Private Feilds
        private Control _primDebugUI = null;

        private Control _primConfigUI = null;

        private Control _primOutputUI = null;

        #endregion


        #region Constructor

        public PrimGoldVision()
        {
            Logic = new LogicControl(); 
            _config = new VisionConfig();
            _primDebugUI = new PrimDebugControl(this);
            _primConfigUI = new PrimConfigControl(this);
            _primOutputUI = new PrimOutputControl(this);
            OnConfigChanged += PrimGoldVision_OnConfigChanged;
            Logic.updateMsgEvent += Logic_updateMsgEvent;
            Logic.updateUIEvent += Logic_updateUIEvent; 
            Logic.captureFinishEvent += Logic_captureFinishEvent; 
            Logic.taskFinishEvent += Logic_taskFinishEvent; 
            Logic.alignResultEvent += Logic_alignResultEvent;
            Logic.motionCtrl += Logic_motionCtrl; 
            PrimConnStat = PrimConnState.Other;
            PrimRunStat = PrimRunState.Other;

        }

        public PrimGoldVision(XmlNode xmlNode)
        {
            if (xmlNode != null)
            {
                _config = XMLHelper.XMLToObject(xmlNode, typeof(VisionConfig)) as VisionConfig;
            }
            else { return; }
            Logic = new LogicControl();
            
            Logic.updateMsgEvent += Logic_updateMsgEvent;
            Logic.updateUIEvent += Logic_updateUIEvent; 
            Logic.captureFinishEvent += Logic_captureFinishEvent; 
            Logic.taskFinishEvent += Logic_taskFinishEvent; 
            Logic.alignResultEvent += Logic_alignResultEvent; 
            Logic.motionCtrl += Logic_motionCtrl; 

            _primDebugUI = new PrimDebugControl(this);      
            _primConfigUI = new PrimConfigControl(this);
            _primOutputUI = new PrimOutputControl(this);
            OnConfigChanged += PrimGoldVision_OnConfigChanged;

            PrimConnStat = PrimConnState.Other;
            PrimRunStat = PrimRunState.Other;
      
        }

        public void UpdateOutputControl()
        {
            if (OnConfigChanged != null)
                OnConfigChanged.Invoke(new object(), new EventArgs());
        }

        private void PrimGoldVision_OnConfigChanged(object sender, EventArgs e)
        {
            ((PrimOutputControl)_primOutputUI).UpdateTableLayout();
        }

        private bool Logic_motionCtrl(string taskName, string primName, VisionPointAngle step, out VisionPointAngle pos)
        {
            
           if (this.motionCtrl != null)
           {
               return  motionCtrl(taskName, primName, step, out pos);
           }
           else
           {
               pos = new VisionPointAngle ();
               return false;
           }
        }

        private void Logic_alignResultEvent(List<AlignResult> alignResult)
        {
            if (this.alignResultEvent != null)
            {
                eventInvoket(() => { this.alignResultEvent(alignResult); });
            }
        }

        private void Logic_taskFinishEvent(string taskName, bool bSucess)
        {
            if (this.taskFinishEvent != null)
            {
                eventInvoket(() => { this.taskFinishEvent(taskName, bSucess); });
            }
        }

        private void Logic_captureFinishEvent(string taskName)
        {
            if (this.CaptureFinishEvent != null)
            {
                eventInvoket(() => { this.CaptureFinishEvent(taskName); });
            }
        }

        private bool Logic_updateUIEvent(string strTask)
        {
            if (this.UpdateUIEvent != null)
            {
                eventInvoket(() => { this.UpdateUIEvent(strTask); });
                //List<OutputStruct> a=Logic.GetAllTaskOutput(new List<string>() { "工序1", "工序2" });
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool Logic_updateMsgEvent(string strArgs)
        {
            if (this.updateMsgEvent != null)
            {
                eventInvoket(() => { this.updateMsgEvent(strArgs); });
                return true;
            }
            else
            {
                return false;
            }
          
        }

        #endregion

        #region Override IPrim Property
        public Type ChildType
        {
            get => _config.ChildType;

            set => _config.ChildType = value;
        }
        

        public PrimType HSType
        {
            get => _config.HSType;

            set => _config.HSType = value;
        }

        public Guid Id
        {
            get => _config.Id;

            set => _config.Id = value;
        }

        public PrimManufacture Manu
        {
            get => _config.Manu;

            set => _config.Manu = value;
        }

        public string Name
        {
            get => _config.Name;

            set => _config.Name = value;
        }

        public PrimConnState PrimConnStat
        {
            get => _config.PrimConnStat;

            set => _config.PrimConnStat = value;
        }

        public bool PrimDebug
        {
            get => _config.PrimDebug;

            set => _config.PrimDebug = value;
        }

        public LogLevel PrimAlarmLv { get; set; }
        public RunMode PrimRunMode { get; set; }
        public PrimRunState PrimRunStat
        {
            get => _config.PrimRunStat;

            set => _config.PrimRunStat = value;
        }

        public bool PrimSimulator
        {
            get => _config.PrimSimulator;

            set => _config.PrimSimulator = value;
        }

        public string PrimTypeName
        {
            get => _config.PrimTypeName;

            set => _config.PrimTypeName = value;
        }

        public PrimVer Ver
        {
            get => _config.Ver;

            set => _config.Ver = value;
        }
        public bool PrimEnable
        {
            get => _config.PrimEnable;

            set => _config.PrimEnable = value;
        }
        public bool LogEnable
        {
            get => _config.LogEnable;

            set => _config.LogEnable = value;
        }
        public string GvFilePath
        {
            get => _config.GvFilePath;

            set => _config.GvFilePath = value;
        }
        public string GvFileName
        {
            get => _config.GvFileName;

            set => _config.GvFileName = value;
        }

        public List<string> OutputConfig
        {
            get => _config.OutputConfig;

            set => _config.OutputConfig = value;
        }
        public Control PrimConfigUI => _primConfigUI;
        public Control PrimDebugUI => _primDebugUI;
        public Control PrimOutputUI => _primOutputUI;
        public int IPrimTaskInit()
        {
            if (IPrimInit() != 0)
            {
                return -1;
            }
            var connRet = "";
            if (IPrimConnect(ref connRet) != 0)
            {
                return -2;
            }

            if (IPrimStart() != 0)
            {
                return -3;
            }

            return 0;
        }

        public int IPrimTaskPause()
        {
            return 0;
        }

        public int IPrimTaskStop()
        {
            var unConnRet = "";
            if (IPrimDisConnect(ref unConnRet) != 0)
            {
                return -2;
            }

            if (IPrimStop() != 0)
            {
                return -1;
            }
            return 0;
        }

        public int IPrimTaskReset()
        {
            if (IPrimReset() != 0)
            {
                return -1;
            }

            return 0;
        }

        public int IPrimInit()
        {
            return 0;
        }

        public int IPrimConnect(ref string result)
        {
            return 0;
        }

        public int IPrimStart()
        {
            return 0;
        }

        public int IPrimStop()
        {
            return 0;
        }

        public int IPrimDisConnect(ref string result)
        {
            return 0;
        }

        public int IPrimSuspend()
        {
            return 0;;
        }

        public int IPrimResume()
        {
            return 0;
        }

        public int IPrimDispose()
        {
            return 0;
        }

        public int IPrimReset()
        {
            return 0;
        }

        public int IPrimImportConfigXml(XmlNode xmlNode)
        {
            var iRet = 0;
            if (xmlNode != null)
            {
                _config = XMLHelper.XMLToObject(xmlNode, typeof(VisionConfig)) as VisionConfig;
            }
            else { return -1; }
            return iRet;
        }

        public XmlNode IPrimExportConfigXml()
        {
            if (_config == null) { return null; }

            var node = XMLHelper.ObjectToXML(_config);
            return node;
            ;
        }

        public Form GetMainForm()
        {
             return new Form ();

        }

        public bool LoadTaskParam(string fileName, string productName, out string errCode)
        {
            if (productName == null)
                fileName = string.IsNullOrEmpty(fileName)
                    ? $@"{GvFilePath}\{GvFileName}.gv"
                    : $@"{GvFilePath}\{fileName}.task";
            else
                fileName = string.IsNullOrEmpty(fileName)
                    ? $@"{GvFilePath}\{productName}\{GvFileName}.task"
                    : $@"{GvFilePath}\{productName}\{fileName}.task";

            if (!File.Exists(fileName))
            {
                errCode = "任务文件不存在";
                return false;
            }
            return  Logic.LoadTaskParam(fileName, out errCode);
        }
        /// <summary>
        /// 运行任务
        /// </summary>
        /// <param name="strTaskNameLst"></param>
        /// <param name="bExternal"></param>
        /// <param name="errCode"></param>
        /// <param name="CapturePosition"></param>
        /// <returns></returns>
        public bool TaskRun(List<string> strTaskNameLst, bool bExternal, out string errCode, VisionPointAngle CapturePosition)
        {
            if (strTaskNameLst == null)
            {
                strTaskNameLst = OutputConfig;
            }
            return Logic.TaskRun(strTaskNameLst, bExternal, out errCode, CapturePosition);
        }
        /// <summary>
        /// 获取Task结果
        /// </summary>
        /// <param name="strTaskName"></param>
        /// <param name="variableName"></param>
        /// <returns></returns>
        public List<OutputStruct> GetTaskOutput(string strTaskName, string variableName)
        {
            return Logic.GetTaskOutput(strTaskName, variableName);
        }

        public List<OutputStruct> GetAllTaskOutput(List<string> strTaskNameLst = null)
        {
            if (strTaskNameLst == null)
            {
                strTaskNameLst = OutputConfig;
            }
            return Logic.GetAllTaskOutput(strTaskNameLst);
        }

        /// <summary>
        /// 执行对位操作
        /// </summary>
        /// <param name="strStationName">工站名称选择哪个工站</param>
        /// <param name="alignTrigInfo">设置目标工位和源工位名称</param>
        /// <returns></returns>
        public bool GetAlignResult(string strStationName, List<AlignTrigInfo> alignTrigInfo)
        {
            return Logic.GetAlignResult (strStationName, alignTrigInfo);
        }

        public void UpdateResultToMap2d(Map2D graph2d, string strTask)
        {
            Logic.UpdateResultToMap2d(graph2d, strTask);
        }

        

        /// <summary>
        /// 外部调用是否需要用Invoket
        /// </summary>
        /// <param name="func">事件参数</param>
        internal static void eventInvoket(Action func)
        {
            Form form = Application.OpenForms.Cast<Form>().FirstOrDefault();
            if (form != null && form.InvokeRequired)
            {
                form.Invoke(func);

            }
            else
            {
                func();
            }
        }


        #endregion



    }
}
