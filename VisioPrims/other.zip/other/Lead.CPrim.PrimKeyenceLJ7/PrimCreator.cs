﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Lead.CPrim.Interfaces;
using Lead.CPrim.PrimKeyenceLJ7;
using System.Xml;


namespace Lead.CPrim.Interfaces
{
    public class PrimCreator : IPrimCreator
    {
        public IPrimTypeAttributes ConcretePrimTypeAttributes => new PrimTypeAttributes();

        public IPrim Create()
        {
            return new PrimKeyence();
        }

        public IPrim Create(XmlNode taskPrimConfig)
        {
            return new PrimKeyence(taskPrimConfig);
        }


    }
}
