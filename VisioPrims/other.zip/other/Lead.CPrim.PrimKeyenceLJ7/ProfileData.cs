﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;


namespace Lead.CPrim.PrimKeyenceLJ7
{
    /// <summary>
    /// Profile data class
    /// </summary>
    public class ProfileData
    {
        #region Field

        /// <summary>
        /// Trigger count
        /// </summary>
        private int _triggerCnt;

        /// <summary>
        /// Encoder count
        /// </summary>
        private int _encoderCnt;

        /// <summary>
        /// Profile data
        /// </summary>
        private int[] _profData;

        /// <summary>
        /// Profile information
        /// </summary>
        private LJV7IF_PROFILE_INFO _profileInfo;

        #endregion

        #region Property
        /// <summary>
        /// Trigger count
        /// </summary>
        public int TriggerCnt => _triggerCnt;

        /// <summary>
        /// Encoder count
        /// </summary>
        public int EncodeCnt => _encoderCnt;

        /// <summary>
        /// Profile Data
        /// </summary>
        public int[] ProfDatas => _profData;

        /// <summary>
        /// Profile Imformation
        /// </summary>
        public LJV7IF_PROFILE_INFO ProfInfo => _profileInfo;

        #endregion

        #region Method
        /// <summary>
        /// Constructor
        /// </summary>
        public ProfileData(int[] receiveBuffer, LJV7IF_PROFILE_INFO profileInfo)
        {
            SetData(receiveBuffer, profileInfo);
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="receiveBuffer">Receive buffer</param>
        /// <param name="startIndex">Start position</param>
        /// <param name="profileInfo">Profile information</param>
        public ProfileData(byte[] receiveBuffer, int startIndex, LJV7IF_PROFILE_INFO profileInfo)
        {
            var bufIntSize = CalculateDataSize(profileInfo);
            var bufIntArray = new int[bufIntSize];
            _profileInfo = profileInfo;

            // Conversion from byte[] to int[]
            for (var i = 0; i < bufIntSize; i++)
            {
                bufIntArray[i] = BitConverter.ToInt32(receiveBuffer, (startIndex + i * Marshal.SizeOf(typeof(int))));
            }
            SetData(bufIntArray, profileInfo);
        }

        /// <summary>
        /// Constructor Overload
        /// </summary>
        /// <param name="receiveBuffer">Receive buffer</param>
        /// <param name="startIndex">Start position</param>
        /// <param name="profileInfo">Profile information</param>
        public ProfileData(int[] receiveBuffer, int startIndex, LJV7IF_PROFILE_INFO profileInfo)
        {
            var bufIntSize = CalculateDataSize(profileInfo);
            var bufIntArray = new int[bufIntSize];
            _profileInfo = profileInfo;

            Array.Copy(receiveBuffer, startIndex, bufIntArray, 0, bufIntSize);
            SetData(bufIntArray, profileInfo);
        }

        /// <summary>
        /// Set the members to the arguments.
        /// </summary>
        /// <param name="receiveBuffer">Receive buffer</param>
        /// <param name="profileInfo">Profile information</param>
        private void SetData(int[] receiveBuffer, LJV7IF_PROFILE_INFO profileInfo)
        {
            _profileInfo = profileInfo;

            // Extract the header.
            var headerSize = Utility.GetByteSize(Utility.TypeOfStruct.PROFILE_HEADER) / Marshal.SizeOf(typeof(int));
            var headerData = new int[headerSize];
            Array.Copy(receiveBuffer, 0, headerData, 0, headerSize);
            _triggerCnt = headerData[1];
            _encoderCnt = headerData[2];

            // Extract the footer.
            var footerSize = Utility.GetByteSize(Utility.TypeOfStruct.PROFILE_FOOTER) / Marshal.SizeOf(typeof(int));
            var footerData = new int[footerSize];
            Array.Copy(receiveBuffer, receiveBuffer.Length - footerSize, footerData, 0, footerSize);

            // Extract the profile data.
            var profSize = receiveBuffer.Length - headerSize - footerSize;
            _profData = new int[profSize];
            Array.Copy(receiveBuffer, headerSize, _profData, 0, profSize);
        }

        /// <summary>
        /// Get the data string.
        /// </summary>
        /// <returns>Retained data</returns>
        public StringBuilder GetStringData()
        {
            var retString = new StringBuilder();

            retString.AppendLine(string.Format(@"Trigger count	:{0}", _triggerCnt));
            retString.AppendLine(string.Format(@"Encoder count:{0}", _encoderCnt));

            return retString;
        }

        /// <summary>
        /// Data size calculation
        /// </summary>
        /// <param name="profileInfo">Profile information</param>
        /// <returns>Profile data size</returns>
        static public int CalculateDataSize(LJV7IF_PROFILE_INFO profileInfo)
        {
            var header = new LJV7IF_PROFILE_HEADER();
            var footer = new LJV7IF_PROFILE_FOOTER();

            return profileInfo.wProfDataCnt * profileInfo.byProfileCnt * (profileInfo.byEnvelope + 1) +
                (Marshal.SizeOf(header) + Marshal.SizeOf(footer)) / Marshal.SizeOf(typeof(int));
        }

        /// <summary>
        /// ToString override
        /// </summary>
        /// <returns>String for display</returns>
        public override string ToString()
        {
            var sb = new StringBuilder();

            // Data position calculation
            double posX = ProfInfo.lXStart;
            double deltaX = ProfInfo.lXPitch;

            int singleProfileCount = ProfInfo.wProfDataCnt;
            var dataCount = (int)ProfInfo.byProfileCnt * (ProfInfo.byEnvelope + 1);

            for (var i = 0; i < singleProfileCount; i++)
            {
                sb.AppendFormat("{0}\t", posX + deltaX * i);
                for (var j = 0; j < dataCount; j++)
                {
                    sb.AppendFormat("{0}\t", _profData[i + ProfInfo.wProfDataCnt * j]);
                }
                sb.AppendLine();
            }

            return sb.ToString();
        }

        /// <summary>
        /// Create the X-position string from the profile information.
        /// </summary>
        /// <param name="profileInfo">Profile information</param>
        /// <returns>X-position string</returns>
        public static string GetXPosString(LJV7IF_PROFILE_INFO profileInfo)
        {
            var sb = new StringBuilder();
            // Data position calculation
            double posX = profileInfo.lXStart;
            double deltaX = profileInfo.lXPitch;

            int singleProfileCount = profileInfo.wProfDataCnt;
            var dataCount = (int)profileInfo.byProfileCnt * (profileInfo.byEnvelope + 1);

            for (var i = 0; i < dataCount; i++)
            {
                for (var j = 0; j < singleProfileCount; j++)
                {
                    sb.AppendFormat("{0}\t", (posX + deltaX * j));
                }
            }
            return sb.ToString();
        }

        #endregion
    }
}
