﻿using System;
using Lead.CPrim.Interfaces;

namespace Lead.CPrim.PrimLightSource
{
    public class LightSourceConfig
    {
        //Prim 子类的类型
        public Type ChildType { set; get; }

        //Prim的硬件、软件类型
        public PrimType HSType { set; get; }

        public Guid Id { set; get; }
        public PrimManufacture Manu { set; get; }
        public string Name { set; get; }

        public PrimConnState PrimConnStat { set; get; }
        public bool PrimDebug { set; get; }
        public bool PrimEnable { set; get; }
        public PrimRunState PrimRunStat { set; get; }
        public bool PrimSimulator { set; get; }
        public string PrimTypeName { set; get; }
        public PrimVer Ver { set; get; }
    }
}