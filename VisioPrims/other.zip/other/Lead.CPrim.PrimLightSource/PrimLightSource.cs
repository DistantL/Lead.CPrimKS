﻿using System;
using System.Windows.Forms;
using System.Xml;
using Lead.CPrim.Interfaces;
using Lead.CPrim.LogHelper;
using Lead.CPrim.PrimLightSource.Controls;
using Lead.CPrim.XmlHelper;

namespace Lead.CPrim.PrimLightSource
{
    public class PrimLightSource : IPrim
    {
        private LightSourceConfig _config;

        public PrimLightSource()
        {
            _config = new LightSourceConfig();
            PrimDebugUI = new PrimDebugControl();
            PrimConfigUI = new PrimConfigControl();
            PrimOutputUI = new PrimOutputControl();
        }

        public PrimLightSource(XmlNode xmlNode)
        {
            //xmlNode turn to _config
            if (xmlNode != null)
                _config = XMLHelper.XMLToObject(xmlNode, typeof(LightSourceConfig)) as LightSourceConfig;
            else
                return;

            PrimDebugUI = new PrimDebugControl();
            PrimConfigUI = new PrimConfigControl();
            PrimOutputUI = new PrimOutputControl();
        }

        public event PrimDataRefresh OnPrimDataRefresh;

        public event PrimOpLog OnPrimOpLog;

        public event PrimStateChanged OnPrimStateChanged;

        public Type ChildType
        {
            set => _config.ChildType = value;
            get => _config.ChildType;
        }

        public PrimType HSType
        {
            set => _config.HSType = value;
            get => _config.HSType;
        }

        public Guid Id
        {
            set => _config.Id = value;
            get => _config.Id;
        }

        public bool LogEnable { get; set; } = true;

        public PrimManufacture Manu
        {
            set => _config.Manu = value;
            get => _config.Manu;
        }

        public string Name
        {
            set => _config.Name = value;
            get => _config.Name;
        }

        public LogLevel PrimAlarmLv { get; set; }

        public Control PrimConfigUI { get; }

        public PrimConnState PrimConnStat
        {
            set => _config.PrimConnStat = value;
            get => _config.PrimConnStat;
        }

        public bool PrimDebug
        {
            set => _config.PrimDebug = value;
            get => _config.PrimDebug;
        }

        public Control PrimDebugUI { get; }

        public bool PrimEnable
        {
            set => _config.PrimEnable = value;
            get => _config.PrimEnable;
        }

        public Control PrimOutputUI { get; }

        public RunMode PrimRunMode { get; set; }

        public PrimRunState PrimRunStat
        {
            set => _config.PrimRunStat = value;
            get => _config.PrimRunStat;
        }

        public bool PrimSimulator
        {
            set => _config.PrimSimulator = value;
            get => _config.PrimSimulator;
        }

        public string PrimTypeName
        {
            set => _config.PrimTypeName = value;
            get => _config.PrimTypeName;
        }

        public PrimVer Ver
        {
            set => _config.Ver = value;
            get => _config.Ver;
        }

        public int IPrimConnect(ref string result)
        {
            var iRet = 0;
            return iRet;
        }

        public int IPrimDisConnect(ref string result)
        {
            var iRet = 0;
            return iRet;
        }

        public int IPrimDispose()
        {
            var iRet = 0;
            return iRet;
        }

        public XmlNode IPrimExportConfigXml()
        {
            if (_config == null) return null;

            var node = XMLHelper.ObjectToXML(_config);

            return node;
        }

        public int IPrimImportConfigXml(XmlNode xmlNode)
        {
            var iRet = 0;
            if (xmlNode != null)
                _config = XMLHelper.XMLToObject(xmlNode, typeof(LightSourceConfig)) as LightSourceConfig;
            else
                return -1;
            return iRet;
        }

        public int IPrimInit()
        {
            var iRet = 0;
            return iRet;
        }

        public int IPrimReset()
        {
            var iRet = 0;
            return iRet;
        }

        public int IPrimResume()
        {
            var iRet = 0;
            return iRet;
        }

        public int IPrimStart()
        {
            var iRet = 0;
            return iRet;
        }

        public int IPrimStop()
        {
            var iRet = 0;
            return iRet;
        }

        public int IPrimSuspend()
        {
            var iRet = 0;
            return iRet;
        }

        public int IPrimTaskInit()
        {
            return 0;
        }

        public int IPrimTaskPause()
        {
            return 0;
        }

        public int IPrimTaskReset()
        {
            return 0;
        }

        public int IPrimTaskStop()
        {
            return 0;
        }
    }
}