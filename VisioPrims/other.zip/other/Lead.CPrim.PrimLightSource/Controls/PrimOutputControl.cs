﻿using System.Windows.Forms;

namespace Lead.CPrim.PrimLightSource.Controls
{
    public partial class PrimOutputControl : UserControl
    {
        public PrimOutputControl()
        {
            InitializeComponent();
        }
    }
}