﻿using System.Windows.Forms;

namespace Lead.CPrim.PrimLightSource.Controls
{
    public partial class PrimDebugControl : UserControl
    {
        public PrimDebugControl()
        {
            InitializeComponent();
        }
    }
}