﻿using System.Windows.Forms;

namespace Lead.CPrim.PrimLightSource.Controls
{
    public partial class PrimConfigControl : UserControl
    {
        public PrimConfigControl()
        {
            InitializeComponent();
        }
        
    }
}