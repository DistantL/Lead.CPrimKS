﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Resources;
using Lead.CPrim.PrimLightSource;

namespace Lead.CPrim.Interfaces
{
    public class PrimTypeAttributes : IPrimTypeAttributes
    {
        public IEnumerable<KeyValuePair<string, object>> Attributes => throw new NotImplementedException();
        public string Description => "";
        public string DisplayGroup => "Vision";
        public string DisplayName => "LightSource";
        public string Group => "Vision";

        public Image Icon
        {
            get
            {
                var manager = new ResourceManager(typeof(LscResource));
                return (Image) manager.GetObject("Light");
            }
        }

        public byte MajorVersion => 1;
        public byte MinorVersion => 0;
        public string Name => "LightSource";
        public object this[string attrName] => throw new NotImplementedException();
    }
}