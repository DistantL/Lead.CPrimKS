﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Lead.CPrim.PrimLightSource.CST
{
    public struct HOST_PRM
    {
        public char[] cSn;
        public char[] cIp;
        public char[] cMac;
    }

    public struct CON_PRM
    {
        public char[] cSn;
        public char[] cIp;
        public char[] cSm;
        public char[] cGw;
        public char[] DHCP;
    }

    public struct ADAPDER_PRM
    {
        public char[] cSn;
        public char[] cIp;

    }

    public struct MulDigitalValue
    {
        public int ChannelIndex;
        public int DigitalValue;
    }

    public struct MulStrobeValue
    {
        public int ChannelIndex;
        public int StrobeValue;
    }

    public struct MulLightDelayValue
    {
        public int ChannelIndex;
        public int LightDelayValue;
    }

    public struct MulCameraDelayValue
    {
        public int ChannelIndex;
        public int CameraDelayValue;
    }
    public class CST
    {
        [DllImport("CSTControllerDll.dll", EntryPoint = "CST_CST_GetAdapter", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern int CST_CST_GetAdapter(ref ADAPDER_PRM adapderPrm);
        [DllImport("CSTControllerDll.dll", EntryPoint = "CST_EthernetGetConfigure", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern int CST_EthernetGetConfigure(string mMac, ref CON_PRM conPrm, ref string adapterIp);
        [DllImport("CSTControllerDll.dll", EntryPoint = "CST_EthernetSetConfigure", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern int CST_EthernetSetConfigure(string mMac, ref CON_PRM conPrm, string adapterIp);
        [DllImport("CSTControllerDll.dll", EntryPoint = "CST_EthernetConnectIP", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern int CST_EthernetConnectIP(string mIp, ref Int64 mConHandle);
        [DllImport("CSTControllerDll.dll", EntryPoint = "CST_EthernetConnectStop", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern int CST_EthernetConnectStop(ref Int64 mConHandle);
        [DllImport("CSTControllerDll.dll", EntryPoint = "CST_EthernetGetHost", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        public static extern int CST_EthernetGetHost(ref HOST_PRM hostPrm, ref string adapterIp);
    }
}
