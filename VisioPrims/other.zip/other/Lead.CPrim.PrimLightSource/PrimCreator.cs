﻿using System.Xml;
using Lead.CPrim.Interfaces;

namespace Lead.CPrim.PrimLightSource
{
    public class PrimCreator : IPrimCreator
    {
        public IPrimTypeAttributes ConcretePrimTypeAttributes => new PrimTypeAttributes();

        public IPrim Create()
        {
            return new PrimLightSource();
        }

        public IPrim Create(XmlNode taskPrimConfig)
        {
            return new PrimLightSource(taskPrimConfig);
        }
    }
}