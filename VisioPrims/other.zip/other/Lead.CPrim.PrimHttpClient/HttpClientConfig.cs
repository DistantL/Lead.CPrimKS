﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Lead.CPrim.Interfaces;

namespace Lead.CPrim.PrimHttpClient
{
  public  class HttpClientConfig
    {
    
        #region Override IPrim's Property
        public string Name
        { set; get; }

        public string PrimTypeName
        { set; get; }

        public Guid Id
        { set; get; }

        //Prim 子类的类型
        public Type ChildType
        { set; get; }

        //Prim的硬件、软件类型
        public PrimType HSType
        { set; get; }

        public PrimManufacture Manu
        { set; get; }

        public PrimVer Ver
        { set; get; }

        public PrimConnState PrimConnStat
        { set; get; }

        public PrimRunState PrimRunStat
        { set; get; }

        public bool PrimSimulator
        { set; get; }

        public bool PrimDebug
        { set; get; }

        public bool PrimEnable
        { set; get; }
        #endregion

        #region Override ISkt Property

        public string DstIp
        { set; get; }

        public string Port
        { set; get; }

        public int ReconnectCnt
        { set; get; }


        public string HeartInfo
        { set; get; }

        public int HeartInfoCycleTime
        { set; get; }

        public bool HeartFlag
        { set; get; }

        public int SendQueueCnt
        { set; get; }
        public int RevQueueCnt
        { set; get; }

        public string NetName
        { set; get; }
        #endregion
    }
}

