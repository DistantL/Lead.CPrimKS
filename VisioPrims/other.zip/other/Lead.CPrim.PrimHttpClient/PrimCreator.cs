﻿using Lead.CPrim.PrimHttpClient;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Lead.CPrim.Interfaces
{
   public class PrimCreator : IPrimCreator
    {
        public IPrimTypeAttributes ConcretePrimTypeAttributes
        {
            get
            {
                return new PrimTypeAttributes();
            }
        }
        public IPrim Create()
        {             
            return new HttpClient();      
        }

        public IPrim Create(XmlNode taskPrimConfig)
        {
            return new HttpClient(taskPrimConfig);
        }


    }
}
