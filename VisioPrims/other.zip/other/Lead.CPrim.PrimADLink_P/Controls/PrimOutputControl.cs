using System.Windows.Forms;

namespace Lead.CPrim.PrimADLink_P
{
    public partial class PrimOutputControl : UserControl
    {
        public PrimOutputControl()
        {
            InitializeComponent();
        }
    }
}
