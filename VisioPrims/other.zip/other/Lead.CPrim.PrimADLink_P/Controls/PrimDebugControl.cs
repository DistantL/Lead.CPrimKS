using System.Windows.Forms;

namespace Lead.CPrim.PrimADLink_P
{
    public partial class PrimDebugControl : UserControl
    {
        public PrimDebugControl()
        {
            InitializeComponent();
        }
    }
}
