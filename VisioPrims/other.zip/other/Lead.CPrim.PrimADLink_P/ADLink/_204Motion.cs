﻿using APS_Define_W32;
using APS168_W64;
using System;
using System.Windows.Forms;

namespace ADLink.DemoApp
{
    public class Adlink204C
    {
        public int StartAxisId = 0;
        public int TotalAxis = 0;
        public int CardName = 0;
        public int CardId;

        public bool IsInitialed { get; private set; }
        public bool IsLoadXmlFile { get; private set; }


        public void Initial(int cardId, int mode)
        {
            CardId = cardId;
            var boardIdInBits = 0;
            // Card(Board) initial,mode bit0(0:By system assigned, 1:By dip switch)  
            var ret = APS168.APS_initial(ref boardIdInBits, mode);
            if (ret >= 0)
            {
                IsInitialed = true;
                APS168.APS_get_first_axisId(cardId, ref StartAxisId, ref TotalAxis);
                APS168.APS_get_card_name(cardId, ref CardName);
                if (CardName != (Int32)APS_Define.DEVICE_NAME_PCI_825458 && CardName != (Int32)APS_Define.DEVICE_NAME_AMP_20408C)
                {
                    MessageBox.Show("运动控制是型号不是204C或208C！");
                    return;
                }
            }
            else
            {
                MessageBox.Show("运动控制卡初始化失败，请检查驱动是否装好或者MotionCreatePro已经开启！");
            }
        }

        public bool LoadParamFromFile(string xmlfilename)
        {
            IsLoadXmlFile = (APS168.APS_load_param_from_file(xmlfilename) == 0);
            if (IsLoadXmlFile)
            {
                AutoClosingMessageBox.Show("Load XML File OK !", "204C208C", 2000);
            }
            else
            {
                MessageBox.Show("Load XML File Failed!");
            }
            return IsLoadXmlFile;
        }
    }
}
