﻿using System.Xml;

namespace Lead.CPrim.Interfaces
{
    public class PrimCreator : IPrimCreator
    {
        public IPrimTypeAttributes ConcretePrimTypeAttributes => new PrimTypeAttributes();

        public IPrim Create()
        {
            return new PrimADLink_P.PrimADLink_P();
        }

        public IPrim Create(XmlNode taskPrimConfig)
        {
            return new PrimADLink_P.PrimADLink_P(taskPrimConfig);
        }
    }

}
