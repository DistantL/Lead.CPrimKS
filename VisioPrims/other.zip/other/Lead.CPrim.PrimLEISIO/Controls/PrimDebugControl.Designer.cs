﻿namespace Lead.CPrim.PrimLEISIO
{
    partial class PrimDebugControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label94 = new System.Windows.Forms.Label();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.label123 = new System.Windows.Forms.Label();
            this.tBoxLESIName = new System.Windows.Forms.TextBox();
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.btnInit = new System.Windows.Forms.Button();
            this.btnStop1 = new System.Windows.Forms.Button();
            this.btnRun1 = new System.Windows.Forms.Button();
            this.tBoxConnState = new System.Windows.Forms.TextBox();
            this.tBoxRunState = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label125 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label194 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label166 = new System.Windows.Forms.Label();
            this.CardIDcomboB = new System.Windows.Forms.ComboBox();
            this.comboBoxCard = new System.Windows.Forms.ComboBox();
            this.cmbSelectAxis = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tPageIO = new System.Windows.Forms.TabPage();
            this.grpDo = new System.Windows.Forms.GroupBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.grpDi = new System.Windows.Forms.GroupBox();
            this.label111 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.lbTitle = new System.Windows.Forms.Label();
            this.tmrUpdateUI = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tPageIO.SuspendLayout();
            this.grpDo.SuspendLayout();
            this.grpDi.SuspendLayout();
            this.SuspendLayout();
            // 
            // label94
            // 
            this.label94.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label94.Location = new System.Drawing.Point(589, 62);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(61, 20);
            this.label94.TabIndex = 0;
            this.label94.Tag = "15";
            this.label94.Text = ".15";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "param.ini";
            // 
            // label123
            // 
            this.label123.BackColor = System.Drawing.Color.SkyBlue;
            this.label123.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label123.Dock = System.Windows.Forms.DockStyle.Left;
            this.label123.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label123.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label123.Location = new System.Drawing.Point(0, 0);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(178, 32);
            this.label123.TabIndex = 12;
            this.label123.Text = "LESIName";
            this.label123.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tBoxLESIName
            // 
            this.tBoxLESIName.BackColor = System.Drawing.Color.OldLace;
            this.tBoxLESIName.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tBoxLESIName.Location = new System.Drawing.Point(180, 2);
            this.tBoxLESIName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tBoxLESIName.Multiline = true;
            this.tBoxLESIName.Name = "tBoxLESIName";
            this.tBoxLESIName.Size = new System.Drawing.Size(188, 31);
            this.tBoxLESIName.TabIndex = 13;
            this.tBoxLESIName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox
            // 
            this.groupBox.Controls.Add(this.btnInit);
            this.groupBox.Controls.Add(this.btnStop1);
            this.groupBox.Controls.Add(this.btnRun1);
            this.groupBox.Font = new System.Drawing.Font("微软雅黑", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox.Location = new System.Drawing.Point(796, 40);
            this.groupBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox.Name = "groupBox";
            this.groupBox.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox.Size = new System.Drawing.Size(244, 82);
            this.groupBox.TabIndex = 131;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "EXE";
            // 
            // btnInit
            // 
            this.btnInit.BackColor = System.Drawing.Color.SkyBlue;
            this.btnInit.Location = new System.Drawing.Point(5, 35);
            this.btnInit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnInit.Name = "btnInit";
            this.btnInit.Size = new System.Drawing.Size(67, 40);
            this.btnInit.TabIndex = 107;
            this.btnInit.Text = "Init";
            this.btnInit.UseVisualStyleBackColor = false;
            this.btnInit.Click += new System.EventHandler(this.btnInit_Click);
            // 
            // btnStop1
            // 
            this.btnStop1.BackColor = System.Drawing.Color.SandyBrown;
            this.btnStop1.Location = new System.Drawing.Point(155, 35);
            this.btnStop1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnStop1.Name = "btnStop1";
            this.btnStop1.Size = new System.Drawing.Size(67, 40);
            this.btnStop1.TabIndex = 105;
            this.btnStop1.Text = "Stop";
            this.btnStop1.UseVisualStyleBackColor = false;
            this.btnStop1.Click += new System.EventHandler(this.btnStop1_Click);
            // 
            // btnRun1
            // 
            this.btnRun1.BackColor = System.Drawing.Color.LightGreen;
            this.btnRun1.Location = new System.Drawing.Point(81, 35);
            this.btnRun1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnRun1.Name = "btnRun1";
            this.btnRun1.Size = new System.Drawing.Size(67, 40);
            this.btnRun1.TabIndex = 105;
            this.btnRun1.Text = "Run";
            this.btnRun1.UseVisualStyleBackColor = false;
            this.btnRun1.Click += new System.EventHandler(this.btnRun1_Click);
            // 
            // tBoxConnState
            // 
            this.tBoxConnState.BackColor = System.Drawing.Color.Khaki;
            this.tBoxConnState.Dock = System.Windows.Forms.DockStyle.Right;
            this.tBoxConnState.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tBoxConnState.Location = new System.Drawing.Point(757, 0);
            this.tBoxConnState.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tBoxConnState.Multiline = true;
            this.tBoxConnState.Name = "tBoxConnState";
            this.tBoxConnState.Size = new System.Drawing.Size(188, 32);
            this.tBoxConnState.TabIndex = 15;
            this.tBoxConnState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tBoxRunState
            // 
            this.tBoxRunState.BackColor = System.Drawing.Color.Khaki;
            this.tBoxRunState.Dock = System.Windows.Forms.DockStyle.Right;
            this.tBoxRunState.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tBoxRunState.Location = new System.Drawing.Point(945, 0);
            this.tBoxRunState.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tBoxRunState.Multiline = true;
            this.tBoxRunState.Name = "tBoxRunState";
            this.tBoxRunState.Size = new System.Drawing.Size(188, 32);
            this.tBoxRunState.TabIndex = 14;
            this.tBoxRunState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tBoxConnState);
            this.panel1.Controls.Add(this.tBoxRunState);
            this.panel1.Controls.Add(this.label123);
            this.panel1.Controls.Add(this.tBoxLESIName);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1133, 32);
            this.panel1.TabIndex = 29;
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label125.Location = new System.Drawing.Point(4, 55);
            this.label125.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(112, 24);
            this.label125.TabIndex = 24;
            this.label125.Text = "Select Card:";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 33);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.splitContainer1.Panel1.Controls.Add(this.comboBox1);
            this.splitContainer1.Panel1.Controls.Add(this.label194);
            this.splitContainer1.Panel1.Controls.Add(this.numericUpDown2);
            this.splitContainer1.Panel1.Controls.Add(this.label166);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox);
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            this.splitContainer1.Panel1.Controls.Add(this.CardIDcomboB);
            this.splitContainer1.Panel1.Controls.Add(this.comboBoxCard);
            this.splitContainer1.Panel1.Controls.Add(this.cmbSelectAxis);
            this.splitContainer1.Panel1.Controls.Add(this.label125);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer1.Size = new System.Drawing.Size(1133, 545);
            this.splitContainer1.SplitterDistance = 125;
            this.splitContainer1.SplitterWidth = 3;
            this.splitContainer1.TabIndex = 5;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Items.AddRange(new object[] {
            "0:1000Kbps",
            "1:800Kbps",
            "2:500Kbps",
            "3:250Kbps",
            "4:125Kbps",
            "5:100Kbps"});
            this.comboBox1.Location = new System.Drawing.Point(565, 92);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(99, 23);
            this.comboBox1.TabIndex = 135;
            // 
            // label194
            // 
            this.label194.AutoSize = true;
            this.label194.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label194.Location = new System.Drawing.Point(477, 93);
            this.label194.Name = "label194";
            this.label194.Size = new System.Drawing.Size(69, 20);
            this.label194.TabIndex = 134;
            this.label194.Text = "Bit Rate:";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(411, 93);
            this.numericUpDown2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.ReadOnly = true;
            this.numericUpDown2.Size = new System.Drawing.Size(49, 25);
            this.numericUpDown2.TabIndex = 133;
            this.numericUpDown2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label166
            // 
            this.label166.AutoSize = true;
            this.label166.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label166.Location = new System.Drawing.Point(243, 98);
            this.label166.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label166.Name = "label166";
            this.label166.Size = new System.Drawing.Size(155, 20);
            this.label166.TabIndex = 132;
            this.label166.Text = "CAN Node Number:";
            // 
            // CardIDcomboB
            // 
            this.CardIDcomboB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CardIDcomboB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CardIDcomboB.FormattingEnabled = true;
            this.CardIDcomboB.Location = new System.Drawing.Point(273, 52);
            this.CardIDcomboB.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.CardIDcomboB.Name = "CardIDcomboB";
            this.CardIDcomboB.Size = new System.Drawing.Size(88, 26);
            this.CardIDcomboB.TabIndex = 25;
            // 
            // comboBoxCard
            // 
            this.comboBoxCard.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxCard.FormattingEnabled = true;
            this.comboBoxCard.Location = new System.Drawing.Point(115, 52);
            this.comboBoxCard.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.comboBoxCard.Name = "comboBoxCard";
            this.comboBoxCard.Size = new System.Drawing.Size(96, 26);
            this.comboBoxCard.TabIndex = 25;
            // 
            // cmbSelectAxis
            // 
            this.cmbSelectAxis.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectAxis.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelectAxis.FormattingEnabled = true;
            this.cmbSelectAxis.Location = new System.Drawing.Point(115, 98);
            this.cmbSelectAxis.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbSelectAxis.Name = "cmbSelectAxis";
            this.cmbSelectAxis.Size = new System.Drawing.Size(97, 26);
            this.cmbSelectAxis.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 98);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 24);
            this.label3.TabIndex = 24;
            this.label3.Text = "Select Axis :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(235, 55);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 24);
            this.label1.TabIndex = 18;
            this.label1.Text = "Id:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tPageIO);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1133, 417);
            this.tabControl1.TabIndex = 0;
            // 
            // tPageIO
            // 
            this.tPageIO.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tPageIO.Controls.Add(this.grpDo);
            this.tPageIO.Controls.Add(this.grpDi);
            this.tPageIO.Location = new System.Drawing.Point(4, 25);
            this.tPageIO.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tPageIO.Name = "tPageIO";
            this.tPageIO.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tPageIO.Size = new System.Drawing.Size(1125, 388);
            this.tPageIO.TabIndex = 2;
            this.tPageIO.Text = "IO";
            // 
            // grpDo
            // 
            this.grpDo.Controls.Add(this.label21);
            this.grpDo.Controls.Add(this.label22);
            this.grpDo.Controls.Add(this.label23);
            this.grpDo.Controls.Add(this.label24);
            this.grpDo.Controls.Add(this.label25);
            this.grpDo.Controls.Add(this.label26);
            this.grpDo.Controls.Add(this.label27);
            this.grpDo.Controls.Add(this.label28);
            this.grpDo.Controls.Add(this.label29);
            this.grpDo.Controls.Add(this.label30);
            this.grpDo.Controls.Add(this.label31);
            this.grpDo.Controls.Add(this.label32);
            this.grpDo.Controls.Add(this.label33);
            this.grpDo.Controls.Add(this.label34);
            this.grpDo.Controls.Add(this.label35);
            this.grpDo.Controls.Add(this.label36);
            this.grpDo.Controls.Add(this.label66);
            this.grpDo.Controls.Add(this.label64);
            this.grpDo.Controls.Add(this.label62);
            this.grpDo.Controls.Add(this.label61);
            this.grpDo.Controls.Add(this.label68);
            this.grpDo.Controls.Add(this.label77);
            this.grpDo.Controls.Add(this.label81);
            this.grpDo.Controls.Add(this.label84);
            this.grpDo.Controls.Add(this.label86);
            this.grpDo.Controls.Add(this.label89);
            this.grpDo.Controls.Add(this.label91);
            this.grpDo.Controls.Add(this.label92);
            this.grpDo.Controls.Add(this.label95);
            this.grpDo.Controls.Add(this.label99);
            this.grpDo.Controls.Add(this.label101);
            this.grpDo.Controls.Add(this.label102);
            this.grpDo.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpDo.Location = new System.Drawing.Point(0, 192);
            this.grpDo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpDo.Name = "grpDo";
            this.grpDo.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpDo.Size = new System.Drawing.Size(672, 192);
            this.grpDo.TabIndex = 15;
            this.grpDo.TabStop = false;
            this.grpDo.Tag = "MotionIo";
            this.grpDo.Text = "General DO";
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label66.Location = new System.Drawing.Point(589, 28);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(61, 20);
            this.label66.TabIndex = 18;
            this.label66.Tag = "7";
            this.label66.Text = ".7";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label64.Location = new System.Drawing.Point(508, 28);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(61, 20);
            this.label64.TabIndex = 17;
            this.label64.Tag = "6";
            this.label64.Text = ".6";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label62.Location = new System.Drawing.Point(427, 28);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(61, 20);
            this.label62.TabIndex = 18;
            this.label62.Tag = "5";
            this.label62.Text = ".5";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label61
            // 
            this.label61.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label61.Location = new System.Drawing.Point(344, 28);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(61, 20);
            this.label61.TabIndex = 17;
            this.label61.Tag = "4";
            this.label61.Text = ".4";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label68
            // 
            this.label68.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label68.Location = new System.Drawing.Point(16, 28);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(61, 20);
            this.label68.TabIndex = 0;
            this.label68.Tag = "0";
            this.label68.Text = ".0";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label77
            // 
            this.label77.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label77.Location = new System.Drawing.Point(427, 62);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(61, 20);
            this.label77.TabIndex = 0;
            this.label77.Tag = "13";
            this.label77.Text = ".13";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label81
            // 
            this.label81.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label81.Location = new System.Drawing.Point(344, 62);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(61, 20);
            this.label81.TabIndex = 0;
            this.label81.Tag = "12";
            this.label81.Text = ".12";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label84
            // 
            this.label84.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label84.Location = new System.Drawing.Point(180, 62);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(61, 20);
            this.label84.TabIndex = 0;
            this.label84.Tag = "10";
            this.label84.Text = ".10";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label86
            // 
            this.label86.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label86.Location = new System.Drawing.Point(99, 28);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(61, 20);
            this.label86.TabIndex = 0;
            this.label86.Tag = "1";
            this.label86.Text = ".1";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label89
            // 
            this.label89.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label89.Location = new System.Drawing.Point(99, 62);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(61, 20);
            this.label89.TabIndex = 0;
            this.label89.Tag = "9";
            this.label89.Text = ".9";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label91
            // 
            this.label91.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label91.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label91.Location = new System.Drawing.Point(16, 62);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(61, 20);
            this.label91.TabIndex = 0;
            this.label91.Tag = "8";
            this.label91.Text = ".8";
            this.label91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label92
            // 
            this.label92.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label92.Location = new System.Drawing.Point(180, 28);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(61, 20);
            this.label92.TabIndex = 0;
            this.label92.Tag = "2";
            this.label92.Text = ".2";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label95
            // 
            this.label95.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label95.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label95.Location = new System.Drawing.Point(508, 62);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(61, 20);
            this.label95.TabIndex = 0;
            this.label95.Tag = "14";
            this.label95.Text = ".14";
            this.label95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label99
            // 
            this.label99.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label99.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label99.Location = new System.Drawing.Point(261, 28);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(61, 20);
            this.label99.TabIndex = 0;
            this.label99.Tag = "3";
            this.label99.Text = ".3";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label101
            // 
            this.label101.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label101.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label101.Location = new System.Drawing.Point(261, 62);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(61, 20);
            this.label101.TabIndex = 0;
            this.label101.Tag = "11";
            this.label101.Text = ".11";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label101.Click += new System.EventHandler(this.Label101_Click);
            // 
            // label102
            // 
            this.label102.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label102.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label102.Location = new System.Drawing.Point(589, 62);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(61, 20);
            this.label102.TabIndex = 0;
            this.label102.Tag = "15";
            this.label102.Text = ".15";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grpDi
            // 
            this.grpDi.Controls.Add(this.label2);
            this.grpDi.Controls.Add(this.label4);
            this.grpDi.Controls.Add(this.label5);
            this.grpDi.Controls.Add(this.label7);
            this.grpDi.Controls.Add(this.label8);
            this.grpDi.Controls.Add(this.label9);
            this.grpDi.Controls.Add(this.label11);
            this.grpDi.Controls.Add(this.label12);
            this.grpDi.Controls.Add(this.label13);
            this.grpDi.Controls.Add(this.label14);
            this.grpDi.Controls.Add(this.label15);
            this.grpDi.Controls.Add(this.label16);
            this.grpDi.Controls.Add(this.label17);
            this.grpDi.Controls.Add(this.label18);
            this.grpDi.Controls.Add(this.label19);
            this.grpDi.Controls.Add(this.label20);
            this.grpDi.Controls.Add(this.label111);
            this.grpDi.Controls.Add(this.label106);
            this.grpDi.Controls.Add(this.label10);
            this.grpDi.Controls.Add(this.label6);
            this.grpDi.Controls.Add(this.label53);
            this.grpDi.Controls.Add(this.label54);
            this.grpDi.Controls.Add(this.label55);
            this.grpDi.Controls.Add(this.label56);
            this.grpDi.Controls.Add(this.label57);
            this.grpDi.Controls.Add(this.label58);
            this.grpDi.Controls.Add(this.label59);
            this.grpDi.Controls.Add(this.label63);
            this.grpDi.Controls.Add(this.label65);
            this.grpDi.Controls.Add(this.label74);
            this.grpDi.Controls.Add(this.label87);
            this.grpDi.Controls.Add(this.label94);
            this.grpDi.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpDi.Location = new System.Drawing.Point(5, 6);
            this.grpDi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpDi.Name = "grpDi";
            this.grpDi.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpDi.Size = new System.Drawing.Size(672, 182);
            this.grpDi.TabIndex = 16;
            this.grpDi.TabStop = false;
            this.grpDi.Tag = "MotionIo";
            this.grpDi.Text = "General DI";
            // 
            // label111
            // 
            this.label111.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label111.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label111.Location = new System.Drawing.Point(589, 28);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(61, 20);
            this.label111.TabIndex = 2;
            this.label111.Tag = "7";
            this.label111.Text = ".7";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label106
            // 
            this.label106.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label106.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label106.Location = new System.Drawing.Point(508, 28);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(61, 20);
            this.label106.TabIndex = 2;
            this.label106.Tag = "6";
            this.label106.Text = ".6";
            this.label106.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Location = new System.Drawing.Point(427, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 20);
            this.label10.TabIndex = 2;
            this.label10.Tag = "5";
            this.label10.Text = ".5";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Location = new System.Drawing.Point(344, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 20);
            this.label6.TabIndex = 1;
            this.label6.Tag = "4";
            this.label6.Text = ".4";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label53.Location = new System.Drawing.Point(16, 28);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(61, 20);
            this.label53.TabIndex = 0;
            this.label53.Tag = "0";
            this.label53.Text = ".0";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label54.Location = new System.Drawing.Point(427, 62);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(61, 20);
            this.label54.TabIndex = 0;
            this.label54.Tag = "13";
            this.label54.Text = ".13";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label55.Location = new System.Drawing.Point(344, 62);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(61, 20);
            this.label55.TabIndex = 0;
            this.label55.Tag = "12";
            this.label55.Text = ".12";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label56.Location = new System.Drawing.Point(180, 62);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(61, 20);
            this.label56.TabIndex = 0;
            this.label56.Tag = "10";
            this.label56.Text = ".10";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label57.Location = new System.Drawing.Point(99, 28);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(61, 20);
            this.label57.TabIndex = 0;
            this.label57.Tag = "1";
            this.label57.Text = ".1";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label58.Location = new System.Drawing.Point(99, 62);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(61, 20);
            this.label58.TabIndex = 0;
            this.label58.Tag = "9";
            this.label58.Text = ".9";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label59.Location = new System.Drawing.Point(16, 62);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(61, 20);
            this.label59.TabIndex = 0;
            this.label59.Tag = "8";
            this.label59.Text = ".8";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label63
            // 
            this.label63.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label63.Location = new System.Drawing.Point(180, 28);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(61, 20);
            this.label63.TabIndex = 0;
            this.label63.Tag = "2";
            this.label63.Text = ".2";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label65
            // 
            this.label65.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label65.Location = new System.Drawing.Point(508, 62);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(61, 20);
            this.label65.TabIndex = 0;
            this.label65.Tag = "14";
            this.label65.Text = ".14";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label74.Location = new System.Drawing.Point(261, 28);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(61, 20);
            this.label74.TabIndex = 0;
            this.label74.Tag = "3";
            this.label74.Text = ".3";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label87
            // 
            this.label87.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label87.Location = new System.Drawing.Point(261, 62);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(61, 20);
            this.label87.TabIndex = 0;
            this.label87.Tag = "11";
            this.label87.Text = ".11";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbTitle
            // 
            this.lbTitle.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lbTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbTitle.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTitle.Location = new System.Drawing.Point(0, 0);
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.Size = new System.Drawing.Size(1133, 33);
            this.lbTitle.TabIndex = 4;
            this.lbTitle.Text = "LESI Config";
            this.lbTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tmrUpdateUI
            // 
            this.tmrUpdateUI.Interval = 50;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Location = new System.Drawing.Point(589, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 20);
            this.label2.TabIndex = 16;
            this.label2.Tag = "7";
            this.label2.Text = ".23";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Location = new System.Drawing.Point(508, 102);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 20);
            this.label4.TabIndex = 17;
            this.label4.Tag = "6";
            this.label4.Text = ".22";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Location = new System.Drawing.Point(427, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 20);
            this.label5.TabIndex = 18;
            this.label5.Tag = "5";
            this.label5.Text = ".21";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Location = new System.Drawing.Point(344, 102);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 20);
            this.label7.TabIndex = 15;
            this.label7.Tag = "4";
            this.label7.Text = ".20";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Location = new System.Drawing.Point(16, 102);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 20);
            this.label8.TabIndex = 3;
            this.label8.Tag = "0";
            this.label8.Text = ".16";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Location = new System.Drawing.Point(427, 136);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 20);
            this.label9.TabIndex = 4;
            this.label9.Tag = "13";
            this.label9.Text = ".29";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Location = new System.Drawing.Point(344, 136);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 20);
            this.label11.TabIndex = 5;
            this.label11.Tag = "12";
            this.label11.Text = ".28";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Location = new System.Drawing.Point(180, 136);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 20);
            this.label12.TabIndex = 6;
            this.label12.Tag = "10";
            this.label12.Text = ".26";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Location = new System.Drawing.Point(99, 102);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 20);
            this.label13.TabIndex = 7;
            this.label13.Tag = "1";
            this.label13.Text = ".17";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Location = new System.Drawing.Point(99, 136);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 20);
            this.label14.TabIndex = 8;
            this.label14.Tag = "9";
            this.label14.Text = ".25";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Location = new System.Drawing.Point(16, 136);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 20);
            this.label15.TabIndex = 9;
            this.label15.Tag = "8";
            this.label15.Text = ".24";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Location = new System.Drawing.Point(180, 102);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 20);
            this.label16.TabIndex = 10;
            this.label16.Tag = "2";
            this.label16.Text = ".18";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Location = new System.Drawing.Point(508, 136);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 20);
            this.label17.TabIndex = 11;
            this.label17.Tag = "14";
            this.label17.Text = ".30";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Location = new System.Drawing.Point(261, 102);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(61, 20);
            this.label18.TabIndex = 12;
            this.label18.Tag = "3";
            this.label18.Text = ".19";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.Location = new System.Drawing.Point(261, 136);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 20);
            this.label19.TabIndex = 13;
            this.label19.Tag = "11";
            this.label19.Text = ".27";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Location = new System.Drawing.Point(589, 136);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 20);
            this.label20.TabIndex = 14;
            this.label20.Tag = "15";
            this.label20.Text = ".31";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.Location = new System.Drawing.Point(589, 100);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(61, 20);
            this.label21.TabIndex = 33;
            this.label21.Tag = "7";
            this.label21.Text = ".7";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Location = new System.Drawing.Point(508, 100);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(61, 20);
            this.label22.TabIndex = 31;
            this.label22.Tag = "6";
            this.label22.Text = ".6";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Location = new System.Drawing.Point(427, 100);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(61, 20);
            this.label23.TabIndex = 34;
            this.label23.Tag = "5";
            this.label23.Text = ".5";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Location = new System.Drawing.Point(344, 100);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(61, 20);
            this.label24.TabIndex = 32;
            this.label24.Tag = "4";
            this.label24.Text = ".4";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Location = new System.Drawing.Point(16, 100);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(61, 20);
            this.label25.TabIndex = 19;
            this.label25.Tag = "0";
            this.label25.Text = ".0";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.Location = new System.Drawing.Point(427, 134);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(61, 20);
            this.label26.TabIndex = 20;
            this.label26.Tag = "13";
            this.label26.Text = ".13";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label27.Location = new System.Drawing.Point(344, 134);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(61, 20);
            this.label27.TabIndex = 21;
            this.label27.Tag = "12";
            this.label27.Text = ".12";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label28.Location = new System.Drawing.Point(180, 134);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(61, 20);
            this.label28.TabIndex = 22;
            this.label28.Tag = "10";
            this.label28.Text = ".10";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label29.Location = new System.Drawing.Point(99, 100);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(61, 20);
            this.label29.TabIndex = 23;
            this.label29.Tag = "1";
            this.label29.Text = ".1";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label30.Location = new System.Drawing.Point(99, 134);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(61, 20);
            this.label30.TabIndex = 24;
            this.label30.Tag = "9";
            this.label30.Text = ".9";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.Location = new System.Drawing.Point(16, 134);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(61, 20);
            this.label31.TabIndex = 25;
            this.label31.Tag = "8";
            this.label31.Text = ".8";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label32.Location = new System.Drawing.Point(180, 100);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(61, 20);
            this.label32.TabIndex = 26;
            this.label32.Tag = "2";
            this.label32.Text = ".2";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label33.Location = new System.Drawing.Point(508, 134);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(61, 20);
            this.label33.TabIndex = 27;
            this.label33.Tag = "14";
            this.label33.Text = ".14";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label34.Location = new System.Drawing.Point(261, 100);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(61, 20);
            this.label34.TabIndex = 28;
            this.label34.Tag = "3";
            this.label34.Text = ".3";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label35.Location = new System.Drawing.Point(261, 134);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(61, 20);
            this.label35.TabIndex = 29;
            this.label35.Tag = "11";
            this.label35.Text = ".11";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label36.Location = new System.Drawing.Point(589, 134);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(61, 20);
            this.label36.TabIndex = 30;
            this.label36.Tag = "15";
            this.label36.Text = ".15";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PrimDebugControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.lbTitle);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "PrimDebugControl";
            this.Size = new System.Drawing.Size(1133, 578);
            //this.Load += new System.EventHandler(this.PrimDebugControl_Load);
            this.groupBox.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tPageIO.ResumeLayout(false);
            this.grpDo.ResumeLayout(false);
            this.grpDi.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.TextBox tBoxLESIName;
        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.Button btnStop1;
        private System.Windows.Forms.Button btnRun1;
        private System.Windows.Forms.TextBox tBoxConnState;
        private System.Windows.Forms.TextBox tBoxRunState;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ComboBox CardIDcomboB;
        private System.Windows.Forms.ComboBox comboBoxCard;
        private System.Windows.Forms.ComboBox cmbSelectAxis;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tPageIO;
        private System.Windows.Forms.GroupBox grpDo;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.GroupBox grpDi;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label lbTitle;
        private System.Windows.Forms.Timer tmrUpdateUI;
        private System.Windows.Forms.Button btnInit;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label194;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
    }
}
