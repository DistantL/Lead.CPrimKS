﻿namespace Lead.CPrim.PrimADLink_IO
{
    partial class PrimConfigControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbTitle = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.cmbCardSystemId = new System.Windows.Forms.ComboBox();
            this.cmbCardType = new System.Windows.Forms.ComboBox();
            this.btnStop1 = new System.Windows.Forms.Button();
            this.btnRun1 = new System.Windows.Forms.Button();
            this.btnInit = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tPageIO = new System.Windows.Forms.TabPage();
            this.grpDo1 = new System.Windows.Forms.GroupBox();
            this.lbDo129 = new System.Windows.Forms.Label();
            this.lbDo128 = new System.Windows.Forms.Label();
            this.lbDo126 = new System.Windows.Forms.Label();
            this.lbDo125 = new System.Windows.Forms.Label();
            this.lbDo124 = new System.Windows.Forms.Label();
            this.lbDo130 = new System.Windows.Forms.Label();
            this.lbDo127 = new System.Windows.Forms.Label();
            this.lbDo131 = new System.Windows.Forms.Label();
            this.lbDo14 = new System.Windows.Forms.Label();
            this.lbDo15 = new System.Windows.Forms.Label();
            this.lbDo16 = new System.Windows.Forms.Label();
            this.lbDo17 = new System.Windows.Forms.Label();
            this.lbDo10 = new System.Windows.Forms.Label();
            this.lbDo121 = new System.Windows.Forms.Label();
            this.lbDo113 = new System.Windows.Forms.Label();
            this.lbDo120 = new System.Windows.Forms.Label();
            this.lbDo112 = new System.Windows.Forms.Label();
            this.lbDo118 = new System.Windows.Forms.Label();
            this.lbDo110 = new System.Windows.Forms.Label();
            this.lbDo11 = new System.Windows.Forms.Label();
            this.lbDo117 = new System.Windows.Forms.Label();
            this.lbDo19 = new System.Windows.Forms.Label();
            this.lbDo116 = new System.Windows.Forms.Label();
            this.lbDo18 = new System.Windows.Forms.Label();
            this.lbDo12 = new System.Windows.Forms.Label();
            this.lbDo122 = new System.Windows.Forms.Label();
            this.lbDo114 = new System.Windows.Forms.Label();
            this.lbDo119 = new System.Windows.Forms.Label();
            this.lbDo13 = new System.Windows.Forms.Label();
            this.lbDo123 = new System.Windows.Forms.Label();
            this.lbDo111 = new System.Windows.Forms.Label();
            this.lbDo115 = new System.Windows.Forms.Label();
            this.grpDo = new System.Windows.Forms.GroupBox();
            this.lbDo029 = new System.Windows.Forms.Label();
            this.lbDo028 = new System.Windows.Forms.Label();
            this.lbDo026 = new System.Windows.Forms.Label();
            this.lbDo025 = new System.Windows.Forms.Label();
            this.lbDo024 = new System.Windows.Forms.Label();
            this.lbDo030 = new System.Windows.Forms.Label();
            this.lbDo027 = new System.Windows.Forms.Label();
            this.lbDo031 = new System.Windows.Forms.Label();
            this.lbDo04 = new System.Windows.Forms.Label();
            this.lbDo05 = new System.Windows.Forms.Label();
            this.lbDo06 = new System.Windows.Forms.Label();
            this.lbDo07 = new System.Windows.Forms.Label();
            this.lbDo00 = new System.Windows.Forms.Label();
            this.lbDo021 = new System.Windows.Forms.Label();
            this.lbDo013 = new System.Windows.Forms.Label();
            this.lbDo020 = new System.Windows.Forms.Label();
            this.lbDo012 = new System.Windows.Forms.Label();
            this.lbDo018 = new System.Windows.Forms.Label();
            this.lbDo010 = new System.Windows.Forms.Label();
            this.lbDo01 = new System.Windows.Forms.Label();
            this.lbDo017 = new System.Windows.Forms.Label();
            this.lbDo09 = new System.Windows.Forms.Label();
            this.lbDo016 = new System.Windows.Forms.Label();
            this.lbDo08 = new System.Windows.Forms.Label();
            this.lbDo02 = new System.Windows.Forms.Label();
            this.lbDo022 = new System.Windows.Forms.Label();
            this.lbDo014 = new System.Windows.Forms.Label();
            this.lbDo019 = new System.Windows.Forms.Label();
            this.lbDo03 = new System.Windows.Forms.Label();
            this.lbDo023 = new System.Windows.Forms.Label();
            this.lbDo011 = new System.Windows.Forms.Label();
            this.lbDo015 = new System.Windows.Forms.Label();
            this.grpDi1 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.grpDi = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.tmrUpdateUI = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tBoxConnState = new System.Windows.Forms.TextBox();
            this.tBoxRunState = new System.Windows.Forms.TextBox();
            this.label123 = new System.Windows.Forms.Label();
            this.tBoxADLinkName = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tPageIO.SuspendLayout();
            this.grpDo1.SuspendLayout();
            this.grpDo.SuspendLayout();
            this.grpDi1.SuspendLayout();
            this.grpDi.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbTitle
            // 
            this.lbTitle.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lbTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbTitle.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbTitle.Location = new System.Drawing.Point(0, 0);
            this.lbTitle.Name = "lbTitle";
            this.lbTitle.Size = new System.Drawing.Size(1073, 33);
            this.lbTitle.TabIndex = 0;
            this.lbTitle.Text = "ADLink Config";
            this.lbTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 33);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 571);
            this.splitter1.TabIndex = 1;
            this.splitter1.TabStop = false;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 33);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.label127);
            this.splitContainer1.Panel1.Controls.Add(this.cmbCardSystemId);
            this.splitContainer1.Panel1.Controls.Add(this.cmbCardType);
            this.splitContainer1.Panel1.Controls.Add(this.btnStop1);
            this.splitContainer1.Panel1.Controls.Add(this.btnRun1);
            this.splitContainer1.Panel1.Controls.Add(this.btnInit);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer1.Size = new System.Drawing.Size(1070, 571);
            this.splitContainer1.SplitterDistance = 83;
            this.splitContainer1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(198, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 17);
            this.label1.TabIndex = 108;
            this.label1.Text = "CardSystemId:";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(20, 51);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(67, 17);
            this.label127.TabIndex = 109;
            this.label127.Text = "CardType:";
            // 
            // cmbCardSystemId
            // 
            this.cmbCardSystemId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCardSystemId.FormattingEnabled = true;
            this.cmbCardSystemId.Location = new System.Drawing.Point(296, 48);
            this.cmbCardSystemId.Name = "cmbCardSystemId";
            this.cmbCardSystemId.Size = new System.Drawing.Size(60, 25);
            this.cmbCardSystemId.TabIndex = 106;
            this.cmbCardSystemId.SelectedIndexChanged += new System.EventHandler(this.cmbCardSystemId_SelectedIndexChanged);
            // 
            // cmbCardType
            // 
            this.cmbCardType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCardType.FormattingEnabled = true;
            this.cmbCardType.Items.AddRange(new object[] {
            "7230",
            "7432"});
            this.cmbCardType.Location = new System.Drawing.Point(96, 48);
            this.cmbCardType.Name = "cmbCardType";
            this.cmbCardType.Size = new System.Drawing.Size(89, 25);
            this.cmbCardType.TabIndex = 107;
            this.cmbCardType.SelectedIndexChanged += new System.EventHandler(this.cmbCardType_SelectedIndexChanged);
            // 
            // btnStop1
            // 
            this.btnStop1.BackColor = System.Drawing.Color.SandyBrown;
            this.btnStop1.Location = new System.Drawing.Point(993, 43);
            this.btnStop1.Name = "btnStop1";
            this.btnStop1.Size = new System.Drawing.Size(50, 32);
            this.btnStop1.TabIndex = 105;
            this.btnStop1.Text = "Stop";
            this.btnStop1.UseVisualStyleBackColor = false;
            this.btnStop1.Click += new System.EventHandler(this.BtnStop1_Click);
            // 
            // btnRun1
            // 
            this.btnRun1.BackColor = System.Drawing.Color.LightGreen;
            this.btnRun1.Location = new System.Drawing.Point(938, 43);
            this.btnRun1.Name = "btnRun1";
            this.btnRun1.Size = new System.Drawing.Size(50, 32);
            this.btnRun1.TabIndex = 105;
            this.btnRun1.Text = "Run";
            this.btnRun1.UseVisualStyleBackColor = false;
            this.btnRun1.Click += new System.EventHandler(this.BtnRun1_Click);
            // 
            // btnInit
            // 
            this.btnInit.BackColor = System.Drawing.Color.SkyBlue;
            this.btnInit.Location = new System.Drawing.Point(883, 43);
            this.btnInit.Name = "btnInit";
            this.btnInit.Size = new System.Drawing.Size(50, 32);
            this.btnInit.TabIndex = 105;
            this.btnInit.Text = "Init";
            this.btnInit.UseVisualStyleBackColor = false;
            this.btnInit.Click += new System.EventHandler(this.BtnInit_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tPageIO);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1070, 484);
            this.tabControl1.TabIndex = 0;
            // 
            // tPageIO
            // 
            this.tPageIO.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tPageIO.Controls.Add(this.grpDo1);
            this.tPageIO.Controls.Add(this.grpDo);
            this.tPageIO.Controls.Add(this.grpDi1);
            this.tPageIO.Controls.Add(this.grpDi);
            this.tPageIO.Location = new System.Drawing.Point(4, 26);
            this.tPageIO.Name = "tPageIO";
            this.tPageIO.Padding = new System.Windows.Forms.Padding(3);
            this.tPageIO.Size = new System.Drawing.Size(1062, 454);
            this.tPageIO.TabIndex = 2;
            this.tPageIO.Text = "IO";
            // 
            // grpDo1
            // 
            this.grpDo1.Controls.Add(this.lbDo129);
            this.grpDo1.Controls.Add(this.lbDo128);
            this.grpDo1.Controls.Add(this.lbDo126);
            this.grpDo1.Controls.Add(this.lbDo125);
            this.grpDo1.Controls.Add(this.lbDo124);
            this.grpDo1.Controls.Add(this.lbDo130);
            this.grpDo1.Controls.Add(this.lbDo127);
            this.grpDo1.Controls.Add(this.lbDo131);
            this.grpDo1.Controls.Add(this.lbDo14);
            this.grpDo1.Controls.Add(this.lbDo15);
            this.grpDo1.Controls.Add(this.lbDo16);
            this.grpDo1.Controls.Add(this.lbDo17);
            this.grpDo1.Controls.Add(this.lbDo10);
            this.grpDo1.Controls.Add(this.lbDo121);
            this.grpDo1.Controls.Add(this.lbDo113);
            this.grpDo1.Controls.Add(this.lbDo120);
            this.grpDo1.Controls.Add(this.lbDo112);
            this.grpDo1.Controls.Add(this.lbDo118);
            this.grpDo1.Controls.Add(this.lbDo110);
            this.grpDo1.Controls.Add(this.lbDo11);
            this.grpDo1.Controls.Add(this.lbDo117);
            this.grpDo1.Controls.Add(this.lbDo19);
            this.grpDo1.Controls.Add(this.lbDo116);
            this.grpDo1.Controls.Add(this.lbDo18);
            this.grpDo1.Controls.Add(this.lbDo12);
            this.grpDo1.Controls.Add(this.lbDo122);
            this.grpDo1.Controls.Add(this.lbDo114);
            this.grpDo1.Controls.Add(this.lbDo119);
            this.grpDo1.Controls.Add(this.lbDo13);
            this.grpDo1.Controls.Add(this.lbDo123);
            this.grpDo1.Controls.Add(this.lbDo111);
            this.grpDo1.Controls.Add(this.lbDo115);
            this.grpDo1.Font = new System.Drawing.Font("微软雅黑", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpDo1.Location = new System.Drawing.Point(9, 347);
            this.grpDo1.Name = "grpDo1";
            this.grpDo1.Size = new System.Drawing.Size(1050, 97);
            this.grpDo1.TabIndex = 19;
            this.grpDo1.TabStop = false;
            this.grpDo1.Tag = "MotionIo";
            this.grpDo1.Text = "DO（Port1）";
            // 
            // lbDo129
            // 
            this.lbDo129.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo129.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo129.Location = new System.Drawing.Point(858, 61);
            this.lbDo129.Name = "lbDo129";
            this.lbDo129.Size = new System.Drawing.Size(40, 19);
            this.lbDo129.TabIndex = 5;
            this.lbDo129.Tag = "29";
            this.lbDo129.Text = ".29";
            this.lbDo129.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo128
            // 
            this.lbDo128.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo128.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo128.Location = new System.Drawing.Point(793, 61);
            this.lbDo128.Name = "lbDo128";
            this.lbDo128.Size = new System.Drawing.Size(40, 19);
            this.lbDo128.TabIndex = 6;
            this.lbDo128.Tag = "28";
            this.lbDo128.Text = ".28";
            this.lbDo128.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo126
            // 
            this.lbDo126.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo126.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo126.Location = new System.Drawing.Point(663, 61);
            this.lbDo126.Name = "lbDo126";
            this.lbDo126.Size = new System.Drawing.Size(40, 19);
            this.lbDo126.TabIndex = 7;
            this.lbDo126.Tag = "26";
            this.lbDo126.Text = ".26";
            this.lbDo126.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo125
            // 
            this.lbDo125.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo125.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo125.Location = new System.Drawing.Point(598, 61);
            this.lbDo125.Name = "lbDo125";
            this.lbDo125.Size = new System.Drawing.Size(40, 19);
            this.lbDo125.TabIndex = 8;
            this.lbDo125.Tag = "25";
            this.lbDo125.Text = ".25";
            this.lbDo125.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo124
            // 
            this.lbDo124.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo124.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo124.Location = new System.Drawing.Point(533, 61);
            this.lbDo124.Name = "lbDo124";
            this.lbDo124.Size = new System.Drawing.Size(40, 19);
            this.lbDo124.TabIndex = 9;
            this.lbDo124.Tag = "24";
            this.lbDo124.Text = ".24";
            this.lbDo124.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo130
            // 
            this.lbDo130.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo130.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo130.Location = new System.Drawing.Point(923, 61);
            this.lbDo130.Name = "lbDo130";
            this.lbDo130.Size = new System.Drawing.Size(40, 19);
            this.lbDo130.TabIndex = 10;
            this.lbDo130.Tag = "30";
            this.lbDo130.Text = ".30";
            this.lbDo130.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo127
            // 
            this.lbDo127.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo127.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo127.Location = new System.Drawing.Point(728, 61);
            this.lbDo127.Name = "lbDo127";
            this.lbDo127.Size = new System.Drawing.Size(40, 19);
            this.lbDo127.TabIndex = 11;
            this.lbDo127.Tag = "27";
            this.lbDo127.Text = ".27";
            this.lbDo127.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo131
            // 
            this.lbDo131.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo131.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo131.Location = new System.Drawing.Point(988, 61);
            this.lbDo131.Name = "lbDo131";
            this.lbDo131.Size = new System.Drawing.Size(40, 19);
            this.lbDo131.TabIndex = 12;
            this.lbDo131.Tag = "31";
            this.lbDo131.Text = ".31";
            this.lbDo131.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo14
            // 
            this.lbDo14.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo14.Location = new System.Drawing.Point(273, 27);
            this.lbDo14.Name = "lbDo14";
            this.lbDo14.Size = new System.Drawing.Size(40, 19);
            this.lbDo14.TabIndex = 1;
            this.lbDo14.Tag = "4";
            this.lbDo14.Text = ".4";
            this.lbDo14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo15
            // 
            this.lbDo15.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo15.Location = new System.Drawing.Point(338, 27);
            this.lbDo15.Name = "lbDo15";
            this.lbDo15.Size = new System.Drawing.Size(40, 19);
            this.lbDo15.TabIndex = 2;
            this.lbDo15.Tag = "5";
            this.lbDo15.Text = ".5";
            this.lbDo15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo16
            // 
            this.lbDo16.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo16.Location = new System.Drawing.Point(403, 27);
            this.lbDo16.Name = "lbDo16";
            this.lbDo16.Size = new System.Drawing.Size(40, 19);
            this.lbDo16.TabIndex = 3;
            this.lbDo16.Tag = "6";
            this.lbDo16.Text = ".6";
            this.lbDo16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo17
            // 
            this.lbDo17.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo17.Location = new System.Drawing.Point(468, 27);
            this.lbDo17.Name = "lbDo17";
            this.lbDo17.Size = new System.Drawing.Size(40, 19);
            this.lbDo17.TabIndex = 4;
            this.lbDo17.Tag = "7";
            this.lbDo17.Text = ".7";
            this.lbDo17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo10
            // 
            this.lbDo10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo10.Location = new System.Drawing.Point(13, 27);
            this.lbDo10.Name = "lbDo10";
            this.lbDo10.Size = new System.Drawing.Size(40, 19);
            this.lbDo10.TabIndex = 0;
            this.lbDo10.Tag = "0";
            this.lbDo10.Text = ".0";
            this.lbDo10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo121
            // 
            this.lbDo121.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo121.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo121.Location = new System.Drawing.Point(338, 61);
            this.lbDo121.Name = "lbDo121";
            this.lbDo121.Size = new System.Drawing.Size(40, 19);
            this.lbDo121.TabIndex = 0;
            this.lbDo121.Tag = "21";
            this.lbDo121.Text = ".21";
            this.lbDo121.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo113
            // 
            this.lbDo113.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo113.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo113.Location = new System.Drawing.Point(858, 27);
            this.lbDo113.Name = "lbDo113";
            this.lbDo113.Size = new System.Drawing.Size(40, 19);
            this.lbDo113.TabIndex = 0;
            this.lbDo113.Tag = "13";
            this.lbDo113.Text = ".13";
            this.lbDo113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo120
            // 
            this.lbDo120.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo120.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo120.Location = new System.Drawing.Point(273, 61);
            this.lbDo120.Name = "lbDo120";
            this.lbDo120.Size = new System.Drawing.Size(40, 19);
            this.lbDo120.TabIndex = 0;
            this.lbDo120.Tag = "20";
            this.lbDo120.Text = ".20";
            this.lbDo120.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo112
            // 
            this.lbDo112.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo112.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo112.Location = new System.Drawing.Point(793, 27);
            this.lbDo112.Name = "lbDo112";
            this.lbDo112.Size = new System.Drawing.Size(40, 19);
            this.lbDo112.TabIndex = 0;
            this.lbDo112.Tag = "12";
            this.lbDo112.Text = ".12";
            this.lbDo112.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo118
            // 
            this.lbDo118.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo118.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo118.Location = new System.Drawing.Point(143, 61);
            this.lbDo118.Name = "lbDo118";
            this.lbDo118.Size = new System.Drawing.Size(40, 19);
            this.lbDo118.TabIndex = 0;
            this.lbDo118.Tag = "18";
            this.lbDo118.Text = ".18";
            this.lbDo118.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo110
            // 
            this.lbDo110.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo110.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo110.Location = new System.Drawing.Point(663, 27);
            this.lbDo110.Name = "lbDo110";
            this.lbDo110.Size = new System.Drawing.Size(40, 19);
            this.lbDo110.TabIndex = 0;
            this.lbDo110.Tag = "10";
            this.lbDo110.Text = ".10";
            this.lbDo110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo11
            // 
            this.lbDo11.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo11.Location = new System.Drawing.Point(78, 27);
            this.lbDo11.Name = "lbDo11";
            this.lbDo11.Size = new System.Drawing.Size(40, 19);
            this.lbDo11.TabIndex = 0;
            this.lbDo11.Tag = "1";
            this.lbDo11.Text = ".1";
            this.lbDo11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo117
            // 
            this.lbDo117.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo117.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo117.Location = new System.Drawing.Point(78, 61);
            this.lbDo117.Name = "lbDo117";
            this.lbDo117.Size = new System.Drawing.Size(40, 19);
            this.lbDo117.TabIndex = 0;
            this.lbDo117.Tag = "17";
            this.lbDo117.Text = ".17";
            this.lbDo117.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo19
            // 
            this.lbDo19.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo19.Location = new System.Drawing.Point(598, 27);
            this.lbDo19.Name = "lbDo19";
            this.lbDo19.Size = new System.Drawing.Size(40, 19);
            this.lbDo19.TabIndex = 0;
            this.lbDo19.Tag = "9";
            this.lbDo19.Text = ".9";
            this.lbDo19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo116
            // 
            this.lbDo116.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo116.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo116.Location = new System.Drawing.Point(13, 61);
            this.lbDo116.Name = "lbDo116";
            this.lbDo116.Size = new System.Drawing.Size(40, 19);
            this.lbDo116.TabIndex = 0;
            this.lbDo116.Tag = "16";
            this.lbDo116.Text = ".16";
            this.lbDo116.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo18
            // 
            this.lbDo18.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo18.Location = new System.Drawing.Point(533, 27);
            this.lbDo18.Name = "lbDo18";
            this.lbDo18.Size = new System.Drawing.Size(40, 19);
            this.lbDo18.TabIndex = 0;
            this.lbDo18.Tag = "8";
            this.lbDo18.Text = ".8";
            this.lbDo18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo12
            // 
            this.lbDo12.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo12.Location = new System.Drawing.Point(143, 27);
            this.lbDo12.Name = "lbDo12";
            this.lbDo12.Size = new System.Drawing.Size(40, 19);
            this.lbDo12.TabIndex = 0;
            this.lbDo12.Tag = "2";
            this.lbDo12.Text = ".2";
            this.lbDo12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo122
            // 
            this.lbDo122.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo122.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo122.Location = new System.Drawing.Point(403, 61);
            this.lbDo122.Name = "lbDo122";
            this.lbDo122.Size = new System.Drawing.Size(40, 19);
            this.lbDo122.TabIndex = 0;
            this.lbDo122.Tag = "22";
            this.lbDo122.Text = ".22";
            this.lbDo122.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo114
            // 
            this.lbDo114.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo114.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo114.Location = new System.Drawing.Point(923, 27);
            this.lbDo114.Name = "lbDo114";
            this.lbDo114.Size = new System.Drawing.Size(40, 19);
            this.lbDo114.TabIndex = 0;
            this.lbDo114.Tag = "14";
            this.lbDo114.Text = ".14";
            this.lbDo114.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo119
            // 
            this.lbDo119.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo119.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo119.Location = new System.Drawing.Point(208, 61);
            this.lbDo119.Name = "lbDo119";
            this.lbDo119.Size = new System.Drawing.Size(40, 19);
            this.lbDo119.TabIndex = 0;
            this.lbDo119.Tag = "19";
            this.lbDo119.Text = ".19";
            this.lbDo119.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo13
            // 
            this.lbDo13.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo13.Location = new System.Drawing.Point(208, 27);
            this.lbDo13.Name = "lbDo13";
            this.lbDo13.Size = new System.Drawing.Size(40, 19);
            this.lbDo13.TabIndex = 0;
            this.lbDo13.Tag = "3";
            this.lbDo13.Text = ".3";
            this.lbDo13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo123
            // 
            this.lbDo123.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo123.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo123.Location = new System.Drawing.Point(468, 61);
            this.lbDo123.Name = "lbDo123";
            this.lbDo123.Size = new System.Drawing.Size(40, 19);
            this.lbDo123.TabIndex = 0;
            this.lbDo123.Tag = "23";
            this.lbDo123.Text = ".23";
            this.lbDo123.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo111
            // 
            this.lbDo111.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo111.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo111.Location = new System.Drawing.Point(728, 27);
            this.lbDo111.Name = "lbDo111";
            this.lbDo111.Size = new System.Drawing.Size(40, 19);
            this.lbDo111.TabIndex = 0;
            this.lbDo111.Tag = "11";
            this.lbDo111.Text = ".11";
            this.lbDo111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo115
            // 
            this.lbDo115.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo115.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo115.Location = new System.Drawing.Point(988, 27);
            this.lbDo115.Name = "lbDo115";
            this.lbDo115.Size = new System.Drawing.Size(40, 19);
            this.lbDo115.TabIndex = 0;
            this.lbDo115.Tag = "15";
            this.lbDo115.Text = ".15";
            this.lbDo115.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grpDo
            // 
            this.grpDo.Controls.Add(this.lbDo029);
            this.grpDo.Controls.Add(this.lbDo028);
            this.grpDo.Controls.Add(this.lbDo026);
            this.grpDo.Controls.Add(this.lbDo025);
            this.grpDo.Controls.Add(this.lbDo024);
            this.grpDo.Controls.Add(this.lbDo030);
            this.grpDo.Controls.Add(this.lbDo027);
            this.grpDo.Controls.Add(this.lbDo031);
            this.grpDo.Controls.Add(this.lbDo04);
            this.grpDo.Controls.Add(this.lbDo05);
            this.grpDo.Controls.Add(this.lbDo06);
            this.grpDo.Controls.Add(this.lbDo07);
            this.grpDo.Controls.Add(this.lbDo00);
            this.grpDo.Controls.Add(this.lbDo021);
            this.grpDo.Controls.Add(this.lbDo013);
            this.grpDo.Controls.Add(this.lbDo020);
            this.grpDo.Controls.Add(this.lbDo012);
            this.grpDo.Controls.Add(this.lbDo018);
            this.grpDo.Controls.Add(this.lbDo010);
            this.grpDo.Controls.Add(this.lbDo01);
            this.grpDo.Controls.Add(this.lbDo017);
            this.grpDo.Controls.Add(this.lbDo09);
            this.grpDo.Controls.Add(this.lbDo016);
            this.grpDo.Controls.Add(this.lbDo08);
            this.grpDo.Controls.Add(this.lbDo02);
            this.grpDo.Controls.Add(this.lbDo022);
            this.grpDo.Controls.Add(this.lbDo014);
            this.grpDo.Controls.Add(this.lbDo019);
            this.grpDo.Controls.Add(this.lbDo03);
            this.grpDo.Controls.Add(this.lbDo023);
            this.grpDo.Controls.Add(this.lbDo011);
            this.grpDo.Controls.Add(this.lbDo015);
            this.grpDo.Font = new System.Drawing.Font("微软雅黑", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpDo.Location = new System.Drawing.Point(9, 234);
            this.grpDo.Name = "grpDo";
            this.grpDo.Size = new System.Drawing.Size(1050, 97);
            this.grpDo.TabIndex = 18;
            this.grpDo.TabStop = false;
            this.grpDo.Tag = "MotionIo";
            this.grpDo.Text = "DO（Port0）";
            // 
            // lbDo029
            // 
            this.lbDo029.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo029.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo029.Location = new System.Drawing.Point(858, 61);
            this.lbDo029.Name = "lbDo029";
            this.lbDo029.Size = new System.Drawing.Size(40, 19);
            this.lbDo029.TabIndex = 5;
            this.lbDo029.Tag = "29";
            this.lbDo029.Text = ".29";
            this.lbDo029.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo028
            // 
            this.lbDo028.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo028.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo028.Location = new System.Drawing.Point(793, 61);
            this.lbDo028.Name = "lbDo028";
            this.lbDo028.Size = new System.Drawing.Size(40, 19);
            this.lbDo028.TabIndex = 6;
            this.lbDo028.Tag = "28";
            this.lbDo028.Text = ".28";
            this.lbDo028.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo026
            // 
            this.lbDo026.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo026.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo026.Location = new System.Drawing.Point(663, 61);
            this.lbDo026.Name = "lbDo026";
            this.lbDo026.Size = new System.Drawing.Size(40, 19);
            this.lbDo026.TabIndex = 7;
            this.lbDo026.Tag = "26";
            this.lbDo026.Text = ".26";
            this.lbDo026.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo025
            // 
            this.lbDo025.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo025.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo025.Location = new System.Drawing.Point(598, 61);
            this.lbDo025.Name = "lbDo025";
            this.lbDo025.Size = new System.Drawing.Size(40, 19);
            this.lbDo025.TabIndex = 8;
            this.lbDo025.Tag = "25";
            this.lbDo025.Text = ".25";
            this.lbDo025.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo024
            // 
            this.lbDo024.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo024.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo024.Location = new System.Drawing.Point(533, 61);
            this.lbDo024.Name = "lbDo024";
            this.lbDo024.Size = new System.Drawing.Size(40, 19);
            this.lbDo024.TabIndex = 9;
            this.lbDo024.Tag = "24";
            this.lbDo024.Text = ".24";
            this.lbDo024.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo030
            // 
            this.lbDo030.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo030.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo030.Location = new System.Drawing.Point(923, 61);
            this.lbDo030.Name = "lbDo030";
            this.lbDo030.Size = new System.Drawing.Size(40, 19);
            this.lbDo030.TabIndex = 10;
            this.lbDo030.Tag = "30";
            this.lbDo030.Text = ".30";
            this.lbDo030.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo027
            // 
            this.lbDo027.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo027.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo027.Location = new System.Drawing.Point(728, 61);
            this.lbDo027.Name = "lbDo027";
            this.lbDo027.Size = new System.Drawing.Size(40, 19);
            this.lbDo027.TabIndex = 11;
            this.lbDo027.Tag = "27";
            this.lbDo027.Text = ".27";
            this.lbDo027.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo031
            // 
            this.lbDo031.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo031.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo031.Location = new System.Drawing.Point(988, 61);
            this.lbDo031.Name = "lbDo031";
            this.lbDo031.Size = new System.Drawing.Size(40, 19);
            this.lbDo031.TabIndex = 12;
            this.lbDo031.Tag = "31";
            this.lbDo031.Text = ".31";
            this.lbDo031.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo04
            // 
            this.lbDo04.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo04.Location = new System.Drawing.Point(273, 27);
            this.lbDo04.Name = "lbDo04";
            this.lbDo04.Size = new System.Drawing.Size(40, 19);
            this.lbDo04.TabIndex = 1;
            this.lbDo04.Tag = "4";
            this.lbDo04.Text = ".4";
            this.lbDo04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo05
            // 
            this.lbDo05.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo05.Location = new System.Drawing.Point(338, 27);
            this.lbDo05.Name = "lbDo05";
            this.lbDo05.Size = new System.Drawing.Size(40, 19);
            this.lbDo05.TabIndex = 2;
            this.lbDo05.Tag = "5";
            this.lbDo05.Text = ".5";
            this.lbDo05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo06
            // 
            this.lbDo06.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo06.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo06.Location = new System.Drawing.Point(403, 27);
            this.lbDo06.Name = "lbDo06";
            this.lbDo06.Size = new System.Drawing.Size(40, 19);
            this.lbDo06.TabIndex = 3;
            this.lbDo06.Tag = "6";
            this.lbDo06.Text = ".6";
            this.lbDo06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo07
            // 
            this.lbDo07.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo07.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo07.Location = new System.Drawing.Point(468, 27);
            this.lbDo07.Name = "lbDo07";
            this.lbDo07.Size = new System.Drawing.Size(40, 19);
            this.lbDo07.TabIndex = 4;
            this.lbDo07.Tag = "7";
            this.lbDo07.Text = ".7";
            this.lbDo07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo00
            // 
            this.lbDo00.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo00.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo00.Location = new System.Drawing.Point(13, 27);
            this.lbDo00.Name = "lbDo00";
            this.lbDo00.Size = new System.Drawing.Size(40, 19);
            this.lbDo00.TabIndex = 0;
            this.lbDo00.Tag = "0";
            this.lbDo00.Text = ".0";
            this.lbDo00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo021
            // 
            this.lbDo021.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo021.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo021.Location = new System.Drawing.Point(338, 61);
            this.lbDo021.Name = "lbDo021";
            this.lbDo021.Size = new System.Drawing.Size(40, 19);
            this.lbDo021.TabIndex = 0;
            this.lbDo021.Tag = "21";
            this.lbDo021.Text = ".21";
            this.lbDo021.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo013
            // 
            this.lbDo013.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo013.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo013.Location = new System.Drawing.Point(858, 27);
            this.lbDo013.Name = "lbDo013";
            this.lbDo013.Size = new System.Drawing.Size(40, 19);
            this.lbDo013.TabIndex = 0;
            this.lbDo013.Tag = "13";
            this.lbDo013.Text = ".13";
            this.lbDo013.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo020
            // 
            this.lbDo020.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo020.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo020.Location = new System.Drawing.Point(273, 61);
            this.lbDo020.Name = "lbDo020";
            this.lbDo020.Size = new System.Drawing.Size(40, 19);
            this.lbDo020.TabIndex = 0;
            this.lbDo020.Tag = "20";
            this.lbDo020.Text = ".20";
            this.lbDo020.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo012
            // 
            this.lbDo012.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo012.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo012.Location = new System.Drawing.Point(793, 27);
            this.lbDo012.Name = "lbDo012";
            this.lbDo012.Size = new System.Drawing.Size(40, 19);
            this.lbDo012.TabIndex = 0;
            this.lbDo012.Tag = "12";
            this.lbDo012.Text = ".12";
            this.lbDo012.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo018
            // 
            this.lbDo018.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo018.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo018.Location = new System.Drawing.Point(143, 61);
            this.lbDo018.Name = "lbDo018";
            this.lbDo018.Size = new System.Drawing.Size(40, 19);
            this.lbDo018.TabIndex = 0;
            this.lbDo018.Tag = "18";
            this.lbDo018.Text = ".18";
            this.lbDo018.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo010
            // 
            this.lbDo010.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo010.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo010.Location = new System.Drawing.Point(663, 27);
            this.lbDo010.Name = "lbDo010";
            this.lbDo010.Size = new System.Drawing.Size(40, 19);
            this.lbDo010.TabIndex = 0;
            this.lbDo010.Tag = "10";
            this.lbDo010.Text = ".10";
            this.lbDo010.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo01
            // 
            this.lbDo01.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo01.Location = new System.Drawing.Point(78, 27);
            this.lbDo01.Name = "lbDo01";
            this.lbDo01.Size = new System.Drawing.Size(40, 19);
            this.lbDo01.TabIndex = 0;
            this.lbDo01.Tag = "1";
            this.lbDo01.Text = ".1";
            this.lbDo01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo017
            // 
            this.lbDo017.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo017.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo017.Location = new System.Drawing.Point(78, 61);
            this.lbDo017.Name = "lbDo017";
            this.lbDo017.Size = new System.Drawing.Size(40, 19);
            this.lbDo017.TabIndex = 0;
            this.lbDo017.Tag = "17";
            this.lbDo017.Text = ".17";
            this.lbDo017.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo09
            // 
            this.lbDo09.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo09.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo09.Location = new System.Drawing.Point(598, 27);
            this.lbDo09.Name = "lbDo09";
            this.lbDo09.Size = new System.Drawing.Size(40, 19);
            this.lbDo09.TabIndex = 0;
            this.lbDo09.Tag = "9";
            this.lbDo09.Text = ".9";
            this.lbDo09.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo016
            // 
            this.lbDo016.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo016.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo016.Location = new System.Drawing.Point(13, 61);
            this.lbDo016.Name = "lbDo016";
            this.lbDo016.Size = new System.Drawing.Size(40, 19);
            this.lbDo016.TabIndex = 0;
            this.lbDo016.Tag = "16";
            this.lbDo016.Text = ".16";
            this.lbDo016.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo08
            // 
            this.lbDo08.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo08.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo08.Location = new System.Drawing.Point(533, 27);
            this.lbDo08.Name = "lbDo08";
            this.lbDo08.Size = new System.Drawing.Size(40, 19);
            this.lbDo08.TabIndex = 0;
            this.lbDo08.Tag = "8";
            this.lbDo08.Text = ".8";
            this.lbDo08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo02
            // 
            this.lbDo02.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo02.Location = new System.Drawing.Point(143, 27);
            this.lbDo02.Name = "lbDo02";
            this.lbDo02.Size = new System.Drawing.Size(40, 19);
            this.lbDo02.TabIndex = 0;
            this.lbDo02.Tag = "2";
            this.lbDo02.Text = ".2";
            this.lbDo02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo022
            // 
            this.lbDo022.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo022.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo022.Location = new System.Drawing.Point(403, 61);
            this.lbDo022.Name = "lbDo022";
            this.lbDo022.Size = new System.Drawing.Size(40, 19);
            this.lbDo022.TabIndex = 0;
            this.lbDo022.Tag = "22";
            this.lbDo022.Text = ".22";
            this.lbDo022.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo014
            // 
            this.lbDo014.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo014.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo014.Location = new System.Drawing.Point(923, 27);
            this.lbDo014.Name = "lbDo014";
            this.lbDo014.Size = new System.Drawing.Size(40, 19);
            this.lbDo014.TabIndex = 0;
            this.lbDo014.Tag = "14";
            this.lbDo014.Text = ".14";
            this.lbDo014.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo019
            // 
            this.lbDo019.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo019.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo019.Location = new System.Drawing.Point(208, 61);
            this.lbDo019.Name = "lbDo019";
            this.lbDo019.Size = new System.Drawing.Size(40, 19);
            this.lbDo019.TabIndex = 0;
            this.lbDo019.Tag = "19";
            this.lbDo019.Text = ".19";
            this.lbDo019.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo03
            // 
            this.lbDo03.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo03.Location = new System.Drawing.Point(208, 27);
            this.lbDo03.Name = "lbDo03";
            this.lbDo03.Size = new System.Drawing.Size(40, 19);
            this.lbDo03.TabIndex = 0;
            this.lbDo03.Tag = "3";
            this.lbDo03.Text = ".3";
            this.lbDo03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo023
            // 
            this.lbDo023.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo023.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo023.Location = new System.Drawing.Point(468, 61);
            this.lbDo023.Name = "lbDo023";
            this.lbDo023.Size = new System.Drawing.Size(40, 19);
            this.lbDo023.TabIndex = 0;
            this.lbDo023.Tag = "23";
            this.lbDo023.Text = ".23";
            this.lbDo023.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo011
            // 
            this.lbDo011.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo011.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo011.Location = new System.Drawing.Point(728, 27);
            this.lbDo011.Name = "lbDo011";
            this.lbDo011.Size = new System.Drawing.Size(40, 19);
            this.lbDo011.TabIndex = 0;
            this.lbDo011.Tag = "11";
            this.lbDo011.Text = ".11";
            this.lbDo011.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDo015
            // 
            this.lbDo015.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDo015.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDo015.Location = new System.Drawing.Point(988, 27);
            this.lbDo015.Name = "lbDo015";
            this.lbDo015.Size = new System.Drawing.Size(40, 19);
            this.lbDo015.TabIndex = 0;
            this.lbDo015.Tag = "15";
            this.lbDo015.Text = ".15";
            this.lbDo015.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grpDi1
            // 
            this.grpDi1.Controls.Add(this.label10);
            this.grpDi1.Controls.Add(this.label11);
            this.grpDi1.Controls.Add(this.label12);
            this.grpDi1.Controls.Add(this.label13);
            this.grpDi1.Controls.Add(this.label14);
            this.grpDi1.Controls.Add(this.label15);
            this.grpDi1.Controls.Add(this.label16);
            this.grpDi1.Controls.Add(this.label17);
            this.grpDi1.Controls.Add(this.label18);
            this.grpDi1.Controls.Add(this.label19);
            this.grpDi1.Controls.Add(this.label20);
            this.grpDi1.Controls.Add(this.label21);
            this.grpDi1.Controls.Add(this.label22);
            this.grpDi1.Controls.Add(this.label23);
            this.grpDi1.Controls.Add(this.label24);
            this.grpDi1.Controls.Add(this.label25);
            this.grpDi1.Controls.Add(this.label26);
            this.grpDi1.Controls.Add(this.label27);
            this.grpDi1.Controls.Add(this.label28);
            this.grpDi1.Controls.Add(this.label29);
            this.grpDi1.Controls.Add(this.label30);
            this.grpDi1.Controls.Add(this.label31);
            this.grpDi1.Controls.Add(this.label32);
            this.grpDi1.Controls.Add(this.label33);
            this.grpDi1.Controls.Add(this.label34);
            this.grpDi1.Controls.Add(this.label35);
            this.grpDi1.Controls.Add(this.label36);
            this.grpDi1.Controls.Add(this.label37);
            this.grpDi1.Controls.Add(this.label38);
            this.grpDi1.Controls.Add(this.label39);
            this.grpDi1.Controls.Add(this.label40);
            this.grpDi1.Controls.Add(this.label41);
            this.grpDi1.Font = new System.Drawing.Font("微软雅黑", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpDi1.Location = new System.Drawing.Point(6, 119);
            this.grpDi1.Name = "grpDi1";
            this.grpDi1.Size = new System.Drawing.Size(1050, 97);
            this.grpDi1.TabIndex = 17;
            this.grpDi1.TabStop = false;
            this.grpDi1.Tag = "MotionIo";
            this.grpDi1.Text = "DI（Port1）";
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Location = new System.Drawing.Point(858, 61);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 19);
            this.label10.TabIndex = 5;
            this.label10.Tag = "29";
            this.label10.Text = ".29";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Location = new System.Drawing.Point(793, 61);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 19);
            this.label11.TabIndex = 6;
            this.label11.Tag = "28";
            this.label11.Text = ".28";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Location = new System.Drawing.Point(663, 61);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 19);
            this.label12.TabIndex = 7;
            this.label12.Tag = "26";
            this.label12.Text = ".26";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Location = new System.Drawing.Point(598, 61);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 19);
            this.label13.TabIndex = 8;
            this.label13.Tag = "25";
            this.label13.Text = ".25";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Location = new System.Drawing.Point(533, 61);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 19);
            this.label14.TabIndex = 9;
            this.label14.Tag = "24";
            this.label14.Text = ".24";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Location = new System.Drawing.Point(923, 61);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 19);
            this.label15.TabIndex = 10;
            this.label15.Tag = "30";
            this.label15.Text = ".30";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Location = new System.Drawing.Point(728, 61);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 19);
            this.label16.TabIndex = 11;
            this.label16.Tag = "27";
            this.label16.Text = ".27";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Location = new System.Drawing.Point(988, 61);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(40, 19);
            this.label17.TabIndex = 12;
            this.label17.Tag = "31";
            this.label17.Text = ".31";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Location = new System.Drawing.Point(273, 27);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(40, 19);
            this.label18.TabIndex = 1;
            this.label18.Tag = "4";
            this.label18.Text = ".4";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.Location = new System.Drawing.Point(338, 27);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(40, 19);
            this.label19.TabIndex = 2;
            this.label19.Tag = "5";
            this.label19.Text = ".5";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Location = new System.Drawing.Point(403, 27);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(40, 19);
            this.label20.TabIndex = 3;
            this.label20.Tag = "6";
            this.label20.Text = ".6";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.Location = new System.Drawing.Point(468, 27);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(40, 19);
            this.label21.TabIndex = 4;
            this.label21.Tag = "7";
            this.label21.Text = ".7";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Location = new System.Drawing.Point(13, 27);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(40, 19);
            this.label22.TabIndex = 0;
            this.label22.Tag = "0";
            this.label22.Text = ".0";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Location = new System.Drawing.Point(338, 61);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(40, 19);
            this.label23.TabIndex = 0;
            this.label23.Tag = "21";
            this.label23.Text = ".21";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Location = new System.Drawing.Point(858, 27);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(40, 19);
            this.label24.TabIndex = 0;
            this.label24.Tag = "13";
            this.label24.Text = ".13";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Location = new System.Drawing.Point(273, 61);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(40, 19);
            this.label25.TabIndex = 0;
            this.label25.Tag = "20";
            this.label25.Text = ".20";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.Location = new System.Drawing.Point(793, 27);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(40, 19);
            this.label26.TabIndex = 0;
            this.label26.Tag = "12";
            this.label26.Text = ".12";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label27.Location = new System.Drawing.Point(143, 61);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(40, 19);
            this.label27.TabIndex = 0;
            this.label27.Tag = "18";
            this.label27.Text = ".18";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label28.Location = new System.Drawing.Point(663, 27);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(40, 19);
            this.label28.TabIndex = 0;
            this.label28.Tag = "10";
            this.label28.Text = ".10";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label29.Location = new System.Drawing.Point(78, 27);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(40, 19);
            this.label29.TabIndex = 0;
            this.label29.Tag = "1";
            this.label29.Text = ".1";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label30.Location = new System.Drawing.Point(78, 61);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(40, 19);
            this.label30.TabIndex = 0;
            this.label30.Tag = "17";
            this.label30.Text = ".17";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.Location = new System.Drawing.Point(598, 27);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(40, 19);
            this.label31.TabIndex = 0;
            this.label31.Tag = "9";
            this.label31.Text = ".9";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label32.Location = new System.Drawing.Point(13, 61);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(40, 19);
            this.label32.TabIndex = 0;
            this.label32.Tag = "16";
            this.label32.Text = ".16";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label33.Location = new System.Drawing.Point(533, 27);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(40, 19);
            this.label33.TabIndex = 0;
            this.label33.Tag = "8";
            this.label33.Text = ".8";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label34.Location = new System.Drawing.Point(143, 27);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(40, 19);
            this.label34.TabIndex = 0;
            this.label34.Tag = "2";
            this.label34.Text = ".2";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label35.Location = new System.Drawing.Point(403, 61);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(40, 19);
            this.label35.TabIndex = 0;
            this.label35.Tag = "22";
            this.label35.Text = ".22";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label36.Location = new System.Drawing.Point(923, 27);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(40, 19);
            this.label36.TabIndex = 0;
            this.label36.Tag = "14";
            this.label36.Text = ".14";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label37.Location = new System.Drawing.Point(208, 61);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(40, 19);
            this.label37.TabIndex = 0;
            this.label37.Tag = "19";
            this.label37.Text = ".19";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label38.Location = new System.Drawing.Point(208, 27);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(40, 19);
            this.label38.TabIndex = 0;
            this.label38.Tag = "3";
            this.label38.Text = ".3";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label39.Location = new System.Drawing.Point(468, 61);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(40, 19);
            this.label39.TabIndex = 0;
            this.label39.Tag = "23";
            this.label39.Text = ".23";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label40.Location = new System.Drawing.Point(728, 27);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(40, 19);
            this.label40.TabIndex = 0;
            this.label40.Tag = "11";
            this.label40.Text = ".11";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label41.Location = new System.Drawing.Point(988, 27);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(40, 19);
            this.label41.TabIndex = 0;
            this.label41.Tag = "15";
            this.label41.Text = ".15";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grpDi
            // 
            this.grpDi.Controls.Add(this.label2);
            this.grpDi.Controls.Add(this.label3);
            this.grpDi.Controls.Add(this.label4);
            this.grpDi.Controls.Add(this.label5);
            this.grpDi.Controls.Add(this.label6);
            this.grpDi.Controls.Add(this.label7);
            this.grpDi.Controls.Add(this.label8);
            this.grpDi.Controls.Add(this.label9);
            this.grpDi.Controls.Add(this.label130);
            this.grpDi.Controls.Add(this.label132);
            this.grpDi.Controls.Add(this.label135);
            this.grpDi.Controls.Add(this.label137);
            this.grpDi.Controls.Add(this.label53);
            this.grpDi.Controls.Add(this.label67);
            this.grpDi.Controls.Add(this.label54);
            this.grpDi.Controls.Add(this.label66);
            this.grpDi.Controls.Add(this.label55);
            this.grpDi.Controls.Add(this.label62);
            this.grpDi.Controls.Add(this.label56);
            this.grpDi.Controls.Add(this.label57);
            this.grpDi.Controls.Add(this.label61);
            this.grpDi.Controls.Add(this.label58);
            this.grpDi.Controls.Add(this.label60);
            this.grpDi.Controls.Add(this.label59);
            this.grpDi.Controls.Add(this.label63);
            this.grpDi.Controls.Add(this.label64);
            this.grpDi.Controls.Add(this.label65);
            this.grpDi.Controls.Add(this.label72);
            this.grpDi.Controls.Add(this.label74);
            this.grpDi.Controls.Add(this.label75);
            this.grpDi.Controls.Add(this.label87);
            this.grpDi.Controls.Add(this.label94);
            this.grpDi.Font = new System.Drawing.Font("微软雅黑", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.grpDi.Location = new System.Drawing.Point(6, 6);
            this.grpDi.Name = "grpDi";
            this.grpDi.Size = new System.Drawing.Size(1050, 97);
            this.grpDi.TabIndex = 16;
            this.grpDi.TabStop = false;
            this.grpDi.Tag = "MotionIo";
            this.grpDi.Text = "DI（Port0）";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Location = new System.Drawing.Point(858, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 19);
            this.label2.TabIndex = 5;
            this.label2.Tag = "29";
            this.label2.Text = ".29";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Location = new System.Drawing.Point(793, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 19);
            this.label3.TabIndex = 6;
            this.label3.Tag = "28";
            this.label3.Text = ".28";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Location = new System.Drawing.Point(663, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 19);
            this.label4.TabIndex = 7;
            this.label4.Tag = "26";
            this.label4.Text = ".26";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Location = new System.Drawing.Point(598, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 19);
            this.label5.TabIndex = 8;
            this.label5.Tag = "25";
            this.label5.Text = ".25";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Location = new System.Drawing.Point(533, 61);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 19);
            this.label6.TabIndex = 9;
            this.label6.Tag = "24";
            this.label6.Text = ".24";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Location = new System.Drawing.Point(923, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 19);
            this.label7.TabIndex = 10;
            this.label7.Tag = "30";
            this.label7.Text = ".30";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Location = new System.Drawing.Point(728, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 19);
            this.label8.TabIndex = 11;
            this.label8.Tag = "27";
            this.label8.Text = ".27";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Location = new System.Drawing.Point(988, 61);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 19);
            this.label9.TabIndex = 12;
            this.label9.Tag = "31";
            this.label9.Text = ".31";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label130
            // 
            this.label130.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label130.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label130.Location = new System.Drawing.Point(273, 27);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(40, 19);
            this.label130.TabIndex = 1;
            this.label130.Tag = "4";
            this.label130.Text = ".4";
            this.label130.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label132
            // 
            this.label132.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label132.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label132.Location = new System.Drawing.Point(338, 27);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(40, 19);
            this.label132.TabIndex = 2;
            this.label132.Tag = "5";
            this.label132.Text = ".5";
            this.label132.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label135
            // 
            this.label135.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label135.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label135.Location = new System.Drawing.Point(403, 27);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(40, 19);
            this.label135.TabIndex = 3;
            this.label135.Tag = "6";
            this.label135.Text = ".6";
            this.label135.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label137
            // 
            this.label137.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label137.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label137.Location = new System.Drawing.Point(468, 27);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(40, 19);
            this.label137.TabIndex = 4;
            this.label137.Tag = "7";
            this.label137.Text = ".7";
            this.label137.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label53
            // 
            this.label53.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label53.Location = new System.Drawing.Point(13, 27);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(40, 19);
            this.label53.TabIndex = 0;
            this.label53.Tag = "0";
            this.label53.Text = ".0";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            this.label67.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label67.Location = new System.Drawing.Point(338, 61);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(40, 19);
            this.label67.TabIndex = 0;
            this.label67.Tag = "21";
            this.label67.Text = ".21";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label54.Location = new System.Drawing.Point(858, 27);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(40, 19);
            this.label54.TabIndex = 0;
            this.label54.Tag = "13";
            this.label54.Text = ".13";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label66.Location = new System.Drawing.Point(273, 61);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(40, 19);
            this.label66.TabIndex = 0;
            this.label66.Tag = "20";
            this.label66.Text = ".20";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label55.Location = new System.Drawing.Point(793, 27);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(40, 19);
            this.label55.TabIndex = 0;
            this.label55.Tag = "12";
            this.label55.Text = ".12";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label62.Location = new System.Drawing.Point(143, 61);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(40, 19);
            this.label62.TabIndex = 0;
            this.label62.Tag = "18";
            this.label62.Text = ".18";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label56.Location = new System.Drawing.Point(663, 27);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(40, 19);
            this.label56.TabIndex = 0;
            this.label56.Tag = "10";
            this.label56.Text = ".10";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label57.Location = new System.Drawing.Point(78, 27);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(40, 19);
            this.label57.TabIndex = 0;
            this.label57.Tag = "1";
            this.label57.Text = ".1";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label61
            // 
            this.label61.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label61.Location = new System.Drawing.Point(78, 61);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(40, 19);
            this.label61.TabIndex = 0;
            this.label61.Tag = "17";
            this.label61.Text = ".17";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label58.Location = new System.Drawing.Point(598, 27);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(40, 19);
            this.label58.TabIndex = 0;
            this.label58.Tag = "9";
            this.label58.Text = ".9";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label60.Location = new System.Drawing.Point(13, 61);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(40, 19);
            this.label60.TabIndex = 0;
            this.label60.Tag = "16";
            this.label60.Text = ".16";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label59.Location = new System.Drawing.Point(533, 27);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(40, 19);
            this.label59.TabIndex = 0;
            this.label59.Tag = "8";
            this.label59.Text = ".8";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label63
            // 
            this.label63.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label63.Location = new System.Drawing.Point(143, 27);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(40, 19);
            this.label63.TabIndex = 0;
            this.label63.Tag = "2";
            this.label63.Text = ".2";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label64
            // 
            this.label64.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label64.Location = new System.Drawing.Point(403, 61);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(40, 19);
            this.label64.TabIndex = 0;
            this.label64.Tag = "22";
            this.label64.Text = ".22";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label65
            // 
            this.label65.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label65.Location = new System.Drawing.Point(923, 27);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(40, 19);
            this.label65.TabIndex = 0;
            this.label65.Tag = "14";
            this.label65.Text = ".14";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label72
            // 
            this.label72.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label72.Location = new System.Drawing.Point(208, 61);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(40, 19);
            this.label72.TabIndex = 0;
            this.label72.Tag = "19";
            this.label72.Text = ".19";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label74
            // 
            this.label74.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label74.Location = new System.Drawing.Point(208, 27);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(40, 19);
            this.label74.TabIndex = 0;
            this.label74.Tag = "3";
            this.label74.Text = ".3";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label75
            // 
            this.label75.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label75.Location = new System.Drawing.Point(468, 61);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(40, 19);
            this.label75.TabIndex = 0;
            this.label75.Tag = "23";
            this.label75.Text = ".23";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label87
            // 
            this.label87.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label87.Location = new System.Drawing.Point(728, 27);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(40, 19);
            this.label87.TabIndex = 0;
            this.label87.Tag = "11";
            this.label87.Text = ".11";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label94
            // 
            this.label94.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label94.Location = new System.Drawing.Point(988, 27);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(40, 19);
            this.label94.TabIndex = 0;
            this.label94.Tag = "15";
            this.label94.Text = ".15";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tmrUpdateUI
            // 
            this.tmrUpdateUI.Interval = 50;
            this.tmrUpdateUI.Tick += new System.EventHandler(this.tmrUpdateUI_Tick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tBoxConnState);
            this.panel1.Controls.Add(this.tBoxRunState);
            this.panel1.Controls.Add(this.label123);
            this.panel1.Controls.Add(this.tBoxADLinkName);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 33);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1070, 33);
            this.panel1.TabIndex = 15;
            // 
            // tBoxConnState
            // 
            this.tBoxConnState.BackColor = System.Drawing.Color.Khaki;
            this.tBoxConnState.Dock = System.Windows.Forms.DockStyle.Right;
            this.tBoxConnState.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tBoxConnState.Location = new System.Drawing.Point(694, 0);
            this.tBoxConnState.Multiline = true;
            this.tBoxConnState.Name = "tBoxConnState";
            this.tBoxConnState.Size = new System.Drawing.Size(188, 33);
            this.tBoxConnState.TabIndex = 15;
            this.tBoxConnState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tBoxRunState
            // 
            this.tBoxRunState.BackColor = System.Drawing.Color.Khaki;
            this.tBoxRunState.Dock = System.Windows.Forms.DockStyle.Right;
            this.tBoxRunState.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tBoxRunState.Location = new System.Drawing.Point(882, 0);
            this.tBoxRunState.Multiline = true;
            this.tBoxRunState.Name = "tBoxRunState";
            this.tBoxRunState.Size = new System.Drawing.Size(188, 33);
            this.tBoxRunState.TabIndex = 14;
            this.tBoxRunState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label123
            // 
            this.label123.BackColor = System.Drawing.Color.SkyBlue;
            this.label123.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label123.Dock = System.Windows.Forms.DockStyle.Left;
            this.label123.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label123.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label123.Location = new System.Drawing.Point(0, 0);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(178, 33);
            this.label123.TabIndex = 12;
            this.label123.Text = "ADLinkName";
            this.label123.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tBoxADLinkName
            // 
            this.tBoxADLinkName.BackColor = System.Drawing.Color.OldLace;
            this.tBoxADLinkName.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tBoxADLinkName.Location = new System.Drawing.Point(180, 2);
            this.tBoxADLinkName.Multiline = true;
            this.tBoxADLinkName.Name = "tBoxADLinkName";
            this.tBoxADLinkName.Size = new System.Drawing.Size(188, 30);
            this.tBoxADLinkName.TabIndex = 13;
            this.tBoxADLinkName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PrimConfigControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.lbTitle);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "PrimConfigControl";
            this.Size = new System.Drawing.Size(1073, 604);
            this.Load += new System.EventHandler(this.PrimConfigControl_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tPageIO.ResumeLayout(false);
            this.grpDo1.ResumeLayout(false);
            this.grpDo.ResumeLayout(false);
            this.grpDi1.ResumeLayout(false);
            this.grpDi.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbTitle;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tPageIO;
        private System.Windows.Forms.GroupBox grpDi;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Timer tmrUpdateUI;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tBoxConnState;
        private System.Windows.Forms.TextBox tBoxRunState;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.TextBox tBoxADLinkName;
        private System.Windows.Forms.Button btnStop1;
        private System.Windows.Forms.Button btnRun1;
        private System.Windows.Forms.Button btnInit;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.GroupBox grpDo1;
        private System.Windows.Forms.Label lbDo129;
        private System.Windows.Forms.Label lbDo128;
        private System.Windows.Forms.Label lbDo126;
        private System.Windows.Forms.Label lbDo125;
        private System.Windows.Forms.Label lbDo124;
        private System.Windows.Forms.Label lbDo130;
        private System.Windows.Forms.Label lbDo127;
        private System.Windows.Forms.Label lbDo131;
        private System.Windows.Forms.Label lbDo14;
        private System.Windows.Forms.Label lbDo15;
        private System.Windows.Forms.Label lbDo16;
        private System.Windows.Forms.Label lbDo17;
        private System.Windows.Forms.Label lbDo10;
        private System.Windows.Forms.Label lbDo121;
        private System.Windows.Forms.Label lbDo113;
        private System.Windows.Forms.Label lbDo120;
        private System.Windows.Forms.Label lbDo112;
        private System.Windows.Forms.Label lbDo118;
        private System.Windows.Forms.Label lbDo110;
        private System.Windows.Forms.Label lbDo11;
        private System.Windows.Forms.Label lbDo117;
        private System.Windows.Forms.Label lbDo19;
        private System.Windows.Forms.Label lbDo116;
        private System.Windows.Forms.Label lbDo18;
        private System.Windows.Forms.Label lbDo12;
        private System.Windows.Forms.Label lbDo122;
        private System.Windows.Forms.Label lbDo114;
        private System.Windows.Forms.Label lbDo119;
        private System.Windows.Forms.Label lbDo13;
        private System.Windows.Forms.Label lbDo123;
        private System.Windows.Forms.Label lbDo111;
        private System.Windows.Forms.Label lbDo115;
        private System.Windows.Forms.GroupBox grpDo;
        private System.Windows.Forms.Label lbDo029;
        private System.Windows.Forms.Label lbDo028;
        private System.Windows.Forms.Label lbDo026;
        private System.Windows.Forms.Label lbDo025;
        private System.Windows.Forms.Label lbDo024;
        private System.Windows.Forms.Label lbDo030;
        private System.Windows.Forms.Label lbDo027;
        private System.Windows.Forms.Label lbDo031;
        private System.Windows.Forms.Label lbDo04;
        private System.Windows.Forms.Label lbDo05;
        private System.Windows.Forms.Label lbDo06;
        private System.Windows.Forms.Label lbDo07;
        private System.Windows.Forms.Label lbDo00;
        private System.Windows.Forms.Label lbDo021;
        private System.Windows.Forms.Label lbDo013;
        private System.Windows.Forms.Label lbDo020;
        private System.Windows.Forms.Label lbDo012;
        private System.Windows.Forms.Label lbDo018;
        private System.Windows.Forms.Label lbDo010;
        private System.Windows.Forms.Label lbDo01;
        private System.Windows.Forms.Label lbDo017;
        private System.Windows.Forms.Label lbDo09;
        private System.Windows.Forms.Label lbDo016;
        private System.Windows.Forms.Label lbDo08;
        private System.Windows.Forms.Label lbDo02;
        private System.Windows.Forms.Label lbDo022;
        private System.Windows.Forms.Label lbDo014;
        private System.Windows.Forms.Label lbDo019;
        private System.Windows.Forms.Label lbDo03;
        private System.Windows.Forms.Label lbDo023;
        private System.Windows.Forms.Label lbDo011;
        private System.Windows.Forms.Label lbDo015;
        private System.Windows.Forms.GroupBox grpDi1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.ComboBox cmbCardSystemId;
        private System.Windows.Forms.ComboBox cmbCardType;
    }
}
