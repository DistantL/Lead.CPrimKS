﻿using Lead.CPrim.Interfaces;
using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lead.CPrim.PrimADLink_IO
{
    public partial class PrimConfigControl : UserControl
    {
        private PrimADLink_IO _primADLink = null;
        private ADLinkConfig _config = null;

        public string ADLinkName
        {
            set => tBoxADLinkName.Text = value;
        }

        public PrimConfigControl()
        {
            InitializeComponent();
        }

        public PrimConfigControl(PrimADLink_IO prim)
        {
            InitializeComponent();
            _primADLink = prim;
        }
        public PrimConfigControl(PrimADLink_IO prim, ADLinkConfig config)
        {
            InitializeComponent();
            _primADLink = prim;
            _config = config;
            var arrayLabel0 = new Label[] { lbDo00, lbDo01, lbDo02, lbDo03, lbDo04, lbDo05, lbDo06, lbDo07, lbDo08, lbDo09, lbDo010, lbDo011, lbDo012, lbDo013, lbDo014, lbDo015, lbDo016, lbDo017, lbDo018,
            lbDo019, lbDo020, lbDo021, lbDo022, lbDo023, lbDo024, lbDo025, lbDo026, lbDo027, lbDo028, lbDo029, lbDo030, lbDo031};
            var arrayLabel1 = new Label[] { lbDo10, lbDo11, lbDo12, lbDo13, lbDo14, lbDo15, lbDo16, lbDo17, lbDo18, lbDo19, lbDo110, lbDo111, lbDo112, lbDo113, lbDo114, lbDo115, lbDo116, lbDo117, lbDo118,
            lbDo119, lbDo120, lbDo121, lbDo122, lbDo123, lbDo124, lbDo125, lbDo126, lbDo127, lbDo128, lbDo129, lbDo130, lbDo131};
            for (var i = 0; i < arrayLabel0.Length; i++)
            {
                arrayLabel0[i].Click += lblDo_Click;
            }
            for (var i = 0; i < arrayLabel1.Length; i++)
            {
                arrayLabel1[i].Click += lblDo1_Click;
            }
        }
        private void tmrUpdateUI_Tick(object sender, EventArgs e)
        {
            if (_primADLink.PrimRunStat == PrimRunState.Running)
            {
                foreach (var label in grpDi.Controls.OfType<Label>())
                {
                    if (label.BorderStyle == BorderStyle.FixedSingle)
                    {
                        var index = Convert.ToInt32(label.Tag);
                        _primADLink.ReadSingleDInput(100 + index * 0.01, out var status);
                        label.BackColor = status ? Color.LawnGreen : Color.DimGray;
                    }
                }

                if (grpDi1.Visible)
                {
                    foreach (var label in grpDi1.Controls.OfType<Label>())
                    {
                        if (label.BorderStyle == BorderStyle.FixedSingle)
                        {
                            var index = Convert.ToInt32(label.Tag);
                            _primADLink.ReadSingleDInput(100 + index * 0.01, out var status);
                            label.BackColor = status ? Color.LawnGreen : Color.DimGray;
                        }
                    }
                }

                foreach (var label in grpDo.Controls.OfType<Label>())
                {
                    if (label.BorderStyle == BorderStyle.FixedSingle)
                    {
                        var index = Convert.ToInt32(label.Tag);
                        _primADLink.ReadSingleDOutput(100 + index * 0.01, out var status);
                        label.BackColor = status ? Color.LawnGreen : Color.DimGray;
                    }
                }

                if (grpDo1.Visible)
                {
                    foreach (var label in grpDo1.Controls.OfType<Label>())
                    {
                        if (label.BorderStyle == BorderStyle.FixedSingle)
                        {
                            var index = Convert.ToInt32(label.Tag);
                            _primADLink.ReadSingleDInput(100 + index * 0.01, out var status);
                            label.BackColor = status ? Color.LawnGreen : Color.DimGray;
                        }
                    }
                }
            }
        }
        
        private void PrimConfigControl_Load(object sender, EventArgs e)
        {
            ADLinkName = _primADLink.Name;
            if (_primADLink.CardType > 0)
            {
                switch (_primADLink.CardType)
                {
                    case DASK.PCI_7230:
                        cmbCardType.SelectedItem = "7230";
                        break;
                    case DASK.PCI_7432:
                        cmbCardType.SelectedItem = "7432";
                        break;
                    default:
                        break;
                }
            }

            if (!cmbCardSystemId.Items.Contains(_primADLink.CardSystemId))
            {
                cmbCardSystemId.Items.Add(_primADLink.CardSystemId);
            }

            cmbCardSystemId.SelectedItem = _primADLink.CardSystemId;
            
        }
        private uint runningCntLast = 0;
        private void BtnInit_Click(object sender, EventArgs e)
        {
            if (_primADLink == null)
            {
                return;
            }

            _primADLink.IPrimInit();

            var result = "";
            _primADLink.IPrimConnect(ref result);
        }
        private void lblDo_Click(object sender, EventArgs e)
        {
            var label = (Label)sender;
            var index = Convert.ToInt32(label.Tag);
            var addr = 100 + index * 0.01;
            _primADLink.ReadSingleDOutput(100 + index * 0.01, out var status);
            _primADLink.WriteSingleDOutput(addr, !status);
        }
        private void lblDo1_Click(object sender, EventArgs e)
        {
            var label = (Label)sender;
            var index = Convert.ToInt32(label.Tag);
            var addr = 101 + index * 0.01;
            _primADLink.ReadSingleDOutput(101 + index * 0.01, out var status);
            _primADLink.WriteSingleDOutput(addr, !status);
        }
        private void BtnRun1_Click(object sender, EventArgs e)
        {
            _primADLink.IPrimStart();

            tmrUpdateUI.Enabled = true;
            tmrUpdateUI.Start();
        }

        private void BtnStop1_Click(object sender, EventArgs e)
        {
            _primADLink.IPrimStop();
        }
        private void cmbCardType_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbCardSystemId.Items.Clear();
            switch (cmbCardType.SelectedItem.ToString())
            {
                case "7230":
                    for (ushort i = 0; i < 16; i++)
                    {
                        //在下拉框中添加 systemID
                        if (DASK.Register_Card(DASK.PCI_7230, i) >= 0)
                        {
                            cmbCardSystemId.Items.Add(i);
                            _primADLink.CardType = DASK.PCI_7230;
                        }
                    }
                    grpDi1.Visible = false;
                    grpDo1.Visible = false;
                    break;
                case "7432":
                    for (ushort i = 0; i < 16; i++)
                    {
                        //在下拉框中添加 systemID
                        if (DASK.Register_Card(DASK.PCI_7432, i) >= 0)
                        {
                            cmbCardSystemId.Items.Add(i);
                            _primADLink.CardType = DASK.PCI_7432;
                        }
                    }
                    grpDi1.Visible = false;
                    grpDo1.Visible = false;
                    break;
            }
        }
        private void cmbCardSystemId_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCardSystemId.SelectedItem != null && ushort.TryParse(cmbCardSystemId.SelectedItem.ToString(), out var outId))
            {
                _primADLink.CardSystemId = outId;
            }
        }
        public void SetPrimConnState(PrimConnState state)
        {
            if (tBoxConnState.InvokeRequired)
            {
                BeginInvoke(new Action<PrimConnState>(SetPrimConnState), state);
            }
            else
            {
                switch (state)
                {
                    case PrimConnState.UnConnected:
                        tBoxConnState.BackColor = Color.Khaki;
                        tBoxConnState.Text = "UnConnected";
                        btnInit.BackColor = Color.SkyBlue;
                        btnRun1.BackColor = Color.LightGreen;
                        btnInit.Enabled = true;
                        btnRun1.Enabled = true;
                        break;
                    case PrimConnState.Connected:
                        tBoxConnState.BackColor = Color.LightGreen;
                        tBoxConnState.Text = "Connected";
                        btnInit.BackColor = Color.Gray;
                        btnInit.Enabled = false;
                        break;
                    case PrimConnState.Other:
                        tBoxConnState.BackColor = Color.Khaki;
                        tBoxConnState.Text = "UnConnected";
                        btnInit.BackColor = Color.SkyBlue;
                        btnRun1.BackColor = Color.LightGreen;
                        btnInit.Enabled = true;
                        btnRun1.Enabled = true;
                        break;
                }
            }

        }

        public void SetPrimRunState(PrimRunState state)
        {
            if (tBoxRunState.InvokeRequired)
            {
                BeginInvoke(new Action<PrimRunState>(SetPrimRunState), state);
            }
            else
            {
                switch (state)
                {
                    case PrimRunState.Idle:
                        tBoxRunState.BackColor = Color.Khaki;
                        tBoxRunState.Text = "Idle";
                        break;
                    case PrimRunState.Running:
                        tBoxRunState.BackColor = Color.LightGreen;
                        tBoxRunState.Text = "Running";
                        btnRun1.BackColor = Color.Gray;
                        btnRun1.Enabled = false;
                        btnInit.BackColor = Color.Gray;
                        btnInit.Enabled = false;
                        btnStop1.Enabled = true;
                        btnStop1.BackColor = Color.SandyBrown;
                        break;
                    case PrimRunState.Stop:
                        tBoxRunState.BackColor = Color.Brown;
                        tBoxRunState.Text = "Stop";
                        btnRun1.BackColor = Color.LightGreen;
                        btnRun1.Enabled = true;
                        btnInit.BackColor = Color.Gray;
                        btnInit.Enabled = false;
                        btnStop1.Enabled = false;
                        btnStop1.BackColor = Color.Gray;
                        break;
                    case PrimRunState.Err:
                        tBoxRunState.BackColor = Color.SandyBrown;
                        tBoxRunState.Text = "Err";
                        break;
                    case PrimRunState.Other:
                        tBoxRunState.BackColor = Color.Khaki;
                        tBoxRunState.Text = "Idle";
                        btnInit.Enabled = true;
                        btnInit.BackColor = Color.LightGreen;
                        btnRun1.Enabled = false;
                        btnRun1.BackColor = Color.Gray;
                        btnStop1.Enabled = false;
                        btnStop1.BackColor = Color.Gray;
                        break;
                }
            }
        }
    }
}
