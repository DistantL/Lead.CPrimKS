using Lead.CPrim.Interfaces;
using System;

namespace Lead.CPrim.PrimADLink_IO
{
    public class ADLinkConfig
    {
        #region Override IPrim's Property
        public string Name
        { set; get; }

        public string PrimTypeName
        { set; get; }

        public Guid Id
        { set; get; }
        
        public Type ChildType
        { set; get; }
        
        public PrimType HSType
        { set; get; }

        public PrimManufacture Manu
        { set; get; }

        public PrimVer Ver
        { set; get; }
        
        public PrimConnState PrimConnStat
        { set; get; }

        public PrimRunState PrimRunStat
        { set; get; }

        public bool PrimSimulator
        { set; get; }

        public bool PrimDebug
        { set; get; }

        public bool PrimEnable
        { set; get; }

        #endregion
        #region Override IMotionCard's Property
        public ushort CardType { set; get; }
        public ushort CardSystemId { set; get; }
        #endregion

    }
}
