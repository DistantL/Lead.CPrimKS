﻿/******************************************************************************
 * CPrim
 * CopyRight (C) 2020-2030.
 * FileName: PrimFins.cs
 * Author: Victor
 * Description: 欧姆龙Fins通讯核心类，支持FinsNet及FinsUdp
 * CreateTime: 2022-09-21
 * 
 * If you use this code, please keep this note.
 * 如果您使用此代码，请保留此说明。
 ******************************************************************************
 * 版本迭代说明&修改记录
 * FinsNet支持逐个读取（SHORT,INT,LONG,FLOAT,USHORT,UINT,ULONG,DOUBLE,BOOL,STRING）、逐个写入（SHORT,INT,LONG,FLOAT,USHORT,UINT,ULONG,DOUBLE,BOOL,STRING）以及批量读取（FLOAT,USHORT,STRING）
 * FinsUdp支持逐个读取（SHORT,INT,LONG,FLOAT,USHORT,UINT,ULONG,DOUBLE,BOOL,STRING）、逐个写入（SHORT,INT,LONG,FLOAT,USHORT,UINT,ULONG,DOUBLE,BOOL,STRING）
 * <3.3.22.0904><Victor><20220921>
 * 1、初版1.0
 * <3.3.22.1010><Victor><20221016>
 * 1、增加FinsNet批量读取功能，支持FLOAT,USHORT,STRING
 * <3.3.22.1010><Victor><20221017>
 * 1、FLOAT变量长度由2变更为4
******************************************************************************/

using CommunicationBase;
using Lead.CPrim.Interfaces;
using Lead.CPrim.Interfaces.Dev;
using Lead.CPrim.ProxyTools;
using Lead.CPrim.ProxyTools.SunnyUI.Style;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Lead.CPrim.PrimFinsNet
{
    /// <summary>基元管理类</summary>
    public class PrimFins : IPrim, IPlc
    {
        //public event PrimDataRefresh OnPrimDataRefresh;
        //public event PrimStateChanged OnPrimStateChanged;
        //public event PrimOpLog OnPrimOpLog;



        #region Field
        /// <summary>Fins配置管理器</summary>
        public PrimFinsConfig _config;
        /// <summary>连接成功标志</summary>
        private bool _netConnetedSuccess;
        /// <summary>OmronFinsNet</summary>
        public IOmronFins _omronPlc;
        /// <summary>数据表集合</summary>
        public FinsDataConfigs DataConfigs = new FinsDataConfigs();
        /// <summary>读取线程</summary>
        Task taskRead;
        /// <summary>读取线程取消标志</summary>
        CancellationTokenSource cts = new CancellationTokenSource();

        /// <summary>
        /// 时钟
        /// </summary>
        private Stopwatch _sw = new Stopwatch();

        /// <summary>
        /// 循环时间
        /// </summary>
        private int _cycleTime = 0;
        #endregion



        #region Ctor
        public PrimFins()
        {
            _config = new PrimFinsConfig();

            HSType = PrimType.Protocol;
            Manu = PrimManufacture.Lead;

            DataConfigs = new FinsDataConfigs();

            PrimDebugUI = new PrimDebugControl(this);
            PrimConfigUI = new PrimConfigControl(this);
            PrimOutputUI = new PrimOutputControl();

            PrimConnStat = PrimConnState.Other;
            PrimRunStat = PrimRunState.Other;

            ((PrimConfigControl)PrimConfigUI).SetPrimConnState(PrimConnStat);
            ((PrimConfigControl)PrimConfigUI).SetPrimRunState(PrimRunStat);

            ((PrimDebugControl)PrimDebugUI).SetPrimConnState(PrimConnStat);
            ((PrimDebugControl)PrimDebugUI).SetPrimRunState(PrimRunStat);
        }
        public PrimFins(XmlNode xmlNode)
        {
            if (xmlNode != null)
                _config = XMLHelper.XMLToObject(xmlNode, typeof(PrimFinsConfig)) as PrimFinsConfig;
            else
                return;

            HSType = PrimType.Protocol;
            Manu = PrimManufacture.Lead;

            DataConfigs = new FinsDataConfigs();

            if (!string.IsNullOrEmpty(_config.DataTablePath) && File.Exists(_config.DataTablePath))
            {
                ImportDataTable(_config.DataTablePath);
            }

            PrimDebugUI = new PrimDebugControl(this);
            PrimConfigUI = new PrimConfigControl(this);
            PrimOutputUI = new PrimOutputControl();

            PrimConnStat = PrimConnState.Other;
            PrimRunStat = PrimRunState.Other;

            ((PrimConfigControl)PrimConfigUI).SetPrimConnState(PrimConnStat);
            ((PrimConfigControl)PrimConfigUI).SetPrimRunState(PrimRunStat);
        }
        #endregion



        #region Prop
        /// <summary>IP</summary>
        public string IP { get => _config.IP; set => _config.IP = value; }
        /// <summary>Port</summary>
        public string Port { get => _config.Port; set => _config.Port = value; }
        /// <summary>上位机的节点地址，假如你的电脑的Ip地址为192.168.0.13，那么这个值就是13</summary>
        public string SA1 { get => _config.SA1; set => _config.SA1 = value; }
        /// <summary>PLC的节点地址，这个值在配置了ip地址之后是默认赋值的，默认为Ip地址的最后一位</summary>
        public string DA1 { get => _config.DA1; set => _config.DA1 = value; }
        /// <summary>PLC的单元号地址，通常都为0</summary>
        public string DA2 { get => _config.DA2; set => _config.DA2 = value; }
        /// <summary>循环时间</summary>
        public int CycleTime { set => _config.CycleTime = value; get => _config.CycleTime; }
        /// <summary>重连次数</summary>
        public int ReconnectCnt { get => _config.ReconnectCnt; set => _config.ReconnectCnt = value; }
        /// <summary>数据表地址</summary>
        public string DataTablePath { set => _config.DataTablePath = value; get => _config.DataTablePath; }
        /// <summary>Fins类型</summary>
        public FinsType FinsTypeSelect { set => _config.FinsTypeSelect = value; get => _config.FinsTypeSelect; }
        /// <summary>通知模式</summary>
        public SktNotifyMode NotifyMode { get => _config.NotifyMode; set => _config.NotifyMode = value; }
        /// <summary>硬件归属</summary>
        public PrimManufacture Manu { set => _config.Manu = value; get => _config.Manu; }
        /// <summary>日志启用</summary>
        public bool LogEnable { get => _config.LogEnable; set => _config.LogEnable = value; }
        /// <summary>读起始地址</summary>
        public string ReadStartAddress { get => _config.ReadStartAddress; set => _config.ReadStartAddress = value; }
        /// <summary>读长度</summary>
        public ushort ReadLength { get => _config.ReadLength; set => _config.ReadLength = value; }
        /// <summary>写起始地址</summary>
        public string WriteStartAddress { get => _config.WriteStartAddress; set => _config.WriteStartAddress = value; }
        /// <summary>写长度</summary>
        public ushort WriteLength { get => _config.WriteLength; set => _config.WriteLength = value; }
        public LogLevel PrimAlarmLv { get; set; }
        public RunMode PrimRunMode { get; set; }
        #endregion



        //*****************************************************************************
        #region Override IPrim
        public Guid Id { set => _config.Id = value; get => _config.Id; }
        public string Name { set => _config.Name = value; get => _config.Name; }
        public bool PrimEnable { set => _config.PrimEnable = value; get => _config.PrimEnable; }
        public PrimType HSType { set => _config.HSType = value; get => _config.HSType; }
        public string PrimTypeName { set => _config.PrimTypeName = value; get => _config.PrimTypeName; }
        public Control PrimConfigUI { get; }
        public Control PrimDebugUI { get; }
        public Control PrimOutputUI { get; }
        public PrimConnState PrimConnStat
        {
            set
            {
                if (_config.PrimConnStat == value)
                {
                    return;
                }
                _config.PrimConnStat = value;
                ((PrimConfigControl)PrimConfigUI).SetPrimConnState(value);
                ((PrimDebugControl)PrimDebugUI).SetPrimConnState(value);
            }
            get => _config.PrimConnStat;
        }
        public PrimRunState PrimRunStat
        {
            set
            {
                if (_config.PrimRunStat == value)
                {
                    return;
                }
                _config.PrimRunStat = value;
                ((PrimConfigControl)PrimConfigUI).SetPrimRunState(value);
                ((PrimDebugControl)PrimDebugUI).SetPrimRunState(value);
            }
            get => _config.PrimRunStat;
        }
        public PrimVer Ver { set => _config.Ver = value; get => _config.Ver; }
        public int CurrentImageIndex { get => _config.CurrentImageIndex; set => _config.CurrentImageIndex = value; }


        public int IPrimInit()
        {
            try
            {
                var iRet = 0;
                if (PrimConnStat == PrimConnState.Connected)
                {
                    LogAdd("已经连接成功_无需进行二次连接", LogLevel.Info);
                    return 0;
                }

                if (!IPAddress.TryParse(IP, out var address))
                {
                    throw new Exception("IP格式有误");
                }
                if (!int.TryParse(Port, out var port))
                {
                    throw new Exception("端口格式有误");
                }
                if (!byte.TryParse(SA1, out var sa1))
                {
                    throw new Exception("SA1格式有误");
                }
                if (!byte.TryParse(DA1, out var da1))
                {
                    throw new Exception("DA1格式有误");
                }
                if (!byte.TryParse(DA2, out var da2))
                {
                    throw new Exception("DA2格式有误");
                }

                if (FinsTypeSelect == FinsType.FinsUdp)
                {
                    _omronPlc = new FinsUdp(IP, port, sa1, da1, da2);
                }
                else if (FinsTypeSelect == FinsType.FinsNet)
                {
                    _omronPlc = new FinsNet(IP, port, sa1, da1, da2);
                }
                else
                {
                    throw new Exception("Fins类型错误");
                }

                var reconnectCnt = 0;
                while (true)
                {
                    if (_omronPlc.Connect())
                    {
                        LogAdd("连接成功", LogLevel.Info);
                        _netConnetedSuccess = true;
                        break;
                    }

                    if (++reconnectCnt >= ReconnectCnt)
                    {
                        _netConnetedSuccess = false;
                        throw new Exception($"连续{ReconnectCnt}次连接失败");
                    }

                    Thread.Sleep(500);
                }


                PrimConnStat = PrimConnState.Connected;

                return iRet;
            }
            catch (Exception ex)
            {
                PrimConnStat = PrimConnState.UnConnected;
                LogAdd($"IPrimInit失败：{ex.Message}", LogLevel.Warn);
                return (int)SoftWareAlarm.PrimFinsNet_IPrimInit返回值不等于0;
            }
        }
        public int IPrimConnect(ref string result)
        {
            var iRet = 0;

            return iRet;
        }
        public int IPrimStart()
        {
            var iRet = 0;
            try
            {
                if (PrimConnStat != PrimConnState.Connected)
                {
                    throw new Exception("未连接_不能进行启动");
                }

                if (PrimRunStat == PrimRunState.Running)
                {
                    LogAdd("已经运行成功_无需进行二次运行", LogLevel.Info);
                    return 0;
                }

                cts = new CancellationTokenSource();
                taskRead = Task.Run(() => CycleRead(cts.Token));
                PrimRunStat = PrimRunState.Running;
                LogAdd("运行成功", LogLevel.Info);
            }
            catch (Exception ex)
            {
                PrimRunStat = PrimRunState.Stop;
                LogAdd($"IPrimStart失败：{ex.Message}", LogLevel.Warn);
                return (int)SoftWareAlarm.PrimFinsNet_IPrimStart返回值不等于0;
            }

            return iRet;
        }
        public int IPrimStop()
        {
            var iRet = 0;

            try
            {
                if (cts != null)
                {
                    cts.Cancel();
                }

                if(taskRead != null)
                {
                    taskRead.Wait(500);
                    taskRead = null;
                }
            }
            catch (Exception ex)
            {
                LogAdd($"停止失败：{ex.Message}", LogLevel.Warn);
                taskRead = null;
            }
            // 断开连接
            _omronPlc?.DisConnect();
            _omronPlc = null;

            PrimConnStat = PrimConnState.UnConnected;
            PrimRunStat = PrimRunState.Stop;
            return iRet;
        }
        public int IPrimDispose()
        {
            try
            {
                ((PrimDebugControl)PrimDebugUI).Dispose();
                ((PrimOutputControl)PrimOutputUI).Dispose();
                ((PrimConfigControl)PrimConfigUI).Dispose();

                PrimRunStat = PrimRunState.Other;
                PrimConnStat = PrimConnState.Other;
                return 0;
            }
            catch (Exception)
            {
                PrimRunStat = PrimRunState.Err;
                PrimConnStat = PrimConnState.Other;
                return -1;
            }
        }
        public int IPrimTaskInit()
        {
            ClearOnPlcVariableChanged();
            if (IPrimInit() != 0) return -1;

            var connRet = "";
            if (IPrimConnect(ref connRet) != 0) return -2;

            if (IPrimStart() != 0) return -3;

            return 0;
        }
        public int IPrimTaskPause()
        {
            return 0;
        }
        public int IPrimTaskReset()
        {
            return 0;
        }
        public int IPrimTaskStop()
        {
            if (IPrimStop() != 0) return -1;
            return 0;
        }
        public XmlNode IPrimExportConfigXml()
        {
            if (_config == null) return null;

            var node = XMLHelper.ObjectToXML(_config);

            return node;
        }
        public int IPrimImportConfigXml(XmlNode xmlNode)
        {
            var iRet = 0;

            if (xmlNode == null)
            {
                return -1;
            }
            _config = XMLHelper.XMLToObject(xmlNode, typeof(PrimFinsConfig)) as PrimFinsConfig;

            if (!string.IsNullOrEmpty(_config.DataTablePath) && File.Exists(_config.DataTablePath))
            {
                ImportDataTable(_config.DataTablePath);
            }
            return iRet;
        }
        #endregion



        //*****************************************************************************
        #region Override IPlc
        public event Del_PlcVariableChanged OnPlcVariableChanged;

        public bool Conneted => _omronPlc != null && _netConnetedSuccess;

        public int ClearOnPlcVariableChanged()
        {
            if (OnPlcVariableChanged == null)
            {
                return 0;
            }
            
            foreach (var d in OnPlcVariableChanged.GetInvocationList())
            {
                OnPlcVariableChanged -= d as Del_PlcVariableChanged;
            }

            return 0;
        }
        public object ReadVariableFromAddr(string valAddr)
        {
            object obj = null;
            if (DataConfigs?.ListDataConfig == null || DataConfigs.ListDataConfig.Count <= 0)
            {
                return obj;
            }
            FinsDataConfig dataConfig = DataConfigs.ListDataConfig.FirstOrDefault(config => config.DtAddress == valAddr);
            if (dataConfig == null)
            {
                return obj;
            }
            return ReadSingleVariable(dataConfig);
        }
        public object ReadVariableFromAddr(string valAddr, ProtocolDataType valType, ushort length = 0)
        {
            object val = null;
            bool result;
            if (string.IsNullOrEmpty(valAddr))
            {
                return null;
            }

            switch (valType)
            {
                case ProtocolDataType.SHORT:
                    result = ReadResult(_omronPlc.ReadInt16(valAddr), out val);
                    break;

                case ProtocolDataType.INT:
                    result = ReadResult(_omronPlc.ReadInt32(valAddr), out val);
                    break;

                case ProtocolDataType.LONG:
                    result = ReadResult(_omronPlc.ReadInt64(valAddr), out val);
                    break;

                case ProtocolDataType.FLOAT:
                    result = ReadResult(_omronPlc.ReadFloat(valAddr), out val);
                    break;

                case ProtocolDataType.USHORT:
                    result = ReadResult(_omronPlc.ReadUInt16(valAddr), out val);
                    break;

                case ProtocolDataType.UINT:
                    result = ReadResult(_omronPlc.ReadUInt32(valAddr), out val);
                    break;

                case ProtocolDataType.ULONG:
                    result = ReadResult(_omronPlc.ReadUInt64(valAddr), out val);
                    break;

                case ProtocolDataType.DOUBLE:
                    result = ReadResult(_omronPlc.ReadDouble(valAddr), out val);
                    break;

                case ProtocolDataType.BOOL:
                    result = ReadResult(_omronPlc.ReadBool(valAddr), out val);
                    break;

                case ProtocolDataType.STRING:
                    result = ReadResult(_omronPlc.ReadString(valAddr, length), out val);
                    break;

                default:
                    result = ReadResult(_omronPlc.ReadString(valAddr, length), out val);
                    break;
            }
            return val;
        }
        public object ReadVariableFromName(string valName)
        {
            object obj = null;
            if (DataConfigs?.ListDataConfig == null || DataConfigs.ListDataConfig.Count <= 0)
            {
                return obj;
            }
            FinsDataConfig dataConfig = DataConfigs.ListDataConfig.FirstOrDefault(config => config.DtName == valName);
            if (dataConfig == null)
            {
                return obj;
            }
            return ReadSingleVariable(dataConfig);
        }
        public int WriteVariableFromName(string valName, object val)
        {
            var ret = -1;

            if (string.IsNullOrEmpty(valName))
            {
                LogAdd("名称为空", LogLevel.Warn);
                return -1;
            }

            FinsDataConfig dataConfig = DataConfigs.ListDataConfig.FirstOrDefault(config => config.DtName == valName);
            if (dataConfig == null)
            {
                return 0;
            }

            ret = WriteVariableFromAddr(dataConfig.DtAddress, dataConfig.DtType, val);
            return ret;
        }
        public int WriteVariableFromAddr(string valAddr, object val)
        {
            var ret = -1;

            if (string.IsNullOrEmpty(valAddr))
            {
                LogAdd("地址为空", LogLevel.Warn);
                return -1;
            }

            FinsDataConfig dataConfig = DataConfigs.ListDataConfig.FirstOrDefault(config => config.DtAddress == valAddr);
            if (dataConfig == null)
            {
                return 0;
            }

            ret = WriteVariableFromAddr(dataConfig.DtAddress, dataConfig.DtType, val);
            return ret;
        }
        public int WriteVariableFromAddr(string valAddr, ProtocolDataType valType, object val)
        {
            var ret = -1;
            var isSuccess = false;
            if (string.IsNullOrEmpty(valAddr)) return -1;

            switch (valType)
            {
                case ProtocolDataType.SHORT:
                    isSuccess = _omronPlc.WriteInt16(valAddr, Int16.Parse(val.ToString())).IsSuccess;
                    break;

                case ProtocolDataType.INT:
                    isSuccess = _omronPlc.WriteInt32(valAddr, Int32.Parse(val.ToString())).IsSuccess;
                    break;

                case ProtocolDataType.LONG:
                    isSuccess = _omronPlc.WriteInt64(valAddr, Int64.Parse(val.ToString())).IsSuccess;
                    break;

                case ProtocolDataType.USHORT:
                    isSuccess = _omronPlc.WriteUInt16(valAddr, UInt16.Parse(val.ToString())).IsSuccess;
                    break;

                case ProtocolDataType.UINT:
                    isSuccess = _omronPlc.WriteUInt32(valAddr, UInt32.Parse(val.ToString())).IsSuccess;
                    break;

                case ProtocolDataType.ULONG:
                    isSuccess = _omronPlc.WriteUInt64(valAddr, UInt64.Parse(val.ToString())).IsSuccess;
                    break;

                case ProtocolDataType.FLOAT:
                    isSuccess = _omronPlc.WriteFloat(valAddr, float.Parse(val.ToString())).IsSuccess;
                    break;

                case ProtocolDataType.DOUBLE:
                    isSuccess = _omronPlc.WriteDouble(valAddr, double.Parse(val.ToString())).IsSuccess;
                    break;

                case ProtocolDataType.BOOL:
                    isSuccess = _omronPlc.WriteBool(valAddr, bool.Parse(val.ToString())).IsSuccess;
                    break;

                case ProtocolDataType.STRING:
                    isSuccess = _omronPlc.WriteString(valAddr, val.ToString()).IsSuccess;
                    break;
            }

            if (isSuccess) ret = 0;
            return ret;
        }
        #endregion



        //*****************************************************************************
        #region Method_ExternalUsing
        /// <summary>加载本地Fins文件</summary>
        /// <param name="filePath">路径</param>
        /// <returns></returns>
        public int ImportDataTable(string filePath)
        {
            var iRet = 0;
            if (DataConfigs == null)
            {
                DataConfigs = new FinsDataConfigs();
            }
            if (DataConfigs.ListDataConfig == null)
            {
                DataConfigs.ListDataConfig = new List<FinsDataConfig>();
            }
            DataConfigs.ListDataConfig.Clear();

            if (File.Exists(filePath))
            {
                DataConfigs = XmlSerializerHelper.ReadXML(filePath, typeof(FinsDataConfigs)) as FinsDataConfigs;
            }

            if (DataConfigs == null)
            {
                DataConfigs = new FinsDataConfigs();
            }
            return iRet;
        }
        /// <summary>保存本地Fins文件</summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public int ExportDataTable(string filePath)
        {
            return XmlSerializerHelper.WriteXML(DataConfigs, filePath, typeof(FinsDataConfigs)) ? 0 : -1;
        }
        #endregion



        //*****************************************************************************
        #region Method_InternalUsing

        /// <summary>日志</summary>
        /// <param name="msg">信息</param>
        /// <param name="lv">日志等级</param>
        /// <param name="id">id</param>
        /// <param name="isShowDialog">true：显示弹窗；false：不显示弹窗；</param>
        public void LogAdd(string msg, LogLevel lv, long id = 0, bool isShowDialog = false)
        {
            if (!LogEnable && lv != LogLevel.Warn && lv != LogLevel.Error && lv != LogLevel.Fatal)
            {
                return;
            }

            msg = $"PrimFinsNet -> { Name} -> " + msg;
            string tempId = $"{(int)lv}{(int)PrimLogId.PrimFinsNet}0000";

            if (int.TryParse(tempId, out var intId))
            {
                id += intId;
            }

            LogHelper.LogAdd(lv, msg, Name, LogClassification.VisioPrim, id);

            if ((lv == LogLevel.Fatal || lv == LogLevel.Error || lv == LogLevel.Warn) && isShowDialog)
            {
                UIMessageDialog.ShowMessageDialog(msg, ULocalize.WarningTitle, false, UIStyle.Orange, false, true);
            }
        }
        /// <summary>循环线程</summary>
        private void CycleRead(CancellationToken token)
        {
            // 阻塞等触发
            while (true)
            {
                _sw.Restart();
                if (PrimRunStat != PrimRunState.Running)
                {
                    if (token.IsCancellationRequested)
                    {
                        LogAdd("手动停止", LogLevel.Info);
                        return;
                    }

                    Thread.Sleep(10);
                    continue;
                }

                if (DataConfigs?.ListDataConfig == null || DataConfigs.ListDataConfig.Count <= 0)
                {

                    if (token.IsCancellationRequested)
                    {
                        LogAdd("手动停止", LogLevel.Info);
                        return;
                    }

                    Thread.Sleep(10);
                    continue;
                }

                OperateResult<byte[]> readRBuffer;
                OperateResult<byte[]> readWBuffer;
                int start = 0;
                int length = 0;
                object obj = null;

                readRBuffer = _omronPlc.ReadRegister(ReadStartAddress, ReadLength);
                readWBuffer = _omronPlc.ReadRegister(WriteStartAddress, WriteLength);

                foreach (var config in DataConfigs.ListDataConfig)
                {
                    if (token.IsCancellationRequested)
                    {
                        LogAdd("手动停止", LogLevel.Info);
                        return;
                    }

                    if (!(config.DtRdMode == DataReadMode.Cycle))
                    {
                        continue;
                    }

                    if (!(config.DtPermission == DataPermission.R || config.DtPermission == DataPermission.RW))
                    {
                        continue;
                    }

                    if (config.DtPermission == DataPermission.R)
                    {
                        if(!CalLength(config.DtAddress, ReadStartAddress, ref start))
                        {
                            continue;
                        }
                    }
                    else
                    {
                        if (!CalLength(config.DtAddress, WriteStartAddress, ref start))
                        {
                            continue;
                        }
                    }

                    switch (config.DtType)
                    {
                        case ProtocolDataType.SHORT:
                            break;
                        case ProtocolDataType.INT:
                            break;
                        case ProtocolDataType.LONG:
                            break;
                        case ProtocolDataType.FLOAT:
                            length = 4;
                            break;
                        case ProtocolDataType.USHORT:
                            length = 2;
                            break;
                        case ProtocolDataType.UINT:
                            break;
                        case ProtocolDataType.ULONG:
                            break;
                        case ProtocolDataType.DOUBLE:
                            break;
                        case ProtocolDataType.BOOL:
                            break;
                        case ProtocolDataType.STRING:
                            length = config.DtLength * 2;
                            break;
                        case ProtocolDataType.OTHER:
                        default:
                            length = 2;
                            break;
                    }
                    if (config.DtPermission == DataPermission.R)
                    {
                        obj = TransString(readRBuffer.Content, start, length, config.DtType, Encoding.ASCII);
                    }
                    else
                    {
                        obj = TransString(readWBuffer.Content, start, length, config.DtType, Encoding.ASCII);
                    }
                    if (obj == null)
                    {
                        continue;
                    }
                    string result = obj.ToString();
                    if (!result.Equals(config.DtCurrentValue))
                    {
                        config.DtLastValue = config.DtCurrentValue;
                        config.DtCurrentValue = result;
                        if (config.DtIsNotify)
                        {
                            OnPlcVariableChanged?.BeginInvoke(config.DtName, config.DtAddress, config.DtType.ToString(), config.DtLastValue, config.DtCurrentValue, null, null);
                        }
                    }
                }

                _cycleTime = (int)_sw.ElapsedMilliseconds;
                if (_cycleTime < _config.CycleTime)
                {
                    Thread.Sleep(_config.CycleTime - _cycleTime);
                    ((PrimConfigControl)PrimConfigUI).SetCycleTime(_config.CycleTime);
                }
                else
                {
                    ((PrimConfigControl)PrimConfigUI).SetCycleTime(_cycleTime);
                }
            }
        }
        /// <summary>数据读取</summary>
        /// <param name="config"></param>
        private object ReadSingleVariable(FinsDataConfig config)
        {
            object obj = null;
            if (string.IsNullOrEmpty(config.DtName) || string.IsNullOrEmpty(config.DtAddress))
            {
                return obj;
            }

            try
            {
                obj = ReadVariableFromAddr(config.DtAddress, config.DtType, config.DtLength);
                if (config.DtType == ProtocolDataType.STRING)
                {
                    int len = obj.ToString().IndexOf('\0') == -1 ? obj.ToString().Length - 1 : obj.ToString().IndexOf('\0');
                    obj = obj.ToString().Substring(0, len);
                }
            }
            catch
            {
                return obj;
            }
            return obj;
        }
        /// <summary>读取结果判断</summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="result"></param>
        /// <param name="val">读取到的数据</param>
        /// <returns>true：读取成功；false：读取失败；</returns>
        private bool ReadResult<T>(OperateResult<T> result, out object val)
        {
            if (result.IsSuccess)
            {
                val = result.Content;
                return true;
            }
            else
            {
                val = null;
                return false;
            }
        }
        /// <summary>计算地址起始值</summary>
        /// <param name="currentAddress"></param>
        /// <param name="startAddress"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        private bool CalLength(string currentAddress, string startAddress, ref int length)
        {
            int start;
            int end;
            if (!currentAddress.ToUpper().Contains("D") || !startAddress.ToUpper().Contains("D"))
            {
                return false;
            }
            if (!int.TryParse(currentAddress.Replace("D", ""), out end))
            {
                return false;
            }
            if (!int.TryParse(startAddress.Replace("D", ""), out start))
            {
                return false;
            }
            length = (end - start) * 2;
            return true;
        }
        public string TransString(byte[] buffer, int index, int length, ProtocolDataType type, Encoding encoding = null)
        {
            byte[] array = new byte[length];
            Array.Copy(buffer, index, array, 0, length);
            switch (type)
            {
                case ProtocolDataType.SHORT:
                    break;
                case ProtocolDataType.INT:
                    break;
                case ProtocolDataType.LONG:
                    break;
                case ProtocolDataType.FLOAT:
                    return _omronPlc.ReadFloat("", array, false).Content.ToString();
                case ProtocolDataType.USHORT:
                    return _omronPlc.ReadUInt16("", array, false).Content.ToString();
                case ProtocolDataType.UINT:
                    break;
                case ProtocolDataType.ULONG:
                    break;
                case ProtocolDataType.DOUBLE:
                    break;
                case ProtocolDataType.BOOL:
                    break;
                case ProtocolDataType.STRING:
                default:
                    return _omronPlc.ReadString("", 0, array, false).Content;
            }
            return _omronPlc.ReadString("", 0, array, false).Content;
        }
        /// <summary>Test</summary>
        private void test()
        {
            //// 读取操作，这里的D100可以替换成C100,A100,W100,H100效果时一样的
            //var D100_7 = _omronPlc.ReadBool("D100.7").Content; // 读取D100.7是否通断，注意D100.0等同于D100
            //var short_D100 = _omronPlc.ReadInt16("D100").Content; // 读取D100组成的字
            //var ushort_D100 = _omronPlc.ReadUInt16("D100").Content; // 读取D100组成的无符号的值
            //var int_D100 = _omronPlc.ReadInt32("D100").Content; // 读取D100-D101组成的有符号的数据
            //var uint_D100 = _omronPlc.ReadUInt32("D100").Content; // 读取D100-D101组成的无符号的值
            //var float_D100 = _omronPlc.ReadFloat("D100").Content; // 读取D100-D101组成的单精度值
            //var long_D100 = _omronPlc.ReadInt64("D100").Content; // 读取D100-D103组成的大数据值
            //var ulong_D100 = _omronPlc.ReadUInt64("D100").Content; // 读取D100-D103组成的无符号大数据
            //var double_D100 = _omronPlc.ReadDouble("D100").Content; // 读取D100-D103组成的双精度值
            //var str_D100 = _omronPlc.ReadString("D100", 5).Content; // 读取D100-D104组成的ASCII字符串数据

            //// 写入操作，这里的D100可以替换成C100,A100,W100,H100效果时一样的
            //_omronPlc.Write("D100", (byte)0x33); // 写单个字节
            //_omronPlc.Write("D100", (short)12345); // 写双字节有符号
            //_omronPlc.Write("D100", (ushort)45678); // 写双字节无符号
            //_omronPlc.Write("D100", 3456789123); // 写双字无符号
            //_omronPlc.Write("D100", 123.456f); // 写单精度
            //_omronPlc.Write("D100", 1234556434534545L); // 写大整数有符号
            //_omronPlc.Write("D100", 523434234234343UL); // 写大整数无符号
            //_omronPlc.Write("D100", 123.456d); // 写双精度
            //_omronPlc.Write("D100", "K123456789"); // 写ASCII字符串

            //var read = _omronPlc.Read("D100", 5);
            //{
            //    if (read.IsSuccess)
            //    {
            //        // 此处需要根据实际的情况来自定义来处理复杂的数据
            //        var D100 = _omronPlc.ByteTransform.TransInt16(read.Content, 0);
            //        var D101 = _omronPlc.ByteTransform.TransInt16(read.Content, 2);
            //        var D102 = _omronPlc.ByteTransform.TransInt16(read.Content, 4);
            //        var D103 = _omronPlc.ByteTransform.TransInt16(read.Content, 6);
            //        var D104 = _omronPlc.ByteTransform.TransInt16(read.Content, 7);
            //    }
            //}
        }
        #endregion
    }
}