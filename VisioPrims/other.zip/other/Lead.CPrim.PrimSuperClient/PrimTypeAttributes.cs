﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Resources;
using Lead.CPrim.Interfaces;

namespace Lead.CPrim.PrimSuperClient
{
    public class PrimTypeAttributes : IPrimTypeAttributes
    {
        public IEnumerable<KeyValuePair<string, object>> Attributes => throw new NotImplementedException();
        public string Description => "";
        public string DisplayGroup => "Dev";
        public string DisplayName => "SuperClient";
        public string Group => "Dev";

        public Image Icon
        {
            get
            {
                var manager = new ResourceManager(typeof(PrimSuperClient));
                return (Image)manager.GetObject("ss_Client");
            }
        }

        public byte MajorVersion => 1;
        public byte MinorVersion => 0;
        public string Name => "SuperClient";
        public object this[string attrName] => throw new NotImplementedException();
    }
}