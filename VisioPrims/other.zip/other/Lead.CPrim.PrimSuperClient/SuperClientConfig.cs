﻿using System;
using Lead.CPrim.Interfaces;

namespace Lead.CPrim.PrimSuperClient
{
    public class SuperClientConfig
    {
        //Prim 子类的类型
        public Type ChildType { set; get; }

        public string ClientIp { get; set; }
        public string ClientName { set; get; }
        public bool DebugEnable { set; get; }
        public int HeartCycTime { set; get; }
        public bool HeartEnable { set; get; }
        public bool HeartFlag { set; get; }

        //Prim的硬件、软件类型
        public PrimType HSType { set; get; }

        public Guid Id { set; get; }
        public bool LogDisplay { set; get; }
        public bool LogEnable { set; get; }
        public PrimManufacture Manu { set; get; }
        public string Name { set; get; }
        public bool NetConneted { get; }
        public SuperNotifyMode NotifyMode { set; get; }
        public int Port { set; get; }
        public PrimConnState PrimConnStat { set; get; }
        public bool PrimDebug { set; get; }
        public bool PrimEnable { set; get; }
        public PrimRunState PrimRunStat { set; get; }
        public bool PrimSimulator { set; get; }
        public string PrimTypeName { set; get; }
        public int ReconnectCnt { set; get; }
        public string RemoteObj { set; get; }
        public int RevQueueCnt { set; get; }
        public int SendQueueCnt { set; get; }
        public string TargetAddr { set; get; }
        public string TargetName { set; get; }
        public PrimVer Ver { set; get; }
    }
}