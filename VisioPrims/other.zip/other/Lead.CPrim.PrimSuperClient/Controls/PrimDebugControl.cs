﻿using System.Windows.Forms;

namespace Lead.CPrim.PrimSuperClient.Controls
{
    public partial class PrimDebugControl : UserControl
    {
        public PrimDebugControl()
        {
            InitializeComponent();
        }
    }
}