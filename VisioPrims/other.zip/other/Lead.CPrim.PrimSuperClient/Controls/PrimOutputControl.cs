﻿using System.Drawing;
using System.Windows.Forms;
using Lead.CPrim.Interfaces;
using Lead.CPrim.LocalizationService;

namespace Lead.CPrim.PrimSuperClient.Controls
{
    public partial class PrimOutputControl : UserControl
    {
        private IPrim _prim = null;

        public PrimOutputControl()
        {
            InitializeComponent();
            InitializeUI();
        }

        public PrimOutputControl(IPrim prim)
        {
            InitializeComponent();
            InitializeUI();
            _prim = prim;
        }

        public string SuperClientName
        {
            set => tBoxName.Text = value;
        }

        private void InitializeUI()
        {
            this.lbTitle.Text = NLocalizer.GetString("PrimSuperClient_PrimOutputControl_SuperClient", "Super Client");
            this.label1.Text = NLocalizer.GetString("PrimSuperClient_PrimOutputControl_ClientName", "Client Name");
        }

        private void PrimOutputControl_Load(object sender, System.EventArgs e)
        {
            tBoxName.Text = _prim.Name;
            tBoxConnState.Text = _prim.PrimConnStat.ToString();
            tBoxRunState.Text = _prim.PrimRunStat.ToString();
        }

        public void SetPrimConnState(PrimConnState state)
        {
            if (tBoxConnState.InvokeRequired)
            {
                var update = new UpdatePrimConnState(SetPrimConnState);
                tBoxConnState.BeginInvoke(update, new object[1] { state });
            }
            else
            {
                switch (state)
                {
                    case PrimConnState.UnConnected:
                        tBoxConnState.BackColor = Color.Khaki;
                        tBoxConnState.Text = "UnConnected";
                        break;

                    case PrimConnState.Connected:
                        tBoxConnState.BackColor = Color.LightGreen;
                        tBoxConnState.Text = "Connected";
                        break;

                    case PrimConnState.Other:
                        tBoxConnState.BackColor = Color.Khaki;
                        tBoxConnState.Text = "UnConnected";
                        break;
                }
            }
        }

        public void SetPrimRunState(PrimRunState state)
        {
            if (tBoxRunState.InvokeRequired) //指示调用方在对控件进行方法调用时是否必须调用 Invoke 方法，因为调用方位于创建控件所在的线程以外的线程中
            {
                var update = new UpdatePrimRunState(SetPrimRunState);
                tBoxRunState.BeginInvoke(update, new object[1] { state });
            }
            else
            {
                switch (state)
                {
                    case PrimRunState.Idle:
                        tBoxRunState.BackColor = Color.Khaki;
                        tBoxRunState.Text = "Idle";
                        break;

                    case PrimRunState.Running:
                        tBoxRunState.BackColor = Color.LightGreen;
                        tBoxRunState.Text = "Running";
                        break;

                    case PrimRunState.Err:
                        tBoxRunState.BackColor = Color.SandyBrown;
                        tBoxRunState.Text = "Err";
                        break;

                    case PrimRunState.Other:
                        tBoxRunState.BackColor = Color.Khaki;
                        tBoxRunState.Text = "Idle";
                        break;
                }
            }
        }
    }
}