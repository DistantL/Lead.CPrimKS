﻿using System.Text;
using SuperSocket.ProtoBase;

namespace Lead.CPrim.PrimSuperClient
{
    public class LeadPackageInfo : IPackageInfo
    {
        public LeadPackageInfo(byte[] header, byte[] bodyBuffer)
        {
            Header = header;
            Data = bodyBuffer;
        }

        /// <summary>
        /// 服务器返回的字符串数据
        /// </summary>
        public string Body => Encoding.UTF8.GetString(Data);

        /// <summary>
        /// 服务器返回的字节数据
        /// </summary>
        public byte[] Data { get; set; }

        /// <summary>
        /// 服务器返回的字节数据头部
        /// </summary>
        public byte[] Header { get; set; }
    }
}