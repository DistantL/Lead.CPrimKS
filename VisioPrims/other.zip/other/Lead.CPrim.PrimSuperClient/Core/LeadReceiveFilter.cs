﻿using System.Linq;
using SuperSocket.ProtoBase;

namespace Lead.CPrim.PrimSuperClient
{
    public class LeadReceiveFilter : FixedHeaderReceiveFilter<LeadPackageInfo>
    {
        /// +-------+---+-------------------------------+
        /// |request| l |                               |
        /// | name  | e |    request body               |
        /// |  (2)  | n |                               |
        /// |       |(2)|                               |
        /// +-------+---+-------------------------------+
        public LeadReceiveFilter()
        : base(4)
        {
        }

        protected override int GetBodyLengthFromHeader(IBufferStream bufferStream, int length)
        {
            var buffers = bufferStream.Buffers[0];
            var array = buffers.ToArray();
            var len = array[length - 2] * 256 + array[length - 1];
            //int len = (int)array[buffers.Offset + 2] * 256 + (int)array[buffers.Offset + 3];
            return len;
        }

        public override LeadPackageInfo ResolvePackage(IBufferStream bufferStream)
        {
            //第三个参数用0,1都可以
            var header = bufferStream.Buffers[0].ToArray();
            var bodyBuffer = bufferStream.Buffers[1].ToArray();
            var allBuffer = bufferStream.Buffers[0].Array.CloneRange(0, (int)bufferStream.Length);
            return new LeadPackageInfo(header, bodyBuffer);
        }
    }
}