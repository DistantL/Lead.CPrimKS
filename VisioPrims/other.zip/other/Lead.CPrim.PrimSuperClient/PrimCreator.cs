﻿using System.Xml;
using Lead.CPrim.Interfaces;

namespace Lead.CPrim.PrimSuperClient
{
    public class PrimCreator : IPrimCreator
    {
        public IPrimTypeAttributes ConcretePrimTypeAttributes => new PrimTypeAttributes();

        public IPrim Create()
        {
            return new SuperClient();
        }

        public IPrim Create(XmlNode taskPrimConfig)
        {
            return new SuperClient(taskPrimConfig);
        }
    }
}