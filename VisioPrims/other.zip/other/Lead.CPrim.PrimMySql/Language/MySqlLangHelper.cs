﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;

namespace Lead.CPrim.PrimMySql
{
    internal class MySqlLangHelper
    {
        public static Dictionary<string, string> _listCSharp2Sql = new Dictionary<string, string>();

        public static List<string> CSharpType2MySqlMulti(Type type)
        {
            List<string> types = new List<string>();
            types.Clear();

            //FieldInfo[] fis = type.GetFields(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Public);
            PropertyInfo[] pros = type.GetProperties();
            //Console.WriteLine( fieldInfo.FieldType+":"+ fieldInfo.Name + ":" + fieldInfo.GetValue(obj) );
            foreach (PropertyInfo proInfo in pros)
            {
                string result = CSharpType2MySqlSingle(proInfo.PropertyType.ToString(), proInfo.Name);
                if (!string.IsNullOrEmpty(result))
                {
                    types.Add(result);
                }
            }

            return types;
        }

        public static string CSharpType2MySqlSingle(string feildType, string feildName)
        {
            string result = "";
            if (_listCSharp2Sql.ContainsKey(feildType))
            {
                result = feildName + " " + _listCSharp2Sql[feildType];
            }

            return result;
        }

        public static void LoadListCSharp2Sql(string path)
        {
            XElement root = XElement.Load(path);

            var custs = (from c in root.Elements("Language")
                         where c.Attribute("From").Value.Equals("C# System Types") && c.Attribute("To").Value.Equals("SQL")
                         select c).ToList();

            _listCSharp2Sql.Clear();
            foreach (XElement node in custs.Elements("Type"))
            {
                _listCSharp2Sql.Add(node.Attribute("From").Value, node.Attribute("To").Value);
            }
        }
    }
}