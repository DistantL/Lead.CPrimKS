﻿using System.Windows.Forms;

namespace Lead.CPrim.PrimMySql.Controls
{
    public partial class PrimDebugControl : UserControl
    {
        public PrimDebugControl()
        {
            InitializeComponent();
        }
    }
}