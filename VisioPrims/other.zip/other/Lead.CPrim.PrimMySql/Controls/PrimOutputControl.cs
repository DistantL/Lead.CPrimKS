﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Lead.CPrim.Interfaces;
using Lead.CPrim.LocalizationService;

namespace Lead.CPrim.PrimMySql.Controls
{
    public delegate void UpdatePrimConnStateT(PrimConnState state);

    public delegate void UpdatePrimRunStateT(PrimRunState state); //改变控件状态。。

    public partial class PrimOutputControl : UserControl
    {
        private PrimConfig _config = null;
        private IPrim _prim = null;

        public PrimOutputControl()
        {
            InitializeComponent();
            InitializeUI();
        }

        public PrimOutputControl(IPrim prim, PrimConfig config)
        {
            InitializeComponent();
            InitializeUI();
            _prim = prim;
            _config = config;
        }

        public string SqlName
        {
            set => tBoxName.Text = value;
        }

        private void BtnDel_Click(object sender, EventArgs e)
        {
        }

        private void btnDelCurSql_Click(object sender, EventArgs e)
        {
            DataRow dr = (dtGridView.SelectedRows[0].DataBoundItem as DataRowView).Row;

            if (string.IsNullOrEmpty(comBoxTables.Text)) { return; }

            string tbName = comBoxTables.Text;

            ((ISql)_prim).DelSingleRow(tbName, dr);
        }

        private void BtnInsert_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)dtGridView.DataSource;

            //1、添加空行
            DataRow dr1 = dt.NewRow();

            for (int i = 0; i < dt.Columns.Count; i++)
            {
                if (dt.Columns[i].ColumnName == "guid")
                {
                    dr1[i] = Guid.NewGuid();
                }
            }

            dt.Rows.Add(dr1);

            //for(int i = 0; i < dt.Columns.Count; i++)
            //{
            //    Type type = dt.Columns.GetType();
            //    if(type == typeof(DateTime))
            //    {
            //        dr1[i] = DateTime.Now;
            //    }
            //}
        }

        private void btnInsertToSql_Click(object sender, EventArgs e)
        {
            int iRet = 0;

            DataRow dr = (dtGridView.SelectedRows[0].DataBoundItem as DataRowView).Row;

            if (string.IsNullOrEmpty(comBoxTables.Text)) { return; }

            string tbName = comBoxTables.Text;

            iRet = ((ISql)_prim).InsertRow(tbName, dr);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)dtGridView.DataSource;

            if (string.IsNullOrEmpty(comBoxTables.Text)) { return; }

            string tbName = comBoxTables.Text;

            ((ISql)_prim).InsertByDataTable(tbName, dt);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(comBoxTables.Text)) { return; }

            string tbName = comBoxTables.Text;

            if (cBoxColName.Checked || cBoxVal.Checked || cBoxDtEnd.Checked || cBoxDtStart.Checked)
            {
                if (cBoxColName.Checked && cBoxVal.Checked && !string.IsNullOrEmpty(tBoxColName.Text) && !string.IsNullOrEmpty(tBoxVal.Text))
                {
                    DataTable dt = ((ISql)_prim).GetTableData(tbName, tBoxColName.Text, tBoxVal.Text);
                    if (dt != null)
                    {
                        dtGridView.DataSource = dt;
                    }
                }
            }
            else
            {
                DataTable dt = ((ISql)_prim).GetTableAllData(tbName);
                if (dt != null)
                {
                    dtGridView.DataSource = dt;
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
        }

        private void cBoxUpdate_CheckedChanged(object sender, EventArgs e)
        {
            if (cBoxUpdate.Checked)
            {
                tmrUpdate.Start();
            }
            else
            {
                tmrUpdate.Stop();
            }
        }

        private void cSVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridViewToCSV(dtGridView);
        }

        //function: 将dataGridView导出到csv
        private bool dataGridViewToCSV(DataGridView dataGridView)
        {
            if (dataGridView.Rows.Count == 0)
            {
                MessageBox.Show(NLocalizer.GetString("PrimMySql_PrimOutputControl_NoDataToExport", "No data to export."), NLocalizer.GetString("PrimMySql_PrimOutputControl_Tip", "Tip"), MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = NLocalizer.GetString("PrimMySql_PrimOutputControl_SaveFileDialogFilterFormat", "CSV files (*.csv)|*.csv");
            saveFileDialog.FilterIndex = 0;
            saveFileDialog.RestoreDirectory = true;
            saveFileDialog.CreatePrompt = true;
            saveFileDialog.FileName = null;
            saveFileDialog.Title = NLocalizer.GetString("PrimMySql_PrimOutputControl_Save", "Save");
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                Stream stream = saveFileDialog.OpenFile();
                StreamWriter sw = new StreamWriter(stream, System.Text.Encoding.GetEncoding(-0));
                string strLine = "";
                try
                {
                    //表头
                    for (int i = 0; i < dataGridView.ColumnCount; i++)
                    {
                        if (i > 0)
                        {
                            strLine += ",";
                        }

                        strLine += dataGridView.Columns[i].HeaderText;
                    }
                    strLine.Remove(strLine.Length - 1);
                    sw.WriteLine(strLine);
                    strLine = "";
                    //表的内容
                    for (int j = 0; j < dataGridView.Rows.Count; j++)
                    {
                        strLine = "";
                        int colCount = dataGridView.Columns.Count;
                        for (int k = 0; k < colCount; k++)
                        {
                            if (k > 0 && k < colCount)
                            {
                                strLine += ",";
                            }

                            if (dataGridView.Rows[j].Cells[k].Value == null)
                            {
                                strLine += "";
                            }
                            else
                            {
                                string cell = dataGridView.Rows[j].Cells[k].Value.ToString().Trim();
                                //防止里面含有特殊符号
                                cell = cell.Replace("\"", "\"\"");
                                cell = "\"" + cell + "\"";
                                strLine += cell;
                            }
                        }
                        sw.WriteLine(strLine);
                    }
                    sw.Close();
                    stream.Close();
                    MessageBox.Show(NLocalizer.GetString("PrimMySql_PrimOutputControl_DataIsExportedTo", "Data is exported to：") + saveFileDialog.FileName.ToString(), NLocalizer.GetString("PrimMySql_PrimOutputControl_ExportCompleted", "Export completed"), MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, NLocalizer.GetString("PrimMySql_PrimOutputControl_ExportError", "Export error"), MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
            }
            return true;
        }

        private void delAllSql_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(comBoxTables.Text)) { return; }

            string tbName = comBoxTables.Text;

            ((ISql)_prim).DelAllRows(tbName);
        }

        private void InitializeUI()
        {
            this.lbTitle.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_MySqlOutput", "MySql Output");
            this.label1.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_MySqlName", "MySql Name");
            this.tabPage2.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_CurrentPartInfo", "CurPartinfo");
            this.tabPage1.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_Query", "Query");
            this.cBoxUpdate.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_Update", "Update");

            this.groupBox2.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_Filter", "Filter:");
            this.label2.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_TableNames", "TableNames:");
            this.label3.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_ColumnName", "ColName:");
            this.label4.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_Value", "Val:");
            this.groupBox1.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_ExecuteDataTable", "Exec DataTable");
            this.btnSearch.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_Search", "Search");
            this.BtnDel.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_Delete", "Delete");
            this.BtnInsert.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_Insert", "Insert");
            this.groupBox3.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_ExecuteDataTable", "Exec DataTable");
            this.btnInsertToSql.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_InsertToSql", "Insert To Sql");
            this.btnUpdate.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_UpdateToSql", "Update To Sql");
            this.btnSave.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_SaveToSql", "Save To Sql");
            this.btnDelCurSql.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_DeleteToSql", "Del To Sql");
            this.delAllSql.Text = NLocalizer.GetString("PrimMySql_PrimOutputControl_DeleteAllSql", "Del All Sql");
        }

        private void PrimOutputControl_Load(object sender, EventArgs e)
        {
            tBoxName.Text = _prim.Name;
            tBoxConnState.Text = _prim.PrimConnStat.ToString();
            tBoxRunState.Text = _prim.PrimRunStat.ToString();
        }

        private void tmrUpdate_Tick(object sender, EventArgs e)
        {
            if (_prim.PrimConnStat != PrimConnState.Connected || _prim.PrimRunStat != PrimRunState.Running) { return; }

            try
            {
                DataTable dt = ((ISql)_prim).GetTableAllData("PartInfo");
                if (dt != null)
                {
                    dtGVCurRet.DataSource = dt;
                }
            }
            catch (Exception)
            {
                tmrUpdate.Stop();
            }
        }

        private void tStripBtnUpdateTables_Click(object sender, EventArgs e)
        {
            comBoxTables.Items.Clear();

            foreach (var item in ((ISql)_prim).DbTableInfoList)
            {
                comBoxTables.Items.Add(item.TableName);
            }
        }

        public void SetPrimConnState(PrimConnState state)
        {
            if (tBoxConnState.InvokeRequired)
            {
                UpdatePrimConnStateT update = new UpdatePrimConnStateT(SetPrimConnState);
                tBoxConnState.BeginInvoke(update, new object[1] { state });
            }
            else
            {
                switch (state)
                {
                    case PrimConnState.UnConnected:
                        tBoxConnState.BackColor = Color.Khaki;
                        tBoxConnState.Text = "UnConnected";
                        break;

                    case PrimConnState.Connected:
                        tBoxConnState.BackColor = Color.LightGreen;
                        tBoxConnState.Text = "Connected";
                        break;

                    case PrimConnState.Other:
                        tBoxConnState.BackColor = Color.Khaki;
                        tBoxConnState.Text = "UnConnected";
                        break;
                }
            }
        }

        public void SetPrimRunState(PrimRunState state)
        {
            if (tBoxRunState.InvokeRequired) //指示调用方在对控件进行方法调用时是否必须调用 Invoke 方法，因为调用方位于创建控件所在的线程以外的线程中
            {
                UpdatePrimRunStateT update = new UpdatePrimRunStateT(SetPrimRunState);
                tBoxRunState.BeginInvoke(update, new object[1] { state });
            }
            else
            {
                switch (state)
                {
                    case PrimRunState.Idle:
                        tBoxRunState.BackColor = Color.Khaki;
                        tBoxRunState.Text = "Idle";
                        break;

                    case PrimRunState.Running:
                        tBoxRunState.BackColor = Color.LightGreen;
                        tBoxRunState.Text = "Running";
                        break;

                    case PrimRunState.Err:
                        tBoxRunState.BackColor = Color.SandyBrown;
                        tBoxRunState.Text = "Err";
                        break;

                    case PrimRunState.Other:
                        tBoxRunState.BackColor = Color.Khaki;
                        tBoxRunState.Text = "Idle";
                        break;
                }
            }
        }
    }
}