﻿using System.Xml;
using Lead.CPrim.PrimMySql;

namespace Lead.CPrim.Interfaces
{
    public class PrimCreator : IPrimCreator
    {
        public IPrimTypeAttributes ConcretePrimTypeAttributes => new PrimTypeAttributes();

        public IPrim Create()
        {
            return new MySqlObj();
        }

        public IPrim Create(XmlNode taskPrimConfig)
        {
            return new MySqlObj(taskPrimConfig);
        }
    }
}