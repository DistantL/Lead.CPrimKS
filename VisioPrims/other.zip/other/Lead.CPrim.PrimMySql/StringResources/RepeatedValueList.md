2020-05-24 17：53：24
==============================================================================



## Repeated value：MySql Name ##

|Key|Position|
|:----------|:-------------|
|PrimMySql_PrimConfigControl_MySqlName|F:\CPrim.HIX-0918\CPrim.Ver2.9.5-PrimsEles\VisioPrims\Lead.CPrim.PrimMySql\Controls\PrimConfigControl.cs|
|PrimMySql_PrimOutputControl_MySqlName|F:\CPrim.HIX-0918\CPrim.Ver2.9.5-PrimsEles\VisioPrims\Lead.CPrim.PrimMySql\Controls\PrimOutputControl.cs|
