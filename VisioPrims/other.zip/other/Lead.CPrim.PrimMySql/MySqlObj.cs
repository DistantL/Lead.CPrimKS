﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using Lead.CPrim.Interfaces;
using Lead.CPrim.LocalizationService;
using Lead.CPrim.LogHelper;
using Lead.CPrim.PrimMySql.Controls;
using Lead.CPrim.XmlHelper;
using MySql.Data.MySqlClient;

namespace Lead.CPrim.PrimMySql
{
    public class MySqlObj : IPrim, ISql
    {
        #region Private Member

        private PrimConfig _config = null;
        private bool _initialed = false;

        private MySqlConnection _myConn = null;

        #endregion Private Member

        #region Override IPrim's Feild & Property

        private Control _primConfigUI = null;

        private Control _primDebugUI = null;

        private Control _primOutputUI = null;

        private string connstr;

        private object objLock = new object();

        public event PrimDataRefresh OnPrimDataRefresh;

        public event PrimOpLog OnPrimOpLog;

        public event PrimStateChanged OnPrimStateChanged;

        //Prim 子类的类型
        public Type ChildType
        {
            set => _config.ChildType = value;
            get => _config.ChildType;
        }

        //Prim的硬件、软件类型
        public PrimType HSType
        {
            set => _config.HSType = value;
            get => _config.HSType;
        }

        public Guid Id
        {
            set => _config.Id = value;
            get => _config.Id;
        }

        public bool LogEnable
        {
            set => _config.LogEnable = value;
            get => _config.LogEnable;
        }

        public PrimManufacture Manu
        {
            set => _config.Manu = value;
            get => _config.Manu;
        }

        public string Name
        {
            set
            {
                _config.Name = value;
                ((PrimConfigControl)_primConfigUI).SqlName = value;
                ((PrimOutputControl)_primOutputUI).SqlName = value;
            }
            get => _config.Name;
        }

        public LogLevel PrimAlarmLv { get; set; }

        public Control PrimConfigUI => _primConfigUI;

        public PrimConnState PrimConnStat
        {
            set => _config.PrimConnStat = value;
            get => _config.PrimConnStat;
        }

        public bool PrimDebug
        {
            set => _config.PrimDebug = value;
            get => _config.PrimDebug;
        }

        public Control PrimDebugUI => _primDebugUI;

        public bool PrimEnable
        {
            set => _config.PrimEnable = value;
            get => _config.PrimEnable;
        }

        public Control PrimOutputUI => _primOutputUI;

        public RunMode PrimRunMode { get; set; }

        public PrimRunState PrimRunStat
        {
            set => _config.PrimRunStat = value;
            get => _config.PrimRunStat;
        }

        public bool PrimSimulator
        {
            set => _config.PrimSimulator = value;
            get => _config.PrimSimulator;
        }

        public string PrimTypeName
        {
            set => _config.PrimTypeName = value;
            get => _config.PrimTypeName;
        }

        public PrimVer Ver
        {
            set => _config.Ver = value;
            get => _config.Ver;
        }

        #endregion Override IPrim's Feild & Property

        #region override ISql's Feild & Property

        public string CurDbName
        {
            set => _config.ObjConfig.CurDbName = value;
            get => _config.ObjConfig.CurDbName;
        }

        public string CurTableName
        {
            set => _config.ObjConfig.CurTableName = value;
            get => _config.ObjConfig.CurTableName;
        }

        public List<DbTableInfo> DbTableInfoList
        {
            set => _config.ObjConfig.DbTableInfoList = value;
            get => _config.ObjConfig.DbTableInfoList;
        }

        public string LoadLangPath
        {
            set => _config.ObjConfig.LoadLangPath = value;
            get => _config.ObjConfig.LoadLangPath;
        }

        public string LoadObjPath
        {
            set => _config.ObjConfig.LoadObjPath = value;
            get => _config.ObjConfig.LoadObjPath;
        }

        public string PassWord
        {
            set => _config.ObjConfig.PassWord = value;
            get => _config.ObjConfig.PassWord;
        }

        public string SqlAddr
        {
            set => _config.ObjConfig.SqlAddr = value;
            get => _config.ObjConfig.SqlAddr;
        }

        public int SqlPort
        {
            set => _config.ObjConfig.SqlPort = value;
            get => _config.ObjConfig.SqlPort;
        }

        public string UserId
        {
            set => _config.ObjConfig.UserId = value;
            get => _config.ObjConfig.UserId;
        }

        #endregion override ISql's Feild & Property

        #region IPrim's Function

        public int IPrimConnect(ref string result)
        {
            int iRet = 0;

            return iRet;
        }

        public int IPrimDisConnect(ref string result)
        {
            int iRet = 0;
            return iRet;
        }

        public int IPrimDispose()
        {
            try
            {
                ((PrimDebugControl)_primDebugUI).Dispose();
                ((PrimOutputControl)_primOutputUI).Dispose();
                ((PrimConfigControl)_primConfigUI).Dispose();

                PrimRunStat = PrimRunState.Other;
                PrimConnStat = PrimConnState.Other;
                return 0;
            }
            catch (Exception)
            {
                PrimRunStat = PrimRunState.Err;
                PrimConnStat = PrimConnState.Other;
                return -1;
            }
        }

        public XmlNode IPrimExportConfigXml()
        {
            //config turn to xmlNode
            if (_config == null) { return null; }

            XmlNode node = XMLHelper.ObjectToXML(_config);

            return node;
        }

        public int IPrimImportConfigXml(XmlNode xmlNode)
        {
            int iRet = 0;
            if (xmlNode != null)
            {
                _config = XMLHelper.XMLToObject(xmlNode, typeof(PrimConfig)) as PrimConfig;
            }
            else { return -1; }
            return iRet;
        }

        public int IPrimInit()
        {
            int iRet = 0;

            if (_initialed) { return 0; }
            if (PrimConnStat == PrimConnState.Connected) { return 0; }
            if (PrimRunStat == PrimRunState.Running) { return 0; }

            PrimRunStat = PrimRunState.Idle;
            PrimConnStat = PrimConnState.UnConnected;
            _initialed = false;

            connstr = $"server={SqlAddr};port={SqlPort.ToString()};user id={UserId};password={PassWord};database={CurDbName};Charset=utf8;";

            iRet = ConnectCurDataBase();
            if (iRet >= 0)
            {
                PrimConnStat = PrimConnState.Connected;
                _initialed = true;
            }

            ((PrimConfigControl)_primConfigUI).SetPrimConnState(PrimConnStat);
            ((PrimConfigControl)_primConfigUI).SetPrimRunState(PrimRunStat);
            ((PrimOutputControl)_primOutputUI).SetPrimConnState(PrimConnStat);
            ((PrimOutputControl)_primOutputUI).SetPrimRunState(PrimRunStat);

            return iRet;
        }

        public int IPrimReset()
        {
            int iRet = 0;
            return iRet;
        }

        public int IPrimResume()
        {
            int iRet = 0;
            return iRet;
        }

        public int IPrimStart()
        {
            int iRet = 0;
            if (PrimRunStat == PrimRunState.Running) { return 0; }

            UpdateTables();

            PrimRunStat = PrimRunState.Running;

            ((PrimConfigControl)_primConfigUI).SetPrimConnState(PrimConnStat);
            ((PrimConfigControl)_primConfigUI).SetPrimRunState(PrimRunStat);
            ((PrimOutputControl)_primOutputUI).SetPrimConnState(PrimConnStat);
            ((PrimOutputControl)_primOutputUI).SetPrimRunState(PrimRunStat);

            return iRet;
        }

        public int IPrimStop()
        {
            int iRet = 0;
            return iRet;
        }

        public int IPrimSuspend()
        {
            int iRet = 0;
            return iRet;
        }

        #endregion IPrim's Function

        #region ISql's Function

        public int ConnectCurDataBase()
        {
            int iRet = 0;
            //string Constr = "server=localhost;port=3306;user id=root;password=mysql;database=test;Charset=utf8;";

            int connCount = 0;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        break;
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_ConnectTableFailed", " ConnectTable failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            iRet = (connCount == 4) ? -1 : 0;

            return iRet;
        }

        public int ConnectCurDbTable()
        {
            int iRet = 0;
            string connstr = $"server={SqlAddr};port={SqlPort.ToString()};user id={UserId};password={PassWord};database={CurDbName};tablename={CurTableName};Charset=utf8;";

            int connCount = 0;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        break;
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_ConnectTableFailed", " ConnectTable failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            iRet = (connCount == 4) ? -1 : 0;

            return iRet;
        }

        public int ConnectDataBase(string dbName)
        {
            int iRet = 0;
            return iRet;
        }

        public int ConnectDbTable(string tableName)
        {
            int iRet = 0;
            return iRet;
        }

        public int ConnectServer()
        {
            int iRet = 0;
            return iRet;
        }

        public int ConnectTable(string dbName, string tableName)
        {
            int iRet = 0;
            return iRet;
        }

        public int CreateDataBase(string dbName)
        {
            int iRet = 0;
            return iRet;
        }

        public int CreateTable(string tableName, Type type)
        {
            int iRet = 0;

            List<string> sqlTypeInfos = MySqlLangHelper.CSharpType2MySqlMulti(type);
            if (sqlTypeInfos.Count <= 0) { return -1; }

            string sqlCreate = $"CREATE TABLE {tableName} (";

            for (int i = 0; i < sqlTypeInfos.Count; i++)
            {
                sqlCreate = sqlCreate + sqlTypeInfos[i];
                if (i < (sqlTypeInfos.Count - 1))
                {
                    sqlCreate = sqlCreate + ",";
                }
            }

            sqlCreate = sqlCreate + ")";

            int connCount = 0;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        using (MySqlCommand cmd = new MySqlCommand(sqlCreate, _myConn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                        break;
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_CreateTableFailed", " CreateTable failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            iRet = (connCount == 4) ? -1 : 0;

            return iRet;
        }

        public int CreateTable(string tableName, string param)
        {
            int iRet = 0;

            string sqlCreate = $"CREATE TABLE {tableName} ( {param} )";

            int connCount = 0;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        using (MySqlCommand cmd = new MySqlCommand(sqlCreate, _myConn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                        break;
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_CreateTableFailed", " CreateTable failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            iRet = (connCount == 4) ? -1 : 0;

            return iRet;
        }

        public int CurInsertRow(DataRow row)
        {
            int iRet = 0;

            iRet = InsertRow(CurTableName, row);

            return iRet;
        }

        public int CurUpdateRow(string colName, object val, string param)
        {
            int iRet = 0;

            iRet = UpdateRow(CurTableName, colName, val, param);

            return iRet;
        }

        public int DelAllRows(string tbName)
        {
            int iRet = 0;

            string delStr = $"delete from {tbName}";

            int connCount = 0;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        using (MySqlCommand cmd = new MySqlCommand(delStr, _myConn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                        break;
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_DeleteAllRowsFailed", " DelAllRows failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                // if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            iRet = (connCount == 4) ? -1 : 0;

            return iRet;
        }

        public int DelSingleRow(string tbName, DataRow row)
        {
            int iRet = 0;

            string colName = row.Table.Columns[0].ColumnName;
            string colVal = row[0].ToString();
            string delStr = $"delete from {tbName} where {colName} = {colVal} ";

            int connCount = 0;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        using (MySqlCommand cmd = new MySqlCommand(delStr, _myConn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                        break;
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_DeleteSingleRowFailed", " DelSingleRow failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            iRet = (connCount == 4) ? -1 : 0;

            return iRet;
        }

        public int DelTable(string tableName)
        {
            int iRet = 0;

            string alterStatement = $"DROP TABLE {tableName}";

            int connCount = 0;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        using (MySqlCommand cmd = new MySqlCommand(alterStatement, _myConn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                        break;
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_DeleteTableFailed", " DelTable failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            iRet = (connCount == 4) ? -1 : 0;

            return iRet;
        }

        public DataTable ExecuteQuerySql(string sqlStr)
        {
            //int iRet = 0;
            int connCount = 0;

            DataTable dtTable = null;
            MySqlDataAdapter adapter = null;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        if (dtTable == null)
                        {
                            dtTable = new DataTable();
                        }

                        adapter = new MySqlDataAdapter(sqlStr, _myConn);
                        adapter.Fill(dtTable);
                        if (dtTable != null)
                        {
                            break;
                        }
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_ExecuteSqlsFailed", " ExecuteSqls failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            if (connCount == 4)
            {
                dtTable = null;
            }

            return dtTable;
        }

        public int ExecuteSql(string sql)
        {
            int iRet = 0;
            int connCount = 0;

            MySqlCommand myCommand = null;
            MySqlTransaction myTrans = null;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        myCommand = _myConn.CreateCommand();
                        myTrans = _myConn.BeginTransaction();
                        myCommand.Connection = _myConn;
                        myCommand.Transaction = myTrans;
                        myCommand.CommandText = sql;
                        myCommand.ExecuteNonQuery();
                        myTrans.Commit();
                        break;
                    }
                    catch (Exception ex)
                    {
                        if (myTrans != null && myTrans.Connection != null)
                        {
                            myTrans.Rollback();
                        }

                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_ExecuteSqlsFailed", " ExecuteSqls failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            iRet = (connCount == 4) ? -1 : 0;
            return iRet;
        }

        public int ExecuteSqls(List<string> sqlList)
        {
            int iRet = 0;
            int connCount = 0;

            MySqlCommand myCommand = null;
            MySqlTransaction myTrans = null;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        myCommand = _myConn.CreateCommand();
                        myTrans = _myConn.BeginTransaction();
                        myCommand.Connection = _myConn;
                        myCommand.Transaction = myTrans;
                        foreach (var sqlStr in sqlList)
                        {
                            myCommand.CommandText = sqlStr;
                            myCommand.ExecuteNonQuery();
                        }
                        myTrans.Commit();
                        break;
                    }
                    catch (Exception ex)
                    {
                        if (myTrans != null && myTrans.Connection != null)
                        {
                            myTrans.Rollback();
                        }

                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_ExecuteSqlsFailed", " ExecuteSqls failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }
            iRet = (connCount == 4) ? -1 : 0;

            return iRet;
        }

        public string GetCreateTableStr(string tableName, Type type)
        {
            List<string> sqlTypeInfos = MySqlLangHelper.CSharpType2MySqlMulti(type);
            if (sqlTypeInfos.Count <= 0) { return string.Empty; }

            string sqlCreate = $"CREATE TABLE {tableName} (";

            for (int i = 0; i < sqlTypeInfos.Count; i++)
            {
                sqlCreate = sqlCreate + sqlTypeInfos[i];
                if (i < (sqlTypeInfos.Count - 1))
                {
                    sqlCreate = sqlCreate + ",";
                }
            }

            sqlCreate = sqlCreate + ")";

            return sqlCreate;
        }

        public string GetCreateTableStr(string tableName, string param)
        {
            string sqlCreate = $"CREATE TABLE {tableName} ( {param} )";
            return sqlCreate;
        }

        public DataTable GetCurTableAllData()
        {
            int connCount = 0;

            DataTable dtTable = null;
            DataSet ds = null;
            MySqlDataAdapter adapter = null;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        if (dtTable == null)
                        {
                            dtTable = new DataTable();
                        }

                        if (ds == null)
                        {
                            ds = new DataSet();
                        }

                        adapter = new MySqlDataAdapter($"select * from {CurTableName}", _myConn);
                        adapter.Fill(ds, CurTableName);
                        dtTable = ds.Tables[CurTableName];
                        if (dtTable != null)
                        {
                            break;
                        }
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_GetCurrentTableAllDataFailed", " GetCurTableAllData failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            if (connCount == 4)
            {
                dtTable = null;
            }

            return dtTable;
        }

        public string GetDelAllRowsStr(string tbName)
        {
            string delStr = $"delete from {tbName}";
            return delStr;
        }

        public string GetDelSingleRowStr(string tbName, string colName, object val)
        {
            string delStr = $"delete from {tbName} where {colName} = '{val}' ";
            return delStr;
        }

        public string GetDelTableStr(string tableName)
        {
            string alterStatement = $"DROP TABLE {tableName}";
            return alterStatement;
        }

        public string GetInsertColStr(string tbName, string colName, string colType)
        {
            string alterStatement = $"ALTER TABLE {tbName} ADD {colName} {colType}";
            return alterStatement;
        }

        public string GetInsertRowStr(string tbName, DataRow row)
        {
            string alterStatement = $"insert into {tbName}";

            StringBuilder sb = new StringBuilder();
            sb.Append(alterStatement + "(");

            for (int i = 0; i < row.Table.Columns.Count; i++)
            {
                sb.Append(row.Table.Columns[i].ColumnName + ",");
            }

            sb.Remove(sb.ToString().LastIndexOf(','), 1);
            sb.Append(") VALUES ");

            sb.Append("(");
            for (int j = 0; j < row.Table.Columns.Count; j++)
            {
                sb.Append("'" + row[j] + "',");
            }
            sb.Remove(sb.ToString().LastIndexOf(','), 1);
            sb.Append("),");

            sb.Remove(sb.ToString().LastIndexOf(','), 1);
            sb.Append(";");

            return sb.ToString();
        }

        public string GetMySqlCurInsertRow(DataRow row)
        {
            return GetInsertRowStr(CurTableName, row);
        }

        public string GetMySqlCurUpdateRowStr(Dictionary<string, object> cols, string param)
        {
            return GetUpdateRowStr(CurTableName, cols, param);
        }

        public string GetMySqlDelSingleRowStr(string tbName, DataRow row)
        {
            string colName = row.Table.Columns[0].ColumnName;
            string colVal = row[0].ToString();
            string delStr = $"delete from {tbName} where {colName} = {colVal} ";
            return delStr;
        }

        public DataTable GetTableAllData(string tbName)
        {
            int connCount = 0;

            DataTable dtTable = null;
            DataSet ds = null;
            MySqlDataAdapter adapter = null;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        if (dtTable == null)
                        {
                            dtTable = new DataTable();
                        }

                        if (ds == null)
                        {
                            ds = new DataSet();
                        }

                        adapter = new MySqlDataAdapter($"select * from {tbName}", _myConn);
                        adapter.Fill(ds, tbName);
                        dtTable = ds.Tables[tbName];
                        if (dtTable != null)
                        {
                            break;
                        }
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_GetTableAllDataFailed", " GetTableAllData failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            if (connCount == 4)
            {
                dtTable = null;
            }

            return dtTable;
        }

        public DataTable GetTableData(string tbName, string col, string val)
        {
            int connCount = 0;

            DataTable dtTable = null;
            DataSet ds = null;
            MySqlDataAdapter adapter = null;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        if (dtTable == null)
                        {
                            dtTable = new DataTable();
                        }

                        if (ds == null)
                        {
                            ds = new DataSet();
                        }

                        adapter = new MySqlDataAdapter($"select * from {tbName} where {col} = '{val}'", _myConn);
                        adapter.Fill(ds, tbName);
                        dtTable = ds.Tables[tbName];
                        if (dtTable != null)
                        {
                            break;
                        }
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_GetTableDataFailed", " GetTableData failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            if (connCount == 4)
            {
                dtTable = null;
            }

            return dtTable;
        }

        public string GetUpdateRowStr(string tbName, Dictionary<string, object> cols, string param)
        {
            StringBuilder updateStr = new StringBuilder();
            updateStr.Append($"update {tbName} set ");
            if (string.IsNullOrEmpty(param))
            {
                foreach (var col in cols)
                {
                    updateStr.Append($" {col.Key}  =  '{col.Value }',");
                }
                updateStr.Remove(updateStr.ToString().LastIndexOf(','), 1);
            }
            else
            {
                foreach (var col in cols)
                {
                    updateStr.Append($" {col.Key}  =  '{col.Value }',");
                }
                updateStr.Remove(updateStr.ToString().LastIndexOf(','), 1);
                updateStr.Append($"where {param}");
            }
            return updateStr.ToString();
        }

        /// <summary>
        /// DataTable批量加入MYSQL数据库
        /// </summary>
        /// <param name="dataTable"></param>
        /// <returns></returns>
        public string InsertByDataTable(string tbName, DataTable dataTable)
        {
            string result = string.Empty;
            if (null == dataTable || dataTable.Rows.Count <= 0)
            {
                return NLocalizer.GetString("PrimMySql_MySqlObj_DataTableHasNoData", "Add failed! DataTable has no data yet!");
            }
            if (string.IsNullOrEmpty(tbName))
            {
                return NLocalizer.GetString("PrimMySql_MySqlObj_SetDataTableNameFirstly", "Add failed! Please set the name of the DataTable first!");
            }
            // 构建INSERT语句
            StringBuilder sb = new StringBuilder();
            sb.Append("INSERT INTO " + tbName + "(");
            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                sb.Append(dataTable.Columns[i].ColumnName + ",");
            }
            sb.Remove(sb.ToString().LastIndexOf(','), 1);
            sb.Append(") VALUES ");
            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                sb.Append("(");
                for (int j = 0; j < dataTable.Columns.Count; j++)
                {
                    if (dataTable.Columns[j].DataType == typeof(bool))
                    {
                        sb.Append(dataTable.Rows[i][j] + ",");
                    }
                    else
                    {
                        sb.Append("'" + dataTable.Rows[i][j] + "',");
                    }
                }
                sb.Remove(sb.ToString().LastIndexOf(','), 1);
                sb.Append("),");
            }
            sb.Remove(sb.ToString().LastIndexOf(','), 1);
            sb.Append(";");
            int res = -1;

            int connCount = 0;

            MySqlTransaction myTrans = null;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        using (MySqlCommand cmd = _myConn.CreateCommand())
                        {
                            myTrans = _myConn.BeginTransaction();
                            cmd.Connection = _myConn;
                            cmd.Transaction = myTrans;
                            cmd.CommandText = sb.ToString();
                            res = cmd.ExecuteNonQuery();
                            myTrans.Commit();
                        }
                        break;
                    }
                    catch (Exception ex)
                    {
                        if (myTrans != null && myTrans.Connection != null)
                        {
                            myTrans.Rollback();
                        }

                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_InsertByDataTableFailed", " InsertByDataTable failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                // if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            if (res > 0)
            {
                result = NLocalizer.GetString("PrimMySql_MySqlObj_AddedSuccessfully", "Added successfully!");
            }
            if (connCount == 4)
            {
                result = NLocalizer.GetString("PrimMySql_MySqlObj_AddedFailed", "Added failly!");
            }
            return result;

            //try
            //{
            //}
            //catch (Exception ex)
            //{
            //    myTrans.Rollback();
            //    res = -1;
            //    // Unknown column 'names' in 'field list'
            //    result = "操作失败！" + ex.Message.Replace("Unknown column", "未知列").Replace("in 'field list'", "存在字段集合中！");
            //    LogAdd(Name + result, AlarmLv.Debug, 15);
            //}
            //_myConn.Close();
        }

        public int InsertCol(string tbName, string colName, string colType)
        {
            int iRet = 0;

            string alterStatement = $"ALTER TABLE {tbName} ADD {colName} {colType}";

            int connCount = 0;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        using (MySqlCommand cmd = new MySqlCommand(alterStatement, _myConn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                        break;
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_InsertColumnFailed", " InsertCol failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            iRet = (connCount == 4) ? -1 : 0;

            return iRet;
        }

        public int InsertRow(string tbName, DataRow row)
        {
            int iRet = 0;

            string alterStatement = $"insert into {tbName}";

            StringBuilder sb = new StringBuilder();
            sb.Append(alterStatement + "(");

            for (int i = 0; i < row.Table.Columns.Count; i++)
            {
                sb.Append(row.Table.Columns[i].ColumnName + ",");
            }

            sb.Remove(sb.ToString().LastIndexOf(','), 1);
            sb.Append(") VALUES ");

            sb.Append("(");
            for (int j = 0; j < row.Table.Columns.Count; j++)
            {
                if (row.Table.Columns[j].DataType == typeof(bool))
                {
                    sb.Append("" + row[j] + ",");
                }
                else
                {
                    sb.Append("'" + row[j] + "',");
                }
            }
            sb.Remove(sb.ToString().LastIndexOf(','), 1);
            sb.Append("),");

            sb.Remove(sb.ToString().LastIndexOf(','), 1);
            sb.Append(";");

            int connCount = 0;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        using (MySqlCommand cmd = new MySqlCommand(sb.ToString(), _myConn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                        break;
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_InsertRowFailed", " InsertRow failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            iRet = (connCount == 4) ? -1 : 0;

            return iRet;
        }

        public int LoadLang(string path)
        {
            int iRet = 0;

            if (string.IsNullOrEmpty(path)) { return -1; }
            if (!File.Exists(path)) { return -1; }

            MySqlLangHelper.LoadListCSharp2Sql(path);

            return iRet;
        }

        public object QueryExcute(string sqlCmd)
        {
            int iRet = 0;

            int connCount = 0;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        using (MySqlCommand cmd = new MySqlCommand(sqlCmd, _myConn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                        break;
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_QueryExecuteFailed", " QueryExecute failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            iRet = (connCount == 4) ? -1 : 0;

            return iRet;
        }

        public int UpdateRow(string tbName, string colName, object val, string param)
        {
            int iRet = 0;

            string updateStr = "";
            if (string.IsNullOrEmpty(param))
            {
                updateStr = $"update {tbName} set {colName} = '{val.ToString()}'";
            }
            else
            {
                updateStr = $"update {tbName} set {colName} = '{val.ToString()}' where {param}";
            }

            int connCount = 0;

            lock (objLock)
            {
                for (connCount = 0; connCount < 4; connCount++)
                {
                    try
                    {
                        if (_myConn == null)
                        {
                            _myConn = new MySqlConnection(connstr);
                        }

                        if (_myConn.State == ConnectionState.Closed)
                        {
                            _myConn.Open();
                        }

                        using (MySqlCommand cmd = new MySqlCommand(updateStr, _myConn))
                        {
                            cmd.ExecuteNonQuery();
                        }
                        break;
                    }
                    catch (Exception ex)
                    {
                        LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_UpdateRowFailed", " UpdateRow failed. ( ") + ex + " )", LogLevel.Debug, 16);
                        Thread.Sleep(20);
                    }
                }
                //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
            }

            iRet = (connCount == 4) ? -1 : 0;

            return iRet;
        }

        public List<string> UpdateTables()
        {
            if (_myConn == null)
            {
                PrimRunStat = PrimRunState.Idle;
                PrimConnStat = PrimConnState.UnConnected;
                _initialed = false;

                ((PrimConfigControl)_primConfigUI).SetPrimConnState(PrimConnStat);
                ((PrimConfigControl)_primConfigUI).SetPrimRunState(PrimRunStat);
                ((PrimOutputControl)_primOutputUI).SetPrimConnState(PrimConnStat);
                ((PrimOutputControl)_primOutputUI).SetPrimRunState(PrimRunStat);

                return null;
            }
            List<string> tbNames = new List<string>();
            tbNames.Clear();

            int connCount = 0;
            try
            {
                lock (objLock)
                {
                    for (connCount = 0; connCount < 4; connCount++)
                    {
                        try
                        {
                            if (_myConn == null)
                            {
                                _myConn = new MySqlConnection(connstr);
                            }

                            if (_myConn.State == ConnectionState.Closed)
                            {
                                _myConn.Open();
                            }

                            DataTable tbName = _myConn.GetSchema("Tables");// 这句是关键  Connectioin为连接 使用的是Mysql.Data.dll
                            if (tbName.Columns.Contains("TABLE_NAME"))
                            {
                                foreach (DataRow dr in tbName.Rows)
                                {
                                    tbNames.Add((string)dr["TABLE_NAME"]);
                                }
                            }

                            if (tbNames.Count > 0)
                            {
                                _config.ObjConfig.DbTableInfoList.Clear();

                                foreach (string name in tbNames)
                                {
                                    DbTableInfo info = new DbTableInfo();
                                    info.DbName = CurDbName;
                                    info.TableName = name;
                                    _config.ObjConfig.DbTableInfoList.Add(info);
                                }
                            }
                            break;
                        }
                        catch (Exception ex)
                        {
                            LogAdd(Name + NLocalizer.GetString("PrimMySql_MySqlObj_ConnectTableFailed", " ConnectTable failed. ( ") + ex + " )", LogLevel.Debug, 16);
                            Thread.Sleep(20);
                        }
                    }
                    //if (_myConn != null && _myConn.State != ConnectionState.Closed) _myConn.Close();
                }

                PrimRunStat = PrimRunState.Running;
                PrimConnStat = PrimConnState.Connected;
                _initialed = true;

                ((PrimConfigControl)_primConfigUI).SetPrimConnState(PrimConnStat);
                ((PrimConfigControl)_primConfigUI).SetPrimRunState(PrimRunStat);
                ((PrimOutputControl)_primOutputUI).SetPrimConnState(PrimConnStat);
                ((PrimOutputControl)_primOutputUI).SetPrimRunState(PrimRunStat);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                PrimRunStat = PrimRunState.Idle;
                PrimConnStat = PrimConnState.UnConnected;
                _initialed = false;

                ((PrimConfigControl)_primConfigUI).SetPrimConnState(PrimConnStat);
                ((PrimConfigControl)_primConfigUI).SetPrimRunState(PrimRunStat);
                ((PrimOutputControl)_primOutputUI).SetPrimConnState(PrimConnStat);
                ((PrimOutputControl)_primOutputUI).SetPrimRunState(PrimRunStat);

                return null;
            }

            return tbNames;
        }

        #endregion ISql's Function

        #region Construct

        public MySqlObj()
        {
            _config = new PrimConfig();
            _config.ObjConfig = new MySqlObjCOnfig();
            _config.ObjConfig.DbTableInfoList = new List<DbTableInfo>();
            _config.ObjConfig.DbTableInfoList.Clear();

            _primDebugUI = new PrimDebugControl();
            _primConfigUI = new PrimConfigControl(this, _config);
            _primOutputUI = new PrimOutputControl(this, _config);

            PrimRunStat = PrimRunState.Idle;
            PrimConnStat = PrimConnState.UnConnected;
            _initialed = false;

            ((PrimConfigControl)_primConfigUI).SetPrimConnState(PrimConnStat);
            ((PrimConfigControl)_primConfigUI).SetPrimRunState(PrimRunStat);
            ((PrimOutputControl)_primOutputUI).SetPrimConnState(PrimConnStat);
            ((PrimOutputControl)_primOutputUI).SetPrimRunState(PrimRunStat);
        }

        public MySqlObj(XmlNode xmlNode)
        {
            //xmlNode turn to _config
            if (xmlNode != null)
            {
                _config = XMLHelper.XMLToObject(xmlNode, typeof(PrimConfig)) as PrimConfig;
            }
            else { return; }

            _primDebugUI = new PrimDebugControl();
            _primConfigUI = new PrimConfigControl(this, _config);
            _primOutputUI = new PrimOutputControl(this, _config);

            PrimRunStat = PrimRunState.Idle;
            PrimConnStat = PrimConnState.UnConnected;
            _initialed = false;

            ((PrimConfigControl)_primConfigUI).SetPrimConnState(PrimConnStat);
            ((PrimConfigControl)_primConfigUI).SetPrimRunState(PrimRunStat);
            ((PrimOutputControl)_primOutputUI).SetPrimConnState(PrimConnStat);
            ((PrimOutputControl)_primOutputUI).SetPrimRunState(PrimRunStat);
        }

        #endregion Construct

        private void LogAdd(string log, LogLevel lv, int id)
        {
            if (!LogEnable)
            {
                return;
            }

            switch (lv)
            {
                case LogLevel.Fatal:
                    Log.Fatal(11900000 + id, log, LogClassification.VisioPrim, Name);
                    PrimAlarmLv = LogLevel.Fatal;
                    PrimRunStat = PrimRunState.Err;
                    break;

                case LogLevel.Error:
                    Log.Error(21900000 + id, log, LogClassification.VisioPrim, Name);
                    PrimAlarmLv = LogLevel.Error;
                    PrimRunStat = PrimRunState.Err;
                    break;

                case LogLevel.Warn:
                    Log.Warn(31900000 + id, log, LogClassification.VisioPrim, Name);
                    PrimAlarmLv = LogLevel.Warn;
                    PrimRunStat = PrimRunState.Err;
                    break;

                case LogLevel.Info:
                    Log.Info(41900000 + id, log, LogClassification.VisioPrim, Name);
                    PrimAlarmLv = LogLevel.Info;
                    // PrimRunStat = PrimRunState.Err;
                    break;

                case LogLevel.Debug:
                    Log.Debug(51900000 + id, log, LogClassification.VisioPrim, Name);
                    PrimAlarmLv = LogLevel.Debug;
                    //PrimRunStat = PrimRunState.Err;
                    break;

                case LogLevel.Trace:
                    Log.Trace(61900000 + id, log, LogClassification.VisioPrim, Name);
                    PrimAlarmLv = LogLevel.Trace;
                    //PrimRunStat = PrimRunState.Err;
                    break;

                default:
                    break;
            }
        }

        public int IPrimTaskInit()
        {
            if (IPrimInit() != 0)
            {
                return -1;
            }
            var connRet = "";
            if (IPrimConnect(ref connRet) != 0)
            {
                return -2;
            }

            if (IPrimStart() != 0)
            {
                return -3;
            }

            return 0;
        }

        public int IPrimTaskPause()
        {
            return 0;
        }

        public int IPrimTaskReset()
        {
            if (IPrimReset() != 0)
            {
                return -1;
            }

            return 0;
        }

        public int IPrimTaskStop()
        {
            if (IPrimStop() != 0)
            {
                return -1;
            }
            return 0;
        }
    }
}