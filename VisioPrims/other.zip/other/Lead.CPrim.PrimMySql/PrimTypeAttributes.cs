﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Resources;
using Lead.CPrim.PrimMySql;

namespace Lead.CPrim.Interfaces
{
    public class PrimTypeAttributes : IPrimTypeAttributes
    {
        public IEnumerable<KeyValuePair<string, object>> Attributes => throw new NotImplementedException();
        public string Description => "";
        public string DisplayGroup => "DataBase";
        public string DisplayName => "MySql";
        public string Group => "DataBase";

        public Image Icon
        {
            get
            {
                ResourceManager manager = new ResourceManager(typeof(RrcMySqlObj));
                return (Image)manager.GetObject("Mysql");
            }
        }

        public byte MajorVersion => 1;
        public byte MinorVersion => 0;
        public string Name => "MySql";
        public object this[string attrName] => throw new NotImplementedException();
    }
}