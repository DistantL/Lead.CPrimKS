﻿using System;
using System.Collections.Generic;
using Lead.CPrim.Interfaces;

namespace Lead.CPrim.PrimMySql
{
    public class MySqlObjCOnfig
    {
        public string CurDbName { set; get; }
        public string CurTableName { set; get; }
        public List<DbTableInfo> DbTableInfoList { get; set; }
        public string LoadLangPath { set; get; }
        public string LoadObjPath { set; get; }
        public string PassWord { set; get; }
        public string SqlAddr { set; get; }
        public int SqlPort { set; get; }
        public string UserId { set; get; }
    }

    public class PrimConfig
    {
        //Prim 子类的类型
        public Type ChildType { set; get; }

        //Prim的硬件、软件类型
        public PrimType HSType { set; get; }

        public Guid Id { set; get; }
        public bool LogEnable { set; get; }
        public PrimManufacture Manu { set; get; }
        public string Name { set; get; }
        public MySqlObjCOnfig ObjConfig { set; get; }
        public PrimConnState PrimConnStat { set; get; }
        public bool PrimDebug { set; get; }
        public bool PrimEnable { set; get; }
        public PrimRunState PrimRunStat { set; get; }
        public bool PrimSimulator { set; get; }
        public string PrimTypeName { set; get; }
        public PrimVer Ver { set; get; }
    }
}