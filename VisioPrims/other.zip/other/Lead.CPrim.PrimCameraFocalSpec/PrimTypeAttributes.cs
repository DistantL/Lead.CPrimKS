﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Resources;

using Lead.CPrim.Interfaces;
using Lead.CPrim.PrimCameraFocalSpec;

namespace Lead.CPrim.Interfaces
{
    public class PrimTypeAttributes : IPrimTypeAttributes
    {
        public string Name => "FocalSpec";

        public string DisplayName => "Camera";

        public string Description => "";

        public string Group => "Dev";

        public string DisplayGroup => "Dev";

        public byte MajorVersion => 1;

        public byte MinorVersion => 0;

        public Image Icon
        {
            get
            {
                ResourceManager manager = new ResourceManager(typeof(ResourceFocalSpec));
                return (Image)manager.GetObject("Device_Camera_FocalSpec");
            }
        }

        public object this[string attrName] => throw new NotImplementedException();

        public IEnumerable<KeyValuePair<string, object>> Attributes => throw new NotImplementedException();
    }
}
