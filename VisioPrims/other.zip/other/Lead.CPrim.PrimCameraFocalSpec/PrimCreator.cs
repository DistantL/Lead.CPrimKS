﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

using Lead.CPrim.Interfaces;
using Lead.CPrim.PrimCameraFocalSpec;


namespace Lead.CPrim.Interfaces
{
    public class PrimCreator : IPrimCreator
    {
        public IPrimTypeAttributes ConcretePrimTypeAttributes => new PrimTypeAttributes();

        public IPrim Create()
        {
            return new PrimFocalSpec();
        }

        public IPrim Create(XmlNode taskPrimConfig)
        {
            return new PrimFocalSpec(taskPrimConfig);
        }
    }

}
